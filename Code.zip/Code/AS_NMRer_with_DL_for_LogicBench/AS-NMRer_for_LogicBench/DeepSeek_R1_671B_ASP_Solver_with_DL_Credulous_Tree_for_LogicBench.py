"""
Implementation of neuro-symbolic methods for non-monotonic reasoning
"""
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["NCCL_P2P_DISABLE"] = "1" # Disable NCCL P2P communication
os.environ["NCCL_IB_DISABLE"] = "0" # Disable NCCL IB communication
os.environ['WANDB_MODE'] = 'dryrun'

from abc import ABC, abstractmethod
from collections import defaultdict
import math
import copy
import random
from unsloth import FastModel
import sys
import re
import httpx
import torch
sys.path.append('/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Datasets')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import TrainingArguments, AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig,AutoTokenizer, AutoModel
import json
import traceback
from unsloth import FastLanguageModel, PatchFastRL
PatchFastRL("GRPO", FastLanguageModel)  # Patch GRPO algorithm to accelerate training
import difflib
from peft import PeftModel, PeftConfig
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
from clingo.control import Control
from clingo.symbol import parse_term
from sentence_transformers import SentenceTransformer, util
import gc

from trl import SFTTrainer, DataCollatorForCompletionOnlyLM
from transformers import TrainingArguments
from datasets import load_dataset
from huggingface_hub import login
from huggingface_hub import notebook_login
from datasets import Dataset
import pandas as pd
import numpy as np
from random import randrange

max_seq_length = 2048
Reasoning_Mode = 'credulous' # [credulous, skeptical]
Formal_Natural_Language = 'DL' # ['ASP','DL']
Total_Expert_Iterative_Number = 0 # Represents the number of expert iterations
Translation_Sentences_Number = 1 # Represents the number of translations for each sentence，When the number of generated candidate sentences is 1, it means each sentence is translated only once and no verifier is used.
Semantic_Verifier_Flag, Grammaer_Verifier_Flag,Aligned_Rules_Flag = True, True, False
Generate_Fine_Tune_Sample_Number, Generate_Repair_Sample_Number = 1, 1 # Represents the number of fine-tuning samples and repair samples generated
Allatonce_Flag = False # Used to indicate whether it is step-by-step sentence-by-sentence reasoning or one-time reasoning, True means one-time reasoning, False means step-by-step sentence-by-sentence reasoning
Selected_Sentence_Number = 1 # Represents the number of sentences selected from the candidate translation sentence list to be added to the context, default is 1
OOD_Flag, NL_Flag = False, False
Semantic_Score_Threshold = 0.5 # Used to indicate the semantic similarity threshold between aligned ASP sentences and natural language after predicate consistency alignment
Similarity_with_GPT4_Flag, Similarity_with_LLAMA31_Flag, Similarity_with_Sentence_Transformer_Flag = False, False, True # Used to indicate whether to reason on the answer set based on similarity or directly use large models to reason on the problem
Task_Type, NMR_Category = '', ''
NMR_Category_List = ['default_reasoning_default', 'default_reasoning_irr', 'default_reasoning_open','default_reasoning_several','reasoning_about_exceptions_1','reasoning_about_exceptions_2','reasoning_about_exceptions_3','reasoning_about_priority']
Reasoning_Deep = ''
Dataset_Name = 'LogicBench'
Dataset_Type = 'test' # Represents the type of dataset，['train', 'dev', 'test']
Task_Type = 'BQA' # ['BQA','MCQA']

   
LLMs_Models_Choise = "DeepSeek_R1_671B" # ['DeepSeek_R1','DeepSeek_V3_671B','Claude','Gemma_7B','Mistral_7B','LLAMA3','LLAMA31']
         

read_file_path = '/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Datasets/' + str(Dataset_Name) + '/'
write_file_path = '/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Experiment/Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #Used to filter the answer set
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16


import warnings
warnings.filterwarnings("ignore")


import numpy as np
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


# Set random seed
setup_seed(20)
Prompt_with_Generate_ASP_Code, Prompt_with_Generate_Default_Logic_Code ='',''
LogicBench_Example_Dict = None
Prompt_with_Extract_Fact_Rule_From_Context,Prompt_with_Extract_Sentence_from_Context,Prompt_with_Rewrite_Extract_Fact_Rule_From_Context,Prompt_with_Verifier_Extract_Fact_Rule_From_Context = '','','',''
Prompt_with_Generate_Default_Logic_Code_for_LogicBench,Prompt_with_Generate_ASP_Code_for_LogicBench = '',''
Prompt_with_Predicate_Consistency_Alignment,Prompt_with_Predicate_Consistency_Alignment_for_LogicBench = '',''
Grammar_Score_Prompt,Semantic_Score_Prompt_with_ASP,Semantic_Score_Prompt_with_DL  = '','',''
Credulous_Reasoning_Prompt_for_LogicBench, Skeptical_Reasoning_Prompt_for_LogicBench, Reasoning_Prompt_for_LogicBench = '','',''
Fine_Tune_Generator_Instruction, Prompt_with_Direct_Repair_ASP_Code = '',''
Prompt_with_ASP_Critic ,Prompt_with_Generate_Default_Logic_Code= '',''
Fine_Tune_Instruction,Semantic_Score_Prompt_with_ASP_for_LogicBench = '',''
Semantic_Score_Prompt_with_ASP_for_LogicEvalD1,Semantic_Score_Prompt_with_ASP_for_LogicEvalD2, Semantic_Score_Prompt_with_ASP_for_LogicEvalD3 = '','',''
Origin_Context_List, Origin_Question_List,Astraction_Sentence_List,Astraction_Question_List=[],[],[],[]

LogicBench_DL_Onebyone_Example_Dict_from_Train ={"default_reasoning_default": "For example 1: The natural language sentence to be translated is: kangaroos and emus are marsupials. ### \n The predicate of the sentence is: marsupials. ### \n The entities of the sentence is: kangaroos. emus. ### \n The translated formal logic program sentence is: marsupials(kangaroos). marsupials(emus). ### \n For example 2: The natural language sentence to be translated is: marsupials usually carry their young in a pouch. ### \n The predicate of the sentence is: marsupials. has_pouch. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: marsupial(X): -exception(X) / has_pouch(X). ### \n For example 3: The translated formal logic program sentence is: kangaroos are possibly an exception to this rule. ### \n The predicate of the sentence is: exception. ### \n The entities of the sentence is: kangaroos. ### \n The translated formal logic program sentence is: exception(kangaroos). ### \n For example 4: The natural language sentence to be translated is: emus carry their young in a pouch? ### \n The predicate of the sentence is: has_pouch. ### \n The entities of the sentence is: emus. ### \n The translated formal logic program sentence is: has_pouch(emus). ### \n For example 5: The natural language sentence to be translated is: emus don\'t carry their young in a pouch? ### \n The predicate of the sentence is: emus. ### \n The entities of the sentence is: emus. ### \n The translated formal logic program sentence is: -has_pouch(emus). ### \n", "default_reasoning_irr": "### \n For example 1: The natural language sentence to be translated is: dogs and cats are animals. ### \n The predicate of the sentence is: animals. ### \n The entities of the sentence is: dogs. cats. ### \n The translated formal logic program sentence is: animals(dogs). animals(cats). ### \n For example 2: The natural language sentence to be translated is: animals typically live in homes. ### \n The predicate of the sentence is: animals. live_homes. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: anmals(X): -exception(X) / live_home(X). ### \n For example 3: The natural language sentence to be translated is: dogs are not living in homes. ### \n The predicate of the sentence is: live_home. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: -live_home (dogs). ### \n For example 4: The natural language sentence to be translated is: dogs are loyal companions. ### \n The predicate of the sentence is: loyal_companions. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: loyal_companions(dogs). ### \n For example 5: The natural language sentence to be translated is: cats are living in homes? ### \n The predicate of the sentence is: live_home. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: live_home(cats). ### \n For example 6: The natural language sentence to be translated is: cats aren\'t living in homes? ### \n The predicate of the sentence is: live_home. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: - live_home(cats). ### \n", "default_reasoning_open": "### \n For example 1: The natural language sentence to be translated is: lemurs are primates. ### \n The predicate of the sentence is: primates. ### \n The entities of the sentence is: lemurs. ### \n The translated formal logic program sentence is: primates(primates). primates(lemurs). ### \n For example 2: The natural language sentence to be translated is: primates have opposable thumbs. ### \n The predicate of the sentence is: opposable_thumbs. ### \n The entities of the sentence is: primates. ### \n The translated formal logic program sentence is: primates (X): opposable_thumbs(X) / opposable_thumbs(X). ### \n For example 3: The natural language sentence to be translated is: lemurs do not have opposable thumbs. ### \n The predicate of the sentence is: opposable_thumbs. ### \n The entities of the sentence is: lemurs. ### \n The translated formal logic program sentence is: -opposable_thumbs(lemurs). ### \n For example 4: The natural language sentence to be translated is: all other primates than lemurs have opposable thumbs? ### \n The predicate of the sentence is: opposable_thumbs. ### \n The entities of the sentence is: primates. ### \n The translated formal logic program sentence is: opposable_thumbs(primates). -opposable_thumbs(lemurs). ### \n For example 5: The natural language sentence to be translated is: all other primates than lemurs don\'t have opposable thumbs? ### \n The predicate of the sentence is: opposable_thumbs. ### \n The entities of the sentence is: primates. ### \n The translated formal logic program sentence is: -opposable_thumbs(primates). opposable_thumbs(lemurs). ### \n", "default_reasoning_several": "### \n For example 1: The natural language sentence to be translated is: john and tim are friends. ### \n The predicate of the sentence is: friends . ### \n The entities of the sentence is: john. tim. ### \n The translated formal logic program sentence is: friends(john, tim). ### \n For example 2: The natural language sentence to be translated is: friends are loyal. ### \n The predicate of the sentence is: friends. loyal. ### \n The entities of the sentence is:X,Y. ### \n The translated formal logic program sentence is: friends(X,Y): loyal(X) / loyal(X). friends(X,Y): loyal(Y) / loyal(Y). ### \n For example 3: The natural language sentence to be translated is: friends are always supportive. ### \n The predicate of the sentence is: friends. supportive. ### \n The entities of the sentence is: X.Y. ### \n The translated formal logic program sentence is: friends(X,Y): supportive(X) / supportive(X). friends(X,Y): supportive(Y) / supportive(Y). ### \n For example 4: The natural language sentence to be translated is: john is not loyal. ### \n The predicate of the sentence is: loyal. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: -loyal(john). ### \n For example 5: The natural language sentence to be translated is: tim is not supportive. ### \n The predicate of the sentence is: supportive. ### \n The entities of the sentence is: tim. ### \n The translated formal logic program sentence is: -supportive(tim). ### \n For example 6: The natural language sentence to be translated is: tim is loyal and john is supportive? ### \n The predicate of the sentence is: loyal. supportive. ### \n The entities of the sentence is: tim. john. ### \n The translated formal logic program sentence is: loyal(tim). supportive(john). ### \n For example 7: The natural language sentence to be translated is: tim isn\'t loyal and john is supportive? ### \n The predicate of the sentence is: . ### \n The entities of the sentence is:. ### \n The translated formal logic program sentence is: -loyal(tim). supportive(john). ### \n For example 8: The natural language sentence to be translated is: tim is loyal and john isn\'t supportive? ### \n The predicate of the sentence is: loyal. supportive. ### \n The entities of the sentence is: tim. john. ### \n The translated formal logic program sentence is: loyal(tim). -supportive(john). ### \n For example 9: The natural language sentence to be translated is: tim isn\'t loyal and john isn\'t supportive? ### \n The predicate of the sentence is: loyal. supportive. ### \n The entities of the sentence is: tim. john. ### \n The translated formal logic program sentence is: -loyal(tim). -supportive(john). ### \n", "reasoning_about_exceptions_1": "### \n For example 1: The natural language sentence to be translated is: apples, oranges, and bananas are fruits. ### \n The predicate of the sentence is: fruits. ### \n The entities of the sentence is: apples. oranges. bananas. ### \n The translated formal logic program sentence is: fruits(apples). fruits(oranges). fruits(bananas). ### \n For example 2: The natural language sentence to be translated is: fruits are typically rich in vitamins. ### \n The predicate of the sentence is: fruits. vitamins. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: fruits(X): vitamins(X) / vitamins(X). ### \n For example 3: The natural language sentence to be translated is: at least one of apples or oranges does not contain vitamins. ### \n The predicate of the sentence is: vitamins. ### \n The entities of the sentence is: apples. oranges. ### \n The translated formal logic program sentence is: -vitamins(apples) | -vitamins(oranges). ### \n For example 4: The natural language sentence to be translated is: bananas are rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### \n The predicate of the sentence is: vitamins . ### \n The entities of the sentence is: bananas. apples. ### \n The translated formal logic program sentence is: vitamins(bananas). -vitamins(apples) | -vitamins(oranges). ### \n For example 5: The natural language sentence to be translated is: bananas aren\'t rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### \n The predicate of the sentence is: vitamins. ### \n The entities of the sentence is: apples. oranges. ### \n The translated formal logic program sentence is: -vitamins(bananas). -vitamins(apples) | -vitamins(oranges). ### \n", "reasoning_about_exceptions_2": "### \n For example 1: The natural language sentence to be translated is: cars drive on roads. ### \n The predicate of the sentence is: cars. drive_on_roads. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: cars(cars). cars(X) : drive_on_roads(X) / drive_on_roads(X). ### \n For example 2: The natural language sentence to be translated is: at least one car doesn\'t drive on roads. ### \n The predicate of the sentence is: drive_on_roads. ### \n The entities of the sentence is: one_car. ### \n The translated formal logic program sentence is: cars(one_car). -drive_on_roads(one_car). ### \n For example 3: The natural language sentence to be translated is: exactly one car drive on roads? ### \n The predicate of the sentence is: drive_on_roads. ### \n The entities of the sentence is: one_car. ### \n The translated formal logic program sentence is: drive_on_roads(one_car). ### \n For example 4: The natural language sentence to be translated is: exactly one car doesn't drive on roads? ### \n The predicate of the sentence is: drive_on_roads. ### \n The entities of the sentence is: one_car. ### \n The translated formal logic program sentence is: -drive_on_roads(one_car). ### \n", "reasoning_about_exceptions_3": "### \n For example 1: The natural language sentence to be translated is: cats are carnivores. ### \n The predicate of the sentence is: carnivores. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: carnivores(cats). carnivores(carnivores). ### \n For example 2: The natural language sentence to be translated is: carnivores normally eat meat. ### \n The predicate of the sentence is: carnivores. ### \n The entities of the sentence is: eat_meat. ### \n The translated formal logic program sentence is: carnivores(X): eat_meat(X) / eat_meat(X). ### \n For example 3: The natural language sentence to be translated is: at least one carnivore does not eat meat. ### \n The predicate of the sentence is: eat_meat. ### \n The entities of the sentence is: one_carnivore. ### \n The translated formal logic program sentence is: carnivores(one_carnivore). -eat_meat(one_carnivore). ### \n For example 4: The natural language sentence to be translated is: cats usually eat meat? ### \n The predicate of the sentence is: eat_meat. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: eat_meat(cats). ### \n For example 5: The natural language sentence to be translated is: cats usually don\'t eat meat? ### \n The predicate of the sentence is: eat_meat. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: -eat_meat(cats). ### \n", "reasoning_about_priority": "### \n For example 1: The natural language sentence to be translated is: john asserts that the cat is in the park. ### \n The predicate of the sentence is: in_park. asserts. ### \n The entities of the sentence is: john.cat. X. ### \n The translated formal logic program sentence is: asserts(john, in_park(cat)). asserts(john, in_park(cat)): -more_reliable(_, john) / in_park(cat). ### \n For example 2: The natural language sentence to be translated is: jane asserts that the cat is not in the park. ### \n The predicate of the sentence is: in_park. asserts. ### \n The entities of the sentence is: jane. cat. ### \n The translated formal logic program sentence is: asserts(jane, -in_park(cat)). asserts(jane, -in_park(cat)) : -more_reliable(_, jane) / -in_park(cat). ### \n For example 3: The natural language sentence to be translated is: jane\'s evidence is more reliable than john\'s. ### \n The predicate of the sentence is: more_reliable. ### \n The entities of the sentence is: jane. john. ### \n The translated formal logic program sentence is: more_reliable(jane, john). ### \n For example 4: The natural language sentence to be translated is: the cat is not in the park? ### \n The predicate of the sentence is: in_park. ### \n The entities of the sentence is: cat. ### \n The translated formal logic program sentence is: -in_park(cat). ### \n For example 5: The natural language sentence to be translated is: the cat is in the park? ### \n The predicate of the sentence is: in_park. ### \n The entities of the sentence is: cat. ### \n The translated formal logic program sentence is: in_park(cat). ### \n."}
LogicBench_DL_Allatonce_Example_Dict_from_Train ={"default_reasoning_default": "For example 1: The natural language sentence to be translated is: kangaroos and emus are marsupials. marsupials usually carry their young in a pouch. kangaroos are possibly an exception to this rule. ### \n The predicate of the sentence is: marsupials. has_pouch ### \n The entities of the sentence is: kangaroos. emus. ### \n The translated formal logic program sentence is: marsupials(kangaroos). marsupials(emus). marsupial(X): -exception(X) / has_pouch(X). exception(kangaroos). ### \n For example 2: The natural language sentence to be translated is: emus carry their young in a pouch? ### \n The predicate of the sentence is: marsupials. has_pouch ### \n The entities of the sentence is: emus. ### \n The translated formal logic program sentence is: has_pouch(emus). ### \n For example 3: The natural language sentence to be translated is: emus don\'t carry their young in a pouch? ### \n The predicate of the sentence is: marsupials. has_pouch ### \n The entities of the sentence is: emus. ### \n The translated formal logic program sentence is: -has_pouch(emus). ### \n", "default_reasoning_irr": "### \n For example 1: The natural language sentence to be translated is: dogs and cats are animals. animals typically live in homes. dogs are not living in homes. ### \n The predicate of the sentence is: animals. live_homes. loyal_companions. ### \n The entities of the sentence is: dogs. cats. ### \n The translated formal logic program sentence is: animals(dogs). animals(cats). animals(X): live_homes(X) / live_home(X). -live_home (dogs). loyal_companions(dogs). ### \n For example 2: The natural language sentence to be translated is: dogs are loyal companions. cats are living in homes? ### \n The predicate of the sentence is: animals. live_homes. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: live_home(cats). ### \n For example 3: The natural language sentence to be translated is: dogs are loyal companions. cats aren\'t living in homes? ### \n The predicate of the sentence is: animals. live_homes. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: -live_home(cats).", "default_reasoning_open": "### \n For example 1: The natural language sentence to be translated is: lemurs are primates. primates have opposable thumbs. lemurs do not have opposable thumbs. ### \n The predicate of the sentence is: primates. ### \n The entities of the sentence is: lemurs. ### \n The translated formal logic program sentence is: primates(primates). primates(lemurs). primates (X): opposable_thumbs(X) / opposable_thumbs(X). -opposable_thumbs(lemurs). opposable_thumbs(primates). -opposable_thumbs(lemurs). ### \n For example 2: The natural language sentence to be translated is: all other primates than lemurs have opposable thumbs? ### \n The predicate of the sentence is: opposable_thumbs ### \n The entities of the sentence is: primates. lemurs. ### \n The translated formal logic program sentence is: opposable_thumbs(primates). -opposable_thumbs(lemurs). ### \n For example 3: The natural language sentence to be translated is: all other primates than lemurs don\'t have opposable thumbs? ### \n The predicate of the sentence is: opposable_thumbs ### \n The entities of the sentence is: primates. lemurs. ### \n The translated formal logic program sentence is: -opposable_thumbs(primates). opposable_thumbs(lemurs). ### \n", "default_reasoning_several": "### \n For example 1: The natural language sentence to be translated is: john and tim are friends. friends are loyal. friends are always supportive. john is not loyal. tim is not supportive. ### \n The predicate of the sentence is: friends. loyal. supportive. ### \n The entities of the sentence is: john. tim. ### \n The translated formal logic program sentence is: friends(john, tim). friends(X,Y): loyal(X) / loyal(X). friends(X,Y): loyal(Y) / loyal(Y). friends(X,Y): supportive(X) / supportive(X). friends(X,Y): supportive(Y) / supportive(Y). -loyal(john). -supportive(tim). loyal(tim). supportive(john). -loyal(tim). supportive(john). loyal(tim). -supportive(john). ### \n For example 2: The natural language sentence to be translated is: tim is loyal and john is supportive? ### \n The predicate of the sentence is: friends. loyal. supportive. ### \n The entities of the sentence is: john. tim. ### \n The translated formal logic program sentence is: loyal(tim). supportive(john). ### \n For example 3: The natural language sentence to be translated is: tim isn\'t loyal and john is supportive? ### \n The predicate of the sentence is: friends. loyal. supportive. ### \n The entities of the sentence is: john. tim. ### \n The translated formal logic program sentence is: -loyal(tim). supportive(john). ### \n For example 4: The natural language sentence to be translated is: tim is loyal and john isn\'t supportive? ### \n The predicate of the sentence is: friends. loyal. supportive. ### \n The entities of the sentence is: john. tim. ### \n The translated formal logic program sentence is: loyal(tim). -supportive(john). ### \n For example 5: The natural language sentence to be translated is: tim isn\'t loyal and john isn\'t supportive? ### \n The predicate of the sentence is: friends. loyal. supportive. ### \n The entities of the sentence is: john. tim. ### \n The translated formal logic program sentence is: -loyal(tim). -supportive(john). ### \n", "reasoning_about_exceptions_1": "### \n For example 1: The natural language sentence to be translated is: apples, oranges, and bananas are fruits. fruits are typically rich in vitamins. at least one of apples or oranges does not contain vitamins. ### \n The predicate of the sentence is: fruits. vitamins. ### \n The entities of the sentence is: apples. oranges. bananas. ### \n The translated formal logic program sentence is: fruits(apples). fruits(oranges). fruits(bananas). fruits(X): vitamins(X) / vitamins(X). -vitamins(apples) | -vitamins(oranges). ### \n For example 2: The natural language sentence to be translated is: bananas aren\'t rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### \n The predicate of the sentence is: fruits. vitamins. ### \n The entities of the sentence is: apples. oranges. bananas. ### \n The translated formal logic program sentence is: vitamins(bananas). -vitamins(apples) | -vitamins(oranges). ### \n For example 3: The natural language sentence to be translated is: bananas are rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### \n The predicate of the sentence is: fruits. vitamins. ### \n The entities of the sentence is: apples. oranges. bananas. ### \n The translated formal logic program sentence is: -vitamins(bananas). -vitamins(apples) | -vitamins(oranges). ### \n", "reasoning_about_exceptions_2": "### \n For example 1: The natural language sentence to be translated is: cars drive on roads. at least one car doesn\'t drive on roads. ### \n The predicate of the sentence is: cars. drive_on_roads. cars. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: cars(cars). cars(X) : drive_on_roads(X) / drive_on_roads(X). -drive_on_roads(one_car). ### \n For example 2: The natural language sentence to be translated is: exactly one car drive on roads? ### \n The predicate of the sentence is: cars. drive_on_roads. ### \n The entities of the sentence is: one_car. ### \n The translated formal logic program sentence is: drive_on_roads(one_car). ### \n ### \n For example 3: The natural language sentence to be translated is: exactly one car doesn't drive on roads? ### \n The predicate of the sentence is: cars. drive_on_roads. ### \n The entities of the sentence is: one_car. ### \n The translated formal logic program sentence is: -drive_on_roads(one_car). ### \n ", "reasoning_about_exceptions_3": "### \n For example 1: The natural language sentence to be translated is: cats are carnivores. carnivores normally eat meat. at least one carnivore does not eat meat. ### \n The predicate of the sentence is: carnivores. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: carnivores(cats). carnivores(carnivores). carnivores(X): eat_meat(X) / eat_meat(X). carnivores (one_carnivore). -eat_meat(one_carnivore). ### \n For example 2: The natural language sentence to be translated is: cats usually eat meat? ### \n The predicate of the sentence is: carnivores. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: eat_meat(cats). ### \n For example 3: The natural language sentence to be translated is: cats usually don\'t eat meat? ### \n The predicate of the sentence is: carnivores. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: -eat_meat(cats). ### \n", "reasoning_about_priority": "### \n For example 1: The natural language sentence to be translated is: john asserts that the cat is in the park. jane asserts that the cat is not in the park. jane\'s evidence is more reliable than john\'s. ### \n The predicate of the sentence is: in_park. person. asserts. more_reliable. ### \n The entities of the sentence is: john.cat. X. ### \n The translated formal logic program sentence is: person(john). asserts(john, in_park(cat)). person(jane). asserts(jane, -in_park(cat)). asserts(Person, in_park(cat)): -more_reliable(_, Person) / in_park(cat). asserts(Person, -in_park(cat)) : -more_reliable(_, Person) / -in_park(cat). more_reliable(jane, john). ### \n For example 2: The natural language sentence to be translated is: the cat is not in the park? ### \n The predicate of the sentence is: in_park. ### \n The entities of the sentence is: cat. ### \n The translated formal logic program sentence is: -in_park(cat). ### \n For example 3: The natural language sentence to be translated is: the cat is in the park? ### \n The predicate of the sentence is: in_park. person. asserts. more_reliable. ### \n The entities of the sentence is: john.cat. X. ### \n The translated formal logic program sentence is: in_park(cat). ### \n"}


# Define examples for extracting and rewriting facts and rules from context  # TODO: Manual translation needed
LogicBench_Extract_FR_From_Context_from_Test = {"default_reasoning_default": " For example 1: The natural language context sentences are: jenny and anna are known for their tall stature, which is often associated with playing basketball. However, anna might be an exception to this norm. jenny plays basketball. ### \n The questions are: jenny plays basketball. jenny doesn't play basketball. ### \n The extracted entities are: jenny. anna. \n The extracted predicate are: plays basketball. \n The extracted facts and rules in context are: jenny is tall. anna is tall. tall people is usually play basketball. anna is not plays basketball. jenny plays basketball. ### \n The extracted questions are: jenny plays basketball. jenny doesn't play basketball. ### \n", "default_reasoning_irr": "### \n For example 1: The natural language context sentences are: Once upon a time, in a land filled with animals, there were two popular mammalian creatures, cats and dogs. Mammals typically possessed a coat of fur, which kept them warm and protected. However, cats were an exception to this rule, as their bodies lacked fur. Nonetheless, both cats and dogs were beloved by many for their unique traits. Dogs, known for their loyalty, were particularly cherished by humans. ### \n The questions are: dogs have fur. dogs don't have fur. ### \n The extracted entities are: cats. dogs. \n The extracted predicate are: mammals. \n The extracted facts and rules in context are: cats are mammals. dogs are mammals. mammals usually have fur. cats don't have fur. dogs are loyalty. ### \n The extracted questions are: dogs have fur. dogs don't have fur. ### \n", "default_reasoning_open": " ### \n For example 1: The natural language sentence to be translated is: In the bird kingdom, there are many different species that possess unique characteristics. One such species is the hummingbird, known for its ability to hover in mid-air and its vibrant colors. While most birds engage in the annual migration south for the winter, the hummingbird chooses to stay put and brave the cold weather. This decision sets the hummingbird apart from its fellow avian companions, as it relies on its resilience and resourcefulness to survive the harsh conditions. ### \n The questions are: all other birds than hummingbirds migrate south for the winter. all other birds than hummingbirds don't migrate south for the winter. ### \n The extracted entities are: hummingbirds. \n The extracted predicate are: migrate south for the winter. \n The extracted facts and rules in context are: hummingbirds are birds. birds usually migrate south for the winter. hummingbirds do not migrate south for the winter. ### \n The extracted questions are: all other birds than hummingbirds migrate south for the winter. all other birds than hummingbirds don't migrate south for the winter. ### \n ", "default_reasoning_several": "### \n For example 1: The natural language context sentences are: john and mary were expecting their first child, filled with the anticipation and excitement that all parents feel. Parents are usually loving and supportive. Parents are normally responsible. However, something seemed amiss in their relationship. mary, usually affectionate and caring, seemed distant and uninvolved. On the other hand, John, known for his responsible nature, started neglecting his duties and became unreliable. ### \n The questions are: mary is responsible and john is loving and supportive. mary isn't responsible and john is loving and supportive. ### \n The extracted entities are: john. mary. \n The extracted predicate are: parents. loving. supportive. responsible. \n The extracted facts and rules in context are: john are parents. mary are parents. parents are usually loving. parents are usually responsible. mary is not loving. john is not responsible. ### \n The extracted questions are: mary is responsible and john is loving. mary isn't responsible and john is loving. ### \n", "reasoning_about_exceptions_1": "### \n For example 1: The natural language context sentences are: In a world where animals are often regarded as intelligent creatures, there is a captivating tale that revolves around cats, dogs, and horses. It is commonly believed that most animals possess a level of intellect. However, there is an intriguing twist to this belief as it is known that either cats or dogs are not considered particularly intelligent. As the story unfolds, we delve into the lives of these remarkable creatures, their interactions, and the unique qualities that each of them possesses. ### \n The questions are: horses are considered to be intelligent creatures and exactly one of cats or dogs is not considered intelligent. horses aren't considered to be intelligent creatures and exactly one of cats or dogs is not considered intelligent. ### \n The extracted entities are: cats. dogs. horses. \n The extracted predicate are: animals. intelligent. \n The extracted facts and rules in context are: cats are animals. dogs are animals. horses are animals. animals are usually intelligent. at least one of cats or dogs is not intelligent. ### \n The extracted questions are: horses are intelligent and exactly one of cats or dogs is not intelligent. horses aren't intelligent creatures and exactly one of cats or dogs is not intelligent. ### \n", "reasoning_about_exceptions_2": "### \n For example 1: The natural language context sentences are: In the realm of cat communication, meowing serves as a fundamental aspect of their vocal repertoire. However, intriguingly enough, there exists a distinct species of cat that deviates from this conventional norm. This peculiar feline defies the expectations associated with its kind by refraining from emitting any meows whatsoever. ### \n The questions are: exactly one species of cat doesn't meow. exactly one species of cat meow. ### \n The extracted entities are: cats. one cat. \n The extracted predicate are: meows. \n The extracted facts and rules in context are: cats are usually meow. One species cat is cat. One species cat is one cat. one species cat is not meows. ### \n The extracted questions are: one species cat doesn't meow. one species cat meow. ### \n ", "reasoning_about_exceptions_3": "### \n For example 1: The natural language sentence to be translated is: In a world where cars were known for having four wheels, it was considered a common fact that wheels typically came equipped with spokes. However, amidst this widespread understanding, there was an exception. At least one wheel defied this norm and stood out from the rest by not having any spokes at all. ### \n The questions are: cars have four wheels with spokes. cars don't have four wheels with spokes. ### \n The extracted entities are: cars. one wheel. \n The extracted predicate are: wheels. spokes. \n The extracted facts and rules in context are: cars have wheels. wheels are wheels. wheels usually have spokes. one wheel is wheels. one wheel does not have spokes. ### \n The extracted questions are: cars have wheels with spokes. cars don't have wheels with spokes. ### \n", "reasoning_about_priority": "### \n For example 1: The natural language context sentences are: In the midst of a heated argument, john adamantly claims that sally was present at the store. However, Jane strongly opposes John's assertion, insisting that sally was indeed absent from the store. john's evidence is more reliable than jane's. ### \n The questions are: sally was in the store. ### \n The extracted entities are: john. sally. \n The extracted predicate are: store. reliable. \n The extracted facts and rules in context are: john is more reliable than jane. john asserts that sally was in the store. jane asserts that sally was not in the store. ### \n The extracted questions are: sally was in the store. ### \n "}
LogicBench_DL_Onebyone_Example_Dict_from_Test ={"default_reasoning_default": "For example 1: The natural language sentence to be translated is: jenny are tall. ### \n The predicate of the sentence is: tall. ### \n The entities of the sentence is: jenny. ### \n The translated formal logic program sentence is: tall(jenny). For example 2: The natural language sentence to be translated is: anna are tall. ### \n The predicate of the sentence is: tall. ### \n The entities of the sentence is: anna. ### \n The translated formal logic program sentence is: tall(anna). For example 3: The natural language sentence to be translated is: tall people usually play basketball. ### \n The predicate of the sentence is: tall. playBasketball. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: tall(X) : playBasketball(X) / playBasketball(X). ### \n For example 4: The natural language sentence to be translated is: anna is not plays basketball. ### \n The predicate of the sentence is: playBasketball. ### \n The entities of the sentence is: anna. ### \n The translated formal logic program sentence is: -playBasketball (anna). ### \n For example 5: The translated formal logic program sentence is: jenny plays basketball. ### \n The predicate of the sentence is: playBasketball. ### \n The entities of the sentence is: jenny. ### \n The translated formal logic program sentence is: playBasketball(jenny). ### \n For example 6: The translated formal logic program sentence is: jenny doesn't play basketball? ### \n The predicate of the sentence is: playBasketball. ### \n The entities of the sentence is: jenny. ### \n The translated formal logic program sentence is: -playBasketball(jenny). ### \n", "default_reasoning_irr": "### \n For example 1: The natural language sentence to be translated is: cats are mammals. ### \n The predicate of the sentence is: mammals. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: mammals(cats). ### \n For example 2: The natural language sentence to be translated is: dogs are mammals. ### \n The predicate of the sentence is: mammals. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: mammals(dogs). ### \n For example 3: The natural language sentence to be translated is: mammals usually have fur. ### \n The predicate of the sentence is: hasFur. mammals. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: mammals(X) : hasFur(X) / hasFur(X). ### \n For example 4: The natural language sentence to be translated is: cats don't have fur. ### \n The predicate of the sentence is: hasFur. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: -hasFur(cats). ### \n For example 5: The natural language sentence to be translated is: dogs are loyalty. ### \n The predicate of the sentence is: loyalty. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: loyalty(dogs). ### \n For example 6: The natural language sentence to be translated is: dogs don't have fur? ### \n The predicate of the sentence is: fur. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: -hasFur(dogs). ### \n", "default_reasoning_open": "### \n For example 1: The natural language sentence to be translated is: hummingbirds are birds. ### \n The predicate of the sentence is: bird. ### \n The entities of the sentence is: hummingbird. ### \n The translated formal logic program sentence is: bird(hummingbird). ### \n For example 2: The natural language sentence to be translated is: birds migrate south for the winter. ### \n The predicate of the sentence is: migrationSouthForWinter. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: birds(X) : migrationSouthForWinter(X) / migrationSouthForWinter(X). ### \n For example 3: The natural language sentence to be translated is: hummingbirds do not migrate south for the winter. ### \n The predicate of the sentence is: migrationSouthForWinter. ### \n The entities of the sentence is: hummingbird. ### \n The translated formal logic program sentence is: -migrationSouthForWinter(hummingbird). ### \n For example 4: The natural language sentence to be translated is: all other birds than hummingbirds migrate south for the winter? ### \n The predicate of the sentence is: migrationSouthForWinter. ### \n The entities of the sentence is: allOtherBirds. hummingbird. ### \n The translated formal logic program sentence is: birds(allOtherBirds) : / migrationSouthForWinter(allOtherBirds). ### \n For example 5: The natural language sentence to be translated is: all other birds than hummingbirds don't migrate south for the winter? ### \n The predicate of the sentence is: migrationSouthForWinter. ### \n The entities of the sentence is: all_other_birds. ### \n The translated formal logic program sentence is: birds(allOtherBirds) : / - migrationSouthForWinter(allOtherBirds). migrationSouthForWinter(hummingbirds). ### \n ", "default_reasoning_several": "### \n For example 1: The natural language sentence to be translated is: john is parents. ### \n The predicate of the sentence is: parents. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: parents(john). ### \n For example 2: The natural language sentence to be translated is: parents are usually loving and supportive. ### \n The predicate of the sentence is: parents. lovingSupportive. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: parents(X) : lovingSupportive(X) / lovingSupportive(X). ### \n For example 3: The natural language sentence to be translated is: parents are normally responsible. ### \n The predicate of the sentence is: parents. responsible. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: parents(X) : responsible(X) / responsible(X). ### \n For example 4: The natural language sentence to be translated is: mary isn't loving and supportive. ### \n The predicate of the sentence is: lovingSupportive. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: -lovingSupportive(mary). ### \n For example 5: The natural language sentence to be translated is: john is not responsible. ### \n The predicate of the sentence is: responsible. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: -responsible(john). ### \n For example 6: The natural language sentence to be translated is: mary is responsible and john is loving and supportive? ### \n The predicate of the sentence is: responsible. loving. supportive. ### \n The entities of the sentence is: mary. john. ### \n The translated formal logic program sentence is: responsible(mary). lovingSupportive(john). ### \n For example 7: The natural language sentence to be translated is: mary isn't responsible and john is loving and supportive? ### \n The predicate of the sentence is: responsible. loving. supportive. ### \n The entities of the sentence is: mary. john. ### \n The translated formal logic program sentence is: -responsible(mary). lovingSupportive(john). ### \n", "reasoning_about_exceptions_1": "### \n For example 1: The natural language sentence to be translated is: cats, dogs, and horses are animals. ### \n The predicate of the sentence is: animals. ### \n The entities of the sentence is: cats. dogs. horses. ### \n The translated formal logic program sentence is: animals(cats). animals(dogs). animals(horses). ### \n For example 2: The natural language sentence to be translated is: animals are usually intelligent. ### \n The predicate of the sentence is: intelligent. animals. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: animals(X) : intelligent(X) / intelligent(X). ### \n For example 3: The natural language sentence to be translated is: at least one of cats or dogs is not considered intelligent. ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: cats. dogs. ### \n The translated formal logic program sentence is: -intelligent(cats). -intelligent(dogs). ### \n For example 4: The natural language sentence to be translated is: horses are intelligent and exactly one of cats or dogs is not intelligent? ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: horses. cats. dogs. ### \n The translated formal logic program sentence is: intelligent(horses). -intelligent(cats). -intelligent (dogs). ### \n For example 5: The natural language sentence to be translated is: horses aren't intelligent creatures and exactly one of cats or dogs is not intelligent? ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: horses. cats. dogs. ### \n The translated formal logic program sentence is: -intelligent(horses). -intelligent(cats). -intelligent (dogs). ### \n", "reasoning_about_exceptions_2": "### \n For example 1: The natural language sentence to be translated is: cats are usually meow. ### \n The predicate of the sentence is: meow. ### \n The entities of the sentence is: cat. ### \n The translated formal logic program sentence is: cat(X) : meow(X) / meow(X). ### \n For example 2: The natural language sentence to be translated is: one species cat is cat. ### \n The predicate of the sentence is: cat. ### \n The entities of the sentence is: oneSpeciesCat. ### \n The translated formal logic program sentence is: cat(oneSpeciesCat). ### \n For example 3: The natural language sentence to be translated is: one species cat isn’t emitting meows. ### \n The predicate of the sentence is: meow. cat. ### \n The entities of the sentence is: oneSpeciesCat. ### \n The translated formal logic program sentence is: cat(oneSpeciesCat). -meow(oneSpeciesCat). ### \n For example 4: The natural language sentence to be translated is: one species cat doesn't meow? ### \n The predicate of the sentence is: meowing. ### \n The entities of the sentence is: oneSpeciesCat. ### \n The translated formal logic program sentence is: -meow(oneSpeciesCat). ### \n For example 5: The natural language sentence to be translated is: exactly one species of cat meow? ### \n The predicate of the sentence is: meow. ### \n The entities of the sentence is: oneSpeciesCat. ### \n The translated formal logic program sentence is: meow(oneSpeciesCat). ### \n", "reasoning_about_exceptions_3": "### \n For example 1: The natural language sentence to be translated is: The wheels are wheels. ### \n The predicate of the sentence is: wheels. ### \n The entities of the sentence is: wheels. ### \n The translated formal logic program sentence is: wheels(wheels). ### \n For example 2: The natural language sentence to be translated is: cars have wheels. ### \n The predicate of the sentence is: wheels. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: wheels(cars). ### \n For example 3: The natural language sentence to be translated is: wheels usually have spokes. ### \n The predicate of the sentence is: wheels. spokes. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: wheels(X) : spokes(X) / spokes(X). ### \n For example 4: The natural language sentence to be translated is: one wheel does not have spokes. ### \n The predicate of the sentence is: spokes. ### \n The entities of the sentence is: oneWheel. ### \n The translated formal logic program sentence is: -spokes(oneWheel). ### \n For example 5: The natural language sentence to be translated is: cars have spokes? ### \n The predicate of the sentence is: spoke. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: spokes(cars). ### \n For example 5: The natural language sentence to be translated is: cars don't have spokes? ### \n The predicate of the sentence is: spokes. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: -spokes(cars). ### \n", "reasoning_about_priority": "### \n For example 1: The natural language sentence to be translated is: john asserts that sally was in the store. ### \n The predicate of the sentence is: asserts. inStore. ### \n The entities of the sentence is: john. sally. store. ### \n The translated formal logic program sentence is: asserts(john, inStore(sally)). asserts(john, inStore(sally)) : -reliable(_,john) / inStore(sally). ### \n For example 2: The natural language sentence to be translated is: jane asserts that sally was not in the store. ### \n The predicate of the sentence is: asserts. present. ### \n The entities of the sentence is: jane. john. sally. ### \n The translated formal logic program sentence is: asserts(jane, -inStore(sally)). asserts(jane, -inStore(sally)) : -reliable(_,jane) / -inStore(sally). ### \n For example 3: The natural language sentence to be translated is: john is more reliable than jane. ### \n The predicate of the sentence is: reliable. ### \n The entities of the sentence is: jane. john. ### \n The translated formal logic program sentence is: reliable(john, jane). ### \n For example 4: The natural language sentence to be translated is: john is less reliable than jane. ### \n The predicate of the sentence is: reliable. ### \n The entities of the sentence is: jane. john. ### \n The translated formal logic program sentence is: reliable(jane, john). ### \n For example 5: The natural language sentence to be translated is: sally was in the store? ### \n The predicate of the sentence is: present. ### \n The entities of the sentence is: sally. store. ### \n The translated formal logic program sentence is: inStore(sally). ### \n For example 6: The natural language sentence to be translated is: sally wasn't in the store? ### \n The predicate of the sentence is: present. ### \n The entities of the sentence is: sally. ### \n The translated formal logic program sentence is: -inStore(sally). ### \n"}
LogicBench_DL_Allatonce_Example_Dict_from_Test ={"default_reasoning_default": "For example 1: The natural language sentence to be translated is: jenny is tall stature. anna is tall stature. tall stature is often playing basketball. anna doesn't play basketball. jenny plays basketball. ### \n The predicate of the sentence is: tallStature. playingBasketball. ### \n The entities of the sentence is: jenny. anna. ### \n The translated formal logic program sentence is: tallStature(jenny). tallStature(anna). tallStature(anna). tallStature(X): playingBasketball(X) / playingBasketball(X). ### \n For example 2: The translated formal logic program sentence is: jenny doesn't play basketball? ### \n The predicate of the sentence is: playingBasketball. ### \n The entities of the sentence is: jenny. ### \n The translated formal logic program sentence is: -playingBasketball(jenny). ### \n", "default_reasoning_irr": "### \n For example 1: The natural language sentence to be translated is: mammalian creatures is animal. cats are mammalian creatures. dogs are mammalian creatures. Mammals typically possessed a coat of fur. fur can keep them warm and protected. cats lacked fur. ### \n The predicate of the sentence is: animals. mammalianCreatures. hasFur. keepWarm. ### \n The entities of the sentence is: dogs. cats. ### \n The translated formal logic program sentence is: mammalianCreatures(X): animals(X) / animals(X). mammalianCreatures(cats). mammalianCreatures(dogs). mammals(X): hasFur(X) / hasFur(X). hasFur(X): keepWarm (X) / keepWarm(X). ### \n For example 2: The natural language sentence to be translated is: dogs have fur? ### \n The predicate of the sentence is: hasFur. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: hasFur(dogs). ### \n For example 3: The natural language sentence to be translated is: dogs don't have fur? ### \n The predicate of the sentence is: hasFur. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: -hasFur (dogs). ### \n", "default_reasoning_open": "### \n For example 1: The natural language sentence to be translated is: hummingbird is bird. most birds engage in the annual migration south for the winter. hummingbird chooses to stay put and brave the cold weather. ### \n The predicate of the sentence is: ### \n The translated formal logic program sentence is: ### \n For example 2: The natural language sentence to be translated is: all other birds than hummingbirds migrate south for the winter? ### \n The predicate of the sentence is: migrationSouthforWinter. ### \n The entities of the sentence is: birds. hummingbirds. ### \n The translated formal logic program sentence is: bird(hummingbird). birds(X): migrationSouthforWinter(X) / migrationSouthforWinter (X). - migrationSouthforWinter(hummingbird). ### \n For example 3: The natural language sentence to be translated is: all other birds than hummingbirds don't migrate south for the winter? ### \n The predicate of the sentence is: migrationSouthforWinter. ### \n The entities of the sentence is: all_other_birds. ### \n The translated formal logic program sentence is: birds(all_other_birds) : / migrationSouthforWinter(all_other_birds). ### \n ", "default_reasoning_several": "### \n For example 1: The natural language sentence to be translated is: john and mary were expecting their first child. john and mary are parents. Parents are usually loving and supportive. Parents are normally responsible. mary seemed distant and uninvolved. John started neglecting his duties and became unreliable. ### \n The predicate of the sentence is: parents. loving. supportive. responsible. ### \n The entities of the sentence is: john. mary. ### \n The translated formal logic program sentence is: parents(john). parents(mary). parents(X): loving(X) / loving(X). parents(X): supportive(X) / supportive(X). parents(X): responsible(X) / responsible(X). -loving(mary). -supportive(mary). -responsible(john). ### \n For example 2: The natural language sentence to be translated is: mary is responsible and john is loving and supportive? ### \n The predicate of the sentence is: responsible. loving. supportive. ### \n The entities of the sentence is: mary. john. ### \n The translated formal logic program sentence is: responsible(mary). loving(john). supportive(john). ### \n For example 3: The natural language sentence to be translated is: mary isn't responsible and john is loving and supportive? ### \n The predicate of the sentence is: responsible. loving. supportive. ### \n The entities of the sentence is: mary. john. ### \n The translated formal logic program sentence is: -responsible(mary). loving(john). supportive(john). ### \n", "reasoning_about_exceptions_1": "### \n For example 1: The natural language sentence to be translated is: cats, dogs, and horses are animals. most animals possess a level of intellect. Cats and dogs are not considered particularly intelligent. ### \n The predicate of the sentence is: animals. intelligent. ### \n The entities of the sentence is: cats. dogs. horses. ### \n The translated formal logic program sentence is: animals(cats). animals(dogs). animals(horses). animals(X): intelligent(X) / intelligent(X). -intelligent(cats). -intelligent(dogs). intelligent(horses). -intelligent(cats) | -intelligent (dogs). ### \n For example 2: The natural language sentence to be translated is: horses are considered to be intelligent creatures and exactly one of cats or dogs is not considered intelligent? ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: horses. cats. dogs. ### \n The translated formal logic program sentence is: intelligent(horses). -intelligent(cats) | -intelligent (dogs). ### \n For example 3: The natural language sentence to be translated is: horses aren't considered to be intelligent creatures and exactly one of cats or dogs is not considered intelligent? ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: horses. cats. dogs. ### \n The translated formal logic program sentence is: -intelligent(horses). -intelligent(cats) | -intelligent (dogs). ### \n", "reasoning_about_exceptions_2": "### \n For example 1: The natural language sentence to be translated is: cat usually is meowing. a distinct species cat is cat. a distinct species cat isn’t emitting meows. ### \n The predicate of the sentence is: meowing. ### \n The entities of the sentence is: a_distinct_species_cat. ### \n The translated formal logic program sentence is: cat(X) : meowing(X) / meowing(X). cat(a_distinct_species_cat). -meowing(a_distinct_species_cat). ### \n For example 2: The natural language sentence to be translated is: exactly one species of cat doesn't meow? ### \n The predicate of the sentence is: meowing. ### \n The entities of the sentence is: a_distinct_species_cat. ### \n The translated formal logic program sentence is: -meowing(a_distinct_species_cat). ### \n For example 3: The natural language sentence to be translated is: exactly one species of cat meow? ### \n The predicate of the sentence is: meowing. ### \n The entities of the sentence is: a_distinct_species_cat. ### \n The translated formal logic program sentence is: meowing(a_distinct_species_cat). ### \n", "reasoning_about_exceptions_3": "### \n For example 1: The natural language sentence to be translated is: cars typically have four wheels. wheels typically came equipped with spokes. At least one wheel not having any spokes. ### \n The predicate of the sentence is: hasFourWheels. AllWheelsSpoked. ### \n The entities of the sentence is: cars. X. c1. ### \n The translated formal logic program sentence is: Cars(X) : hasFourWheels(X) / hasFourWheels(X). hasFourWheels(X) : AllWheelsSpoked(X) / AllWheelsSpoked(X). Cars(c1). -AllWheelsSpoked(c1). ### \n For example 2: The natural language sentence to be translated is: cars have four wheels with spokes? ### \n The predicate of the sentence is: hasFourWheels. AllWheelsSpoked. ### \n The entities of the sentence is: c1. ### \n The translated formal logic program sentence is: hasFourWheels(c1). AllWheelsSpoked(c1). ### \n For example 3: The natural language sentence to be translated is: cars don't have four wheels with spokes? ### \n The predicate of the sentence is: hasFourWheels. AllWheelsSpoked. ### \n The entities of the sentence is: c1. ### \n The translated formal logic program sentence is: -hasFourWheels(c1). -AllWheelsSpoked(c1). ### \n", "reasoning_about_priority": "### \n For example 1: The natural language sentence to be translated is: john adamantly claims that sally was present at the store. Jane strongly insisting that sally was indeed absent from the store. john's evidence is more reliable than jane's. ### \n The predicate of the sentence is: present. claims. claims. reliable. ### \n The entities of the sentence is: john. sally. X. ### \n The translated formal logic program sentence is: claims(john, present(sally, store)). claims(john, present(sally, store)) : present(sally, store) / present(sally, store). claims(jane, ¬present(sally, store)). claims(jane, ¬present(sally, store)) : ¬present(sally, store) / ¬present(sally, store). reliable(john, jane). present(sally, store). ### \n For example 2: The natural language sentence to be translated is: sally was in the store? ### \n The predicate of the sentence is: present. ### \n The entities of the sentence is: sally. ### \n The translated formal logic program sentence is: present(sally, store). ### \n For example 3: The natural language sentence to be translated is: sally wasn't in the store? ### \n The predicate of the sentence is: present. ### \n The entities of the sentence is: sally. store. ### \n The translated formal logic program sentence is: -present(sally, store). ### \n"}

LogicBench_ASP_Onebyone_Example_Dict_from_Test ={"default_reasoning_default": "For example 1: The natural language sentence to be translated is: jenny are tall. ### \n The predicate of the sentence is: tall. ### \n The entities of the sentence is: jenny. ### \n The translated formal logic program sentence is: tall(jenny). For example 2: The natural language sentence to be translated is: anna are tall. ### \n The predicate of the sentence is: tall. ### \n The entities of the sentence is: anna. ### \n The translated formal logic program sentence is: tall(anna). For example 3: The natural language sentence to be translated is: tall people usually play basketball. ### \n The predicate of the sentence is: tall. playBasketball. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: tall(anna). playBasketball(X) :- tall(X), not -playBasketball(X). ### \n For example 4: The natural language sentence to be translated is: anna is not plays basketball. ### \n The predicate of the sentence is: playBasketball. ### \n The entities of the sentence is: anna. ### \n The translated formal logic program sentence is: -playBasketball(anna). ### \n For example 5: The translated formal logic program sentence is: jenny plays basketball. ### \n The predicate of the sentence is: playBasketball. ### \n The entities of the sentence is: jenny. ### \n The translated formal logic program sentence is: playBasketball(jenny). ### \n For example 6: The translated formal logic program sentence is: jenny doesn't play basketball? ### \n The predicate of the sentence is: playBasketball. ### \n The entities of the sentence is: jenny. ### \n The translated formal logic program sentence is: -playBasketball(jenny). ### \n", "default_reasoning_irr": "### \n For example 1: The natural language sentence to be translated is: cats are mammals. dogs are loyalty. ### \n The predicate of the sentence is: mammals. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: mammals(cats). ### \n For example 2: The natural language sentence to be translated is: dogs are mammals. ### \n The predicate of the sentence is: dogs. mammals. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: mammals(dogs). ### \n For example 3: The natural language sentence to be translated is: mammals usually have fur. ### \n The predicate of the sentence is: fur. mammals. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: fur(X) :- mammals(X), not -fur(X). ### \n For example 4: The natural language sentence to be translated is: cats don't have fur. ### \n The predicate of the sentence is: fur. ### \n The entities of the sentence is: cats. ### \n The translated formal logic program sentence is: -fur(cats). ### \n For example 5: The natural language sentence to be translated is: dogs are loyalty. ### \n The predicate of the sentence is: loyalty. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: loyalty(dogs). ### \n For example 6: The natural language sentence to be translated is: dogs don't have fur? ### \n The predicate of the sentence is: fur. ### \n The entities of the sentence is: dogs. ### \n The translated formal logic program sentence is: -fur(dogs). ### \n", "default_reasoning_open": "### \n For example 1: The natural language sentence to be translated is: hummingbirds are birds. ### \n The predicate of the sentence is: bird. ### \n The entities of the sentence is: hummingbird. ### \n The translated formal logic program sentence is: bird(hummingbird). ### \n For example 2: The natural language sentence to be translated is: birds migrate south for the winter. ### \n The predicate of the sentence is: migration_south_for_the_winter. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: migration_south_for_the_winter(X) :- birds(X), not -migration_south_for_the_winter(X). ### \n For example 3: The natural language sentence to be translated is: hummingbirds do not migrate south for the winter. ### \n The predicate of the sentence is: migration_south_for_the_winter. ### \n The entities of the sentence is: hummingbird. ### \n The translated formal logic program sentence is: -migration_south_for_the_winter(hummingbird). ### \n For example 4: The natural language sentence to be translated is: all other birds than hummingbirds migrate south for the winter? ### \n The predicate of the sentence is: migrate_south_for_the_winter. ### \n The entities of the sentence is: all_other_birds. hummingbird. ### \n The translated formal logic program sentence is: migration_south_for_the_winter(all_other_birds) :- birds(all_other_birds). ### \n For example 5: The natural language sentence to be translated is: all other birds than hummingbirds don't migrate south for the winter? ### \n The predicate of the sentence is: migration_south_for_the_winter. ### \n The entities of the sentence is: all_other_birds. ### \n The translated formal logic program sentence is: -migration_south_for_the_winter(all_other_bird) :- birds(all_other_birds). migration_south_for_the_winter(hummingbirds). ### \n ", "default_reasoning_several": "### \n For example 1: The natural language sentence to be translated is: john are parents. ### \n The predicate of the sentence is: parents. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: parents(john). ### \n For example 2: The natural language sentence to be translated is: parents are usually loving and supportive. ### \n The predicate of the sentence is: parents. lovingSupportive. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: lovingSupportive(X) :- parents(X), not - lovingSupportive(X). ### \n For example 3: The natural language sentence to be translated is: parents are normally responsible. ### \n The predicate of the sentence is: parents. responsible. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: responsible(X) :- parents(X), not -responsible(X). ### \n For example 4: The natural language sentence to be translated is: mary isn't loving and supportive. ### \n The predicate of the sentence is: lovingSupportive. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: -lovingSupportive(mary). ### \n For example 5: The natural language sentence to be translated is: john is not responsible. ### \n The predicate of the sentence is: responsible. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: -responsible(john). ### \n For example 6: The natural language sentence to be translated is: mary is responsible and john is loving and supportive? ### \n The predicate of the sentence is: responsible. lovingSupportive. ### \n The entities of the sentence is: mary. john. ### \n The translated formal logic program sentence is: responsible(mary). lovingSupportive(john). ### \n For example 7: The natural language sentence to be translated is: mary isn't responsible and john is loving and supportive? ### \n The predicate of the sentence is: responsible. lovingSupportive. ### \n The entities of the sentence is: mary. john. ### \n The translated formal logic program sentence is: -responsible(mary). lovingSupportive(john). ### \n", "reasoning_about_exceptions_1": "### \n For example 1: The natural language sentence to be translated is: cats, dogs, and horses are animals. ### \n The predicate of the sentence is: animals. ### \n The entities of the sentence is: cats. dogs. horses. ### \n The translated formal logic program sentence is: animals(cats). animals(dogs). animals(horses). ### \n For example 2: The natural language sentence to be translated is: animals are usually considered to be intelligent creatures. ### \n The predicate of the sentence is: intelligent. animals. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: intelligent(X) :- animals(X), not -intelligent(X). ### \n For example 3: The natural language sentence to be translated is: at least one of cats or dogs is not considered intelligent. ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: cats. dogs. ### \n The translated formal logic program sentence is: -intelligent(cats), -intelligent(dogs). ### \n For example 4: The natural language sentence to be translated is: horses are considered to be intelligent creatures and exactly one of cats or dogs is not considered intelligent? ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: horses. cats. dogs. ### \n The translated formal logic program sentence is: intelligent(horses). -intelligent(cats) | -intelligent (dogs). ### \n For example 5: The natural language sentence to be translated is: horses aren't considered to be intelligent creatures and exactly one of cats or dogs is not considered intelligent? ### \n The predicate of the sentence is: intelligent. ### \n The entities of the sentence is: horses. cats. dogs. ### \n The translated formal logic program sentence is: -intelligent(horses). -intelligent(cats) | -intelligent (dogs). ### \n", "reasoning_about_exceptions_2": "### \n For example 1: The natural language sentence to be translated is: cats usually meow. ### \n The predicate of the sentence is: meow. ### \n The entities of the sentence is: cat. ### \n The translated formal logic program sentence is: meow(X) :-cat(X),not -meow(X). ### \n For example 2: The natural language sentence to be translated is: a distinct species cat is cat. ### \n The predicate of the sentence is: cat. ### \n The entities of the sentence is: a_distinct_species_cat ### \n The translated formal logic program sentence is: cat(a_distinct_species_cat). ### \n For example 3: The natural language sentence to be translated is: a distinct species cat isn’t emitting meows. ### \n The predicate of the sentence is: meow. ### \n The entities of the sentence is: a_distinct_species_cat. ### \n The translated formal logic program sentence is: -meow(a_distinct_species_cat). ### \n For example 4: The natural language sentence to be translated is: exactly one species of cat doesn't meow? ### \n The predicate of the sentence is: meow. ### \n The entities of the sentence is: a_distinct_species_cat. ### \n The translated formal logic program sentence is: -meow(a_distinct_species_cat). ### \n For example 5: The natural language sentence to be translated is: exactly one species of cat meow? ### \n The predicate of the sentence is: meow. ### \n The entities of the sentence is: a_distinct_species_cat. ### \n The translated formal logic program sentence is: meow(a_distinct_species_cat). ### \n", "reasoning_about_exceptions_3": "### \n For example 1: The natural language sentence to be translated is: cars have four wheels. ### \n The predicate of the sentence is: wheels. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: wheels(cars). ### \n For example 2: The natural language sentence to be translated is: wheels normally have spokes. ### \n The predicate of the sentence is: wheels. spokes. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: spokes(X) :- wheels(X), not -spokes(X). ### \n For example 3: The natural language sentence to be translated is: at least one wheel does not have spokes. ### \n The predicate of the sentence is: spokes. ### \n The entities of the sentence is: oneWheel. ### \n The translated formal logic program sentence is: -spokes(oneWheel). ### \n For example 4: The natural language sentence to be translated is: cars have four wheels with spokes? ### \n The predicate of the sentence is: spoke. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: spokes(cars). ### \n For example 5: The natural language sentence to be translated is: cars don't have four wheels with spokes? ### \n The predicate of the sentence is: spokes. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: -spokes(cars). ### \n", "reasoning_about_priority": "### \n For example 1: The natural language sentence to be translated is: john asserts that sally was in the store. ### \n The predicate of the sentence is: asserts. inStore. ### \n The entities of the sentence is: john. sally. store. ### \n The translated formal logic program sentence is: asserts(john, inStore(sally)). inStore(sally) :- asserts(john, inStore(sally)), not reliable(_,john). ### \n For example 2: The natural language sentence to be translated is: jane asserts that sally was not in the store. ### \n The predicate of the sentence is: asserts. present. ### \n The entities of the sentence is: jane. john. sally. ### \n The translated formal logic program sentence is: asserts(jane, -inStore(sally)). -inStore(sally) :- asserts(jane, -inStore(sally)), not reliable (_,jane). ### \n For example 3: The natural language sentence to be translated is: john's evidence is more reliable than jane's. ### \n The predicate of the sentence is: reliable. ### \n The entities of the sentence is: jane. john. ### \n The translated formal logic program sentence is: reliable(john, jane). inStore(sally). ### \n For example 4: The natural language sentence to be translated is: sally was in the store? ### \n The predicate of the sentence is: present. ### \n The entities of the sentence is: sally. store. ### \n The translated formal logic program sentence is: inStore(sally). ### \n For example 5: The natural language sentence to be translated is: sally wasn't in the store? ### \n The predicate of the sentence is: present. ### \n The entities of the sentence is: sally. ### \n The translated formal logic program sentence is: -inStore(sally). ### \n"}
LogicEvalD1_DL_onebyone_Example_Dict_from_Test ={"default_reasoning_default": "For example 1: The natural language sentence to be translated is: John and Maria are students in math class. ### \n The predicate of the sentence is: take_test. student. ### \n The entities of the sentence is: john. maria. ### \n The translated formal logic program sentence is: student(john). student(maria). ### \n For example 2: The natural language sentence to be translated is: Typically students in math class take tests. ### \n The predicate of the sentence is: take_test. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: student(X) : take_test(X) / take_test(X). ### \n For example 3: The natural language sentence to be translated is: John sometimes skips tests even when assigned. ### \n The predicate of the sentence is: take_test. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: -take_test(john). ### \n For example 4: The natural language sentence to be translated is: Maria takes tests. ### \n The predicate of the sentence is: take_test. ### \n The entities of the sentence is: maria. ### \n The translated formal logic program sentence is: take_test(maria). ### \n", "default_reasoning_irr": "### \n For example 1: The natural language sentence to be translated is: Emma and Jacob are students. ### \n The predicate of the sentence is: students. high_GPAs. academic_scholarships. sports_scholarships. ### \n The entities of the sentence is: emma. jacob. ### \n The translated formal logic program sentence is: students(emma). students(jacob). students(X), sports_scholarships(jacob). ### \n For example 2: The natural language sentence to be translated is: Usually students with high GPAs get academic scholarships. ### \n The predicate of the sentence is: high_GPAs. academic_scholarships. ### \n The entities of the sentence is: Jacob. ### \n The translated formal logic program sentence is: high_GPAs(X): academic_scholarships(X) / academic_scholarships(X). ### \n For example 3: The natural language sentence to be translated is: Emma does not have an academic scholarship. ### \n The predicate of the sentence is: academic_scholarships ### \n The entities of the sentence is: emma. ### \n The translated formal logic program sentence is: -academic_scholarships(emma).. ### \n For example 4: The natural language sentence to be translated is: Jacob has an academic scholarship. ### \n The predicate of the sentence is: academic_scholarships ### \n The entities of the sentence is: Jacob. ### \n The translated formal logic program sentence is: academic_scholarships(Jacob). ### \n For example 5: The natural language sentence to be translated is: Jacob has an academic scholarship. ### \n The predicate of the sentence is: academic_scholarships ### \n The entities of the sentence is: Jacob. ### \n The translated formal logic program sentence is: academic_scholarships(Jacob). ### \n", "default_reasoning_open": "### \n For example 1: The natural language sentence to be translated is: In a quaint town, there is a specific apple tree named Golden Glory that is known for producing golden apples. ### \n The predicate of the sentence is: tree. produce_golden_apples. ### \n The entities of the sentence is: apple_tree. golden_glory. ### \n The translated formal logic program sentence is: tree(apple_tree). tree(golden_glory). produce_golden_apples(golden_glory). ### \n For example 2: The natural language sentence to be translated is: It is commonly known that trees which produce golden apples tend to also have sweet fruit. ### \n The predicate of the sentence is: sweet_fruit. produce_golden_apples. ### \n The entities of the sentence is: golden_glory. ### \n The translated formal logic program sentence is: tree(X), produce_golden_apples(X) : sweet_fruit(X) / sweet_fruit(X). ### \n For example 3: The natural language sentence to be translated is: However, Golden Glorys apples, despite being golden, are surprisingly tart. ### \n The predicate of the sentence is: surprisingly_tart. ### \n The entities of the sentence is: golden_glory. ### \n The translated formal logic program sentence is: surprisingly_tart(golden_glory). ### \n For example 4: The natural language sentence to be translated is: all apple trees in this town that produce golden apples, other than Golden Glory, have sweet fruit? ### \n The predicate of the sentence is: sweet_fruit ### \n The entities of the sentence is: apple_tree. golden_glory. ### \n The translated formal logic program sentence is: sweet_fruit(apple_tree). -sweet_fruit(golden_glory). ### \n", "default_reasoning_several": "### \n For example 1: The natural language sentence to be translated is: In a world where certain flowers can bloom in sunlight, usually those blooming in sunlight also attract bees. ### \n The predicate of the sentence is: companies. bloom_in_sunlight. attract_bees. ### \n The entities of the sentence is: flowers. innovateinc. ### \n The translated formal logic program sentence is: bloom_in_sunlight(flowers). bloom_in_sunlight(X) : attract_bees(X) / attract_bees(X). ### \n For example 2: The natural language sentence to be translated is: Moreover, these flowers tend to be fragrant. ### \n The predicate of the sentence is: fragrant. ### \n The entities of the sentence is: flowers. ### \n The translated formal logic program sentence is: -fragrant(flowers). ### \n For example 3: The natural language sentence to be translated is: Daisy does not attract bees, while Rose is not fragrant. ### \n The predicate of the sentence is: attract_bees. fragrant. ### \n The entities of the sentence is: daisy. rose. ### \n The translated formal logic program sentence is:-attract_bees(daisy). flowers(daisy). -fragrant(rose). flowers(rose). ### \n For example 4: The natural language sentence to be translated is: Rose attracts bees and Daisy is fragrant? ### \n The predicate of the sentence is: attract_bees. fragrant. ### \n The entities of the sentence is: rose. daisy. ### \n The translated formal logic program sentence is: attract_bees(rose). -fragrant(daisy). ### \n", "reasoning_about_exceptions_1": "### \n For example 1: The natural language sentence to be translated is: John, Jane, and Robert are all musicians in a local band. ### \n The predicate of the sentence is: musicians. play_guitar. play_drums. play_bass. play_instruments. sing_lead_vocal. ### \n The entities of the sentence is: john. jane. robert. ### \n The translated formal logic program sentence is: musicians(john). musicians(jane). musicians(robert).  ### \n For example 2: The natural language sentence to be translated is: They often play various instruments like guitar, drums, and bass at their shows. ### \n The predicate of the sentence is: play_instruments. play_guitar. play_drums. play_drums. ### \n The entities of the sentence is: robert. john. jane. ### \n The translated formal logic program sentence is: play_guitar(X): / play_instruments(X). play_drums(X): / play_instruments(X). play_bass(X): / play_instruments(X). play_drums(X): play_instruments(X) / play_instruments(X). ### \n For example 3: The natural language sentence to be translated is: However, at their next gig, either John or Jane will not be playing an instrument. ### \n The predicate of the sentence is: play_instruments. ### \n The entities of the sentence is: john. jane. ### \n The translated formal logic program sentence is: -play_instruments(john) | -play_instruments(jane). ### \n For example 4: The natural language sentence to be translated is: Instead, one of them will be singing lead vocals while the other two play their instruments. ### \n The predicate of the sentence is: sing_lead_vocal. vitamins. ### \n The entities of the sentence is: robert. john. jane. ### \n The translated formal logic program sentence is: sing_lead_vocal(john) | sing_lead_vocal(jane) | sing_lead_vocal(robert). ### \n For example 5: The natural language sentence to be translated is: The band likes to switch up their roles sometimes to keep their performances fresh and interesting. ### \n The predicate of the sentence is: switch_up_thir_role. keep_fresh_interesting. ### \n The entities of the sentence is: band. performances. ### \n The translated formal logic program sentence is: switch_up_thir_role(band) : keep_fresh_interesting(performances) / keep_fresh_interesting(performances). ### \n For example 6: The natural language sentence to be translated is: robert is playing an instrument and exactly one of john or jane is not playing an instrument? ### \n The predicate of the sentence is: play_instruments. vitamins. ### \n The entities of the sentence is: robert. john. jane. ### \n The translated formal logic program sentence is: play_instruments(robert). -play_instruments(john) | -play_instruments(jane). ### \n For example 7: The natural language sentence to be translated is: Even though John or Jane won't play an instrument this time, they are still contributing as musicians through their singing. ### \n The predicate of the sentence is: play_instruments. vitamins. musicians. ### \n The entities of the sentence is: john. jane. ### \n The translated formal logic program sentence is: -play_instruments(john) | -play_instruments(jane). -play_instruments(X) : singing(X) / - singing(X). ### \n For example 8: The natural language sentence to be translated is: Robert will play his usual guitar parts to accompany the lead vocals. ### \n The predicate of the sentence is: play_guitar. ### \n The entities of the sentence is: robert. ### \n The translated formal logic program sentence is: play_guitar(robert). ### \n For example 9: The natural language sentence to be translated is: robert is playing an instrument and exactly one of john or jane is not playing an instrument? ### \n The predicate of the sentence is: play_instruments. vitamins. ### \n The entities of the sentence is: robert. john. jane. ### \n The translated formal logic program sentence is: play_instruments(robert). -play_instruments(john) | -play_instruments(jane). ### \n", "reasoning_about_exceptions_2": "### \n For example 1: The natural language sentence to be translated is: John was at the grocery store picking out some apples. ### \n The predicate of the sentence is: red_apple. green_apple. apple. green. red. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: red_apple(dozen_apple). green_apple(one_apple). apple(red_apple). ### \n For example 2: The natural language sentence to be translated is: He grabbed a bag and started putting in the bright red apples that caught his eye. ### \n The predicate of the sentence is: grabbed_bag. put_red_apples. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: grabbed_bag(john). put_red_apples(john). ### \n For example 3: The natural language sentence to be translated is: After filling the bag with a dozen red apples, he noticed a bin with green apples. ### \n The predicate of the sentence is: noticed_green_apple. dozen_red_apple. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: dozen_red_apple(bag). noticed_green_apple(john). ### \n For example 4: The natural language sentence to be translated is: Intrigued, he picked one up and examined it. ### \n The predicate of the sentence is: pick_on_green_apple. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: pick_one_green_apple(john). ### \n For example 5: The natural language sentence to be translated is: Even though apples are usually red, this apple was a deep green color. ### \n The predicate of the sentence is: apple. red. ### \n The entities of the sentence is: one_apple. ### \n The translated formal logic program sentence is: apple(X) : red(X) / red(X). green_color(green_apple). green_color(X) : -red(X) / -red(X). apple(green_apple). ### \n For example 6: The natural language sentence to be translated is: John was curious about how it would taste compared to the red apples, so he decided to purchase one green apple along with his bag of red ones. ### \n The predicate of the sentence is: purchase_one_green_apple. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: purchase_one_green_apple(john). ### \n For example 7: The natural language sentence to be translated is: When John got home, he was eager to try the unique green apple and see if the flavor was any different from what he was used to. ### \n The predicate of the sentence is: try_green_apple. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: -try_green_apple(john). ### \n For example 8: The natural language sentence to be translated is: exactly one apple is not red? ### \n The predicate of the sentence is: red. ### \n The entities of the sentence is: one_apple. ### \n The translated formal logic program sentence is: -red(one_apple). ### \n", "reasoning_about_exceptions_3": "### \n For example 1: The natural language sentence to be translated is: John was walking through the parking lot at his local supermarket. ### \n The predicate of the sentence is: walk_at_supermarket. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: walk_at_supermarket(john). ### \n For example 2: The natural language sentence to be translated is: As he glanced around at the rows of vehicles, he noticed that most of the cars were red in color. ### \n The predicate of the sentence is: red_car ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: red_car(cars). ### \n For example 3: The natural language sentence to be translated is: From experience, John knew that red cars typically had four wheels. ### \n The predicate of the sentence is: red_car. four_wheels. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: red_car(X): four_wheels(X) / four_wheels(X). ### \n For example 4: The natural language sentence to be translated is: However, as John scanned the lot, he spotted a red three-wheeled vehicle parked in the back. ### \n The predicate of the sentence is: red_car. ### \n The entities of the sentence is: red_three_wheeled. ### \n The translated formal logic program sentence is: red_car(red_three_wheeled). ### \n For example 5: The natural language sentence to be translated is: John thought Most red cars have four wheels, but this unusual red vehicle only has three. ### \n The predicate of the sentence is: four_wheels. ### \n The entities of the sentence is: red_car. ### \n The translated formal logic program sentence is: red_car(X): four_wheels(X) / four_wheels(X). ### \n For example 6: The natural language sentence to be translated is: John was intrigued by the sight of the atypical red three-wheeler amidst the sea of typical four-wheeled red cars in the lot. ### \n The predicate of the sentence is: four_wheels. ### \n The entities of the sentence is: red_three_wheeled. ### \n The translated formal logic program sentence is: -four_wheels(red_three_wheeled). ### \n For example 7: The natural language sentence to be translated is: It made him realize that even broad generalizations about things like red cars having four wheels don't always apply to every single case. ### \n The predicate of the sentence is: four_wheels. ### \n The entities of the sentence is: all_red_cars. ### \n The translated formal logic program sentence is: -four_wheels(all_red_cars). ### \n For example 8: The natural language sentence to be translated is: cars have four wheels? ### \n The predicate of the sentence is: four_wheels. ### \n The entities of the sentence is: cars. ### \n The translated formal logic program sentence is: four_wheels(cars). ### \n", "reasoning_about_priority": "### \n For example 1: The natural language sentence to be translated is: John and Emily were having a friendly debate about the composition of the moon. ### \n The predicate of the sentence is: debate_moon e. ### \n The entities of the sentence is: john. emily. ### \n The translated formal logic program sentence is:  debate_moon(john, emily). ### \n For example 2: The natural language sentence to be translated is: John insisted that the moon must be made of cheese, being silly and fanciful in his argument. ### \n The predicate of the sentence is: made_of_cheese. more_reliable. ### \n The entities of the sentence is: moon. john. ### \n The translated formal logic program sentence is: asserts(john, made_of_cheese(moon)). asserts(john, made_of_cheese(moon)): -more_reliable(_, john) / made_of_cheese(moon).  ### \n For example 3: The natural language sentence to be translated is: However, Emily stated firmly that the moon is definitely not made of cheese, and proceeded to lay out scientific facts about the moon's rocky, cratered surface. ### \n The predicate of the sentence is: made_of_cheese. ### \n The entities of the sentence is: moon. emily. more_reliable. ### \n The translated formal logic program sentence is: asserts(emily, -made_of_cheese(moon)). asserts(emily, -made_of_cheese(moon)) : -more_reliable(_, emily) / -made_of_cheese(moon). ### \n For example 4: The natural language sentence to be translated is: Though they disagreed, John and Emily enjoyed their playful discussion, with Emily taking on the role of the rational scientist and John making outrageous claims just for fun. ### \n The predicate of the sentence is: enjoyed_discussion. ### \n The entities of the sentence is: emily. ### \n The translated formal logic program sentence is: enjoyed_discussion(john). enjoyed_discussion(emily). ### \n For example 5: The natural language sentence to be translated is: Their lighthearted banter showed that friends can have different perspectives yet still appreciate each other's humor and company. ### \n The predicate of the sentence is: different_perpectives. ### \n The entities of the sentence is: friends. ### \n The translated formal logic program sentence is: different_perpectives(friends). ### \n For example 6: The natural language sentence to be translated is: john's evidence is more reliable than emily's. ### \n The predicate of the sentence is: more_reliable. ### \n The entities of the sentence is: john. emily. ### \n The translated formal logic program sentence is: more_reliable(john, emily). ### \n For example 7: The natural language sentence to be translated is: the moon is not made of cheese? ### \n The predicate of the sentence is: made_of_cheese. ### \n The entities of the sentence is: moon. ### \n The translated formal logic program sentence is: -made_of_cheese(moon). ### \n "}
LogicEvalD2_DL_Allatonce_Example_Dict_from_Test ={"BDR_MP": "For example 1: The natural language sentence to be translated is: jim and pam work at the same office. Normally, employees at that office get free lunch. Jim does not get free lunch. If Pam gets free lunch, then she gets an hour lunch break. ### \n The predicate of the sentence is: employee. work_at. free_lunch. hour_lunch_break. ### \n The entities of the sentence is: jim. pam. ### \n The translated formal logic program sentence is: employee(jim). employee(pam). works_at(jim, office). works_at(pam, office). employee(X), works_at(X, office) :- free_lunch(X) / free_lunch(X). -free_lunch(jim). free_lunch(pam) : hour_lunch_break(pam) / hour_lunch_break(pam). ### \n For example 2: The natural language sentence to be translated is: pam gets an hour lunch break? ### \n The predicate of the sentence is: hour_lunch_break. ### \n The entities of the sentence is: pam. ### \n The translated formal logic program sentence is: hour_lunch_break(pam). ### \n", "BDR_MT": "### \n For example 1: The natural language sentence to be translated is: Emma and Jacob are students in the same class. Usually students in that class submit homework assignments. Emma did not submit the last homework. If Jacob missed over 3 classes, that means he likely did not submit the homework. ### \n The predicate of the sentence is: student. submits_homework. missed_over_3_classes. ### \n The entities of the sentence is: emma. jacob. ### \n The translated formal logic program sentence is: student(emma). student(jacob). student(X) : submits_homework(X) / submits_homework(X). -submits_homework(emma). missed_over_3_classes(jacob) : -submits_homework(jacob) / -submits_homework(jacob). ### \n For example 2: The natural language sentence to be translated is: Jacob missed over 3 classes? ### \n The predicate of the sentence is: missed_over_3_classes. ### \n The entities of the sentence is: jacob. ### \n The translated formal logic program sentence is: missed_over_3_classes (jacob). ### \n", "DRD_MP": "### \n For example 1: The natural language sentence to be translated is: jane and martha are renting apartments in a building. Typically, units in this building with a view of the park have a balcony. Jane's unit has a view of the park. But her unit might not have a balcony even if it has a view. If Martha's apartment has a balcony, then it includes air conditioning. ### \n The predicate of the sentence is: apartments. unit. view_park. have_a_balcony. air_conditioning. ### \n The entities of the sentence is: jane. martha. ### \n The translated formal logic program sentence is: apartments(jane). apartments(martha). apartments(X): unit(X) / unit(X). unit(X): view_park(X) / view_park(X). view_park(X), unit(X) : have_a_balcony(X) / have_a_balcony(X). view_park(jane). -have_a_balcony(jane). have_a_balcony(martha) : air_conditioning(marths) / air_conditioning(marths). ### \n For example 2: The natural language sentence to be translated is: Martha's apartment has air conditioning ### \n The predicate of the sentence is: species. air_conditioning. ### \n The entities of the sentence is: marths. species. ### \n The translated formal logic program sentence is: air_conditioning(marths). ### \n ", "DRD_MT": "### \n For example 1: The natural language sentence to be translated is: John and Mary are students in math class. Normally students in math class take quizzes. John may not take quizzes even though he is in math class. If Mary has debate club during math class, then she does not take quizzes in math class. ### \n The predicate of the sentence is: student. in_math_class. takes_quiz. has_debate_club. ### \n The entities of the sentence is: john. mary. ### \n The translated formal logic program sentence is: student(john). student(mary). in_math_class(john). in_math_class(mary). in_math_class(X), student(X) : takes_quiz(X) / takes_quiz(X). -takes_quiz(john). has_debate_club(mary) : -takes_quiz(mary) / -takes_quiz(mary). ### \n For example 2: The natural language sentence to be translated is: Mary has debate club during math class? ### \n The predicate of the sentence is: has_debate_club. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: has_debate_club(mary). ### \n ", "DRI_MP": "### \n For example 1: The natural language sentence to be translated is: John and Kate are students in the same math class. Usually students in this math class understand algebra. John does not understand algebra. Kate participates in the math club. ### \n The predicate of the sentence is: student. in_math_class. understands_algebra. ### \n The entities of the sentence is: john. kate. ### \n The translated formal logic program sentence is: student(john). student(kate). in_math_class(john). in_math_class(kate). in_math_class(X) : understands_algebra(X)/ understands_algebra(X). -understands_algebra(john). in_math_club(kate). ### \n For example 2: The natural language sentence to be translated is: kate participates in the math club? ### \n The predicate of the sentence is: in_math_club. ### \n The entities of the sentence is: kate. ### \n The translated formal logic program sentence is: in_math_club(kate). ### \n", "DRI_MT": "### \n For example 1: The natural language sentence to be translated is: John and Kate are students in the same class. Usually students in that class play a sport. John does not play a sport. kate sings in the school student. ### \n The predicate of the sentence is: student. play_sport. in_same_class. ### \n The entities of the sentence is: john. kate. ### \n The translated formal logic program sentence is: student(john). student(kate). in_same_class(john, kate). student(X): play_sport(X) / play_sport(X). -play_sport(john). sings_in_school(kate). ### \n For example 2: The natural language sentence to be translated is: kate does not sing in the school choir? ### \n The predicate of the sentence is: sings_in_school. ### \n The entities of the sentence is: kate. ### \n The translated formal logic program sentence is: sings_in_school(kate). ### \n", "PBD_MP": "### \n For example 1: The natural language sentence to be translated is: Jenny said the dog dug up the flower bed. Her brother said the dog did not dig up the flower bed. People usually tell the truth. Jenny is more trustworthy than her brother. If the dog dug up the flowers, it likely made a mess. ### \n The predicate of the sentence is: dug_flowers. more_trustworthy. person. truthful. made_mess. statement. ### \n The entities of the sentence is: dog. jenn. brother ### \n The translated formal logic program sentence is: statement(jenny, dug_flowers(dog)). statement(jenny, dug_flowers(dog)) : more_trustworthy(jenny,_) / dug_flowers(dog). statement(brother, -dug_flowers(dog)). statement(brother, -dug_flowers(dog)) : more_trustworthy(brother,_) / -dug_flowers(dog). person(X): truthful(X) / truthful(X). more_trustworthy(jenny, brother). dug_flowers(dog): made_mess(dog) / made_mess(dog). ### \n For example 2: The natural language sentence to be translated is: dog made a mess? ### \n The predicate of the sentence is: made_mess. ### \n The entities of the sentence is: dog. ### \n The translated formal logic program sentence is: made_mess(dog). ### \n", "PBD_MT": "### \n For example 1: The natural language sentence to be translated is: John said the dog is friendly. Mary said the dog is aggressive. People are usually right when they make such claims. John seems more reliable than Mary. ### \n The predicate of the sentence is: people. said. aggressive. claim. right. more_reliable. ### \n The entities of the sentence is: john. mary. dog. ### \n The translated formal logic program sentence is: people(john). people(mary). said(john, friendly(dog)). said(john, friendly(dog)) : more_reliable(john,_) / friendly(dog). said(mary, aggressive(dog)). said(mary, aggressive(dog)) : more_reliable(mary, _) / aggressive(dog). claim(X) : right(X), people(X) / right(X). more_reliable(john, mary). ### \n For example 2: The natural language sentence to be translated is: the dog is friendly? ### \n The predicate of the sentence is: friendly. ### \n The entities of the sentence is: dog. ### \n The translated formal logic program sentence is: friendly(dog). ### \n ", "REI_MP": "### \n For example 1: The natural language sentence to be translated is: Jake, Emma, and Noah are students who took a math test. Typically, students who study hard for the math test score well. Jake and Emma did not study hard for the test. If Noah scored well on the test, then he must have prepared thoroughly. ### \n The predicate of the sentence is: student. studied_hard. scored_well. prepared_thoroughly. ### \n The entities of the sentence is: jake. emma. noah. ### \n The translated formal logic program sentence is: student(jake). student(emma). student(noah). student(X): studied_hard(X) / studied_hard(X). student(X) : scored_well(X) / scored_well(X). -studied_hard(jake). -studied_hard(emma). scored_well(noah) : prepared_thoroughly(noah) / prepared_thoroughly(noah). ### \n For example 2: The natural language sentence to be translated is: Noah prepared thoroughly for the math test? ### \n The predicate of the sentence is: prepared_thoroughly. ### \n The entities of the sentence is: noah. ### \n The translated formal logic program sentence is: prepared_thoroughly(noah). ### \n", "REI_MT": "### \n For example 1: The natural language sentence to be translated is: John, Mike and Emma are students in the same class. Usually, students in this class submit their assignments on time. John and Mike have submitted one or more assignments late. If Emma has been sick this week, then she likely also submitted an assignment late. ### \n The predicate of the sentence is: student. same_class. scored_well. late_submission. sick_this_week. ### \n The entities of the sentence is: john. emma. mike. ### \n The translated formal logic program sentence is: student(john). student(mike). student(emma). same_class(john). same_class(mike). same_class(emma). student(X), same_class(X): -late_submission(X) / submit_on_time(X). late_submission(john). late_submission(mike). sick_this_week(emma) : late_submission(emma) / late_submission(emma). ### \n For example 2: The natural language sentence to be translated is: emma has been sick this week? ### \n The predicate of the sentence is: sick_this_week. ### \n The entities of the sentence is: emma. ### \n The translated formal logic program sentence is: sick_this_week(emma). ### \n ", "REII_MP": "### \n For example 1: The natural language sentence to be translated is: John bought a new phone. New phones usually come with a warranty. However, some new phones do not come with a warranty. If a phone has a warranty, then it has customer support. ### \n The predicate of the sentence is: new_phone. bought. customer_support. warranty. sick_this_week. ### \n The entities of the sentence is: john. john_phone. mike. ### \n The translated formal logic program sentence is: new_phone(john_phone). new_phone(X) : warranty(X) / warranty(X). new_phone(X) : -warranty(X) / -warranty(X). warranty(X) : customer_support(X) / customer_support(X). ### \n For example 2: The natural language sentence to be translated is: John's new phone has customer support? ### \n The predicate of the sentence is: customer_support. ### \n The entities of the sentence is: john_phone. ### \n The translated formal logic program sentence is: customer_support(john_phone). ### \n ", "REII_MT": "### \n For example 1: The natural language sentence to be translated is: John is a student at school X. Students at school X typically submit their assignments on time. There is at least one student at school X who does not submit assignments on time. If John has been sick this week, then he likely did not submit the assignment on time. ### \n The predicate of the sentence is: student_school_x. submits_on_time. sick_this_week. ### \n The entities of the sentence is: john. john_phone. one_student. ### \n The translated formal logic program sentence is: student_school_x(john). student_school_x(X) : submits_on_time(X) / submits_on_time(X). -submits_on_time(one_student). sick_this_week(john) : -submits_on_time(john) / -submits_on_time(john). ### \n For example 2: The natural language sentence to be translated is: John has been sick this week? ### \n The predicate of the sentence is: sick_this_week. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: sick_this_week(john). ### \n "}
LogicEvalD2_DL_onebyone_Example_Dict_from_Test = {"BDR_MP": "For example 1: The natural language sentence to be translated is: jim and pam work at the same office. ### \n The predicate of the sentence is: employee. works_at_office. free_lunch. hour_lunch_break. ### \n The entities of the sentence is: jim. pam. ### \n The translated formal logic program sentence is: employee(jim). employee(pam). works_at_office(jim). works_at_office(pam). ### \n For example 2: The natural language sentence to be translated is: Normally, employees at that office get free lunch. Jim does not get free lunch. ### \n The predicate of the sentence is: employee. free_lunch. works_at_office. ### \n The entities of the sentence is: X. jim. ### \n The translated formal logic program sentence is: employee(X), works_at_office(X) :- free_lunch(X) / free_lunch(X). -free_lunch(jim). ### \n For example 3: The natural language sentence to be translated is: If Pam gets free lunch, then she gets an hour lunch break. ### \n The predicate of the sentence is: hour_lunch_break. free_lunch. ### \n The entities of the sentence is: pam. ### \n The translated formal logic program sentence is: free_lunch(pam) : hour_lunch_break(pam) / hour_lunch_break(pam). ### \n For example 4: The natural language sentence to be translated is: pam gets an hour lunch break? ### \n The predicate of the sentence is: hour_lunch_break. ### \n The entities of the sentence is: pam. ### \n The translated formal logic program sentence is: hour_lunch_break(pam). ### \n", "BDR_MT": "### \n For example 1: The natural language sentence to be translated is: Emma and Jacob are students in the same class. If Jacob missed over 3 classes, that means he likely did not submit the homework. ### \n The predicate of the sentence is: student. submits_homework. missed_classes. ### \n The entities of the sentence is: emma. jacob. ### \n The translated formal logic program sentence is: student(emma). student(jacob).   ### \n For example 2: The natural language sentence to be translated is: Usually students in that class submit homework assignments. ### \n The predicate of the sentence is: submits_homework. student. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: student(X) : submits_homework(X) / submits_homework(X). ### \n For example 3: The natural language sentence to be translated is: Emma did not submit the last homework. ### \n The predicate of the sentence is: submits_homework. ### \n The entities of the sentence is: emma. ### \n The translated formal logic program sentence is: -submits_homework(emma). ### \n For example 4: The natural language sentence to be translated is: If Jacob missed over 3 classes, that means he likely did not submit the homework. ### \n The predicate of the sentence is: missed_ove_ 3_classes. submits_homework. ### \n The entities of the sentence is: jacob. ### \n The translated formal logic program sentence is: missed_ove_ 3_classes(jacob) : -submits_homework(jacob) / -submits_homework(jacob). ### \n For example 5: The natural language sentence to be translated is: Jacob missed over 3 classes? ### \n The predicate of the sentence is: missed_ove_ 3_classes. ### \n The entities of the sentence is: jacob. ### \n The translated formal logic program sentence is: missed_ove_ 3_classes(jacob). ### \n", "DRD_MP": "### \n For example 1: The natural language sentence to be translated is: jane and martha are renting apartments in a building. Jane's unit has a view of the park. ### \n The predicate of the sentence is: apartments. unit. view_park. have_a_balcony. air_conditioning. ### \n The entities of the sentence is: jane. martha. ### \n The translated formal logic program sentence is: apartments(jane). apartments(martha). apartments(X): unit(X) / unit(X). ### \n For example 2: The natural language sentence to be translated is: Typically, units in this building with a view of the park have a balcony. ### \n The predicate of the sentence is: view_park. unit. have_a_balcony. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: unit(X): view_park(X) / view_park(X). view_park(X), unit(X) : have_a_balcony(X) / have_a_balcony(X). ### \n For example 3: The natural language sentence to be translated is: Jane's unit has a view of the park. ### \n The predicate of the sentence is: species. view_park. ### \n The entities of the sentence is: jane. ### \n The translated formal logic program sentence is: view_park(jane). ### \n For example 4: The natural language sentence to be translated is: But her unit might not have a balcony even if it has a view. ### \n The predicate of the sentence is: have_a_balcony. ## \n The entities of the sentence is: jane. ### \n For example 5: The natural language sentence to be translated is: If Martha's apartment has a balcony, then it includes air conditioning. ### \n The predicate of the sentence is: have_a_balcony. air_conditioning. ## \n The entities of the sentence is: marths. ### \n The translated formal logic program sentence is: have_a_balcony(martha) : air_conditioning(marths) / air_conditioning(marths). ### \n For example 6: The natural language sentence to be translated is: Martha's apartment has air conditioning ### \n The predicate of the sentence is: species. air_conditioning. ### \n The entities of the sentence is: marths. species. ### \n The translated formal logic program sentence is: air_conditioning(marths). ### \n ", "DRD_MT": "### \n For example 1: The natural language sentence to be translated is: John and Mary are students in math class. ### \n The predicate of the sentence is: student. in_math_class. takes_quiz. has_debate_club. ### \n The entities of the sentence is: john. mary. ### \n The translated formal logic program sentence is: student(john). student(mary). in_math_class(john). in_math_class(mary). ### \n For example 2: The natural language sentence to be translated is: Normally students in math class take quizzes. ### \n The predicate of the sentence is: takes_quiz. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: student. student(X) : takes_quiz(X) / takes_quiz(X). ### \n For example 3: The natural language sentence to be translated is: John may not take quizzes even though he is in math class. ### \n The predicate of the sentence is: takes_quiz. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: -takes_quiz(john). ### \n For example 4: The natural language sentence to be translated is: If Mary has debate club during math class, then she does not take quizzes in math class. ### \n The predicate of the sentence is: in_math_class. has_debate_club. takes_quiz. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: in_math_class(X), has_debate_club(mary) : -takes_quiz(mary) / -takes_quiz(mary).### \n For example 5: The natural language sentence to be translated is: Mary has debate club during math class? ### \n The predicate of the sentence is: has_debate_club. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: has_debate_club(mary). ### \n ", "DRI_MP": "### \n For example 1: The natural language sentence to be translated is: John and Kate are students in the same math class. ### \n The predicate of the sentence is: student. in_math_class. understands_algebra. ### \n The entities of the sentence is: john. kate. ### \n The translated formal logic program sentence is: student(john). student(kate). in_math_class(john). in_math_class(kate). ### \n For example 2: The natural language sentence to be translated is: Usually students in this math class understand algebra. ### \n The predicate of the sentence is: student. in_math_class. understands_algebra. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: in_math_class(X), student(X) : understands_algebra(X)/ understands_algebra(X). ### \n For example 3: The natural language sentence to be translated is: John does not understand algebra. ### \n The predicate of the sentence is: understands_algebra. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: -understands_algebra(john). ### \n For example 4: The natural language sentence to be translated is: Kate participates in the math club. ### \n The predicate of the sentence is: in_math_club. ### \n The entities of the sentence is: kate. ### \n The translated formal logic program sentence is: in_math_club(kate).### \n For example 5: The natural language sentence to be translated is: kate participates in the math club? ### \n The predicate of the sentence is: in_math_club. ### \n The entities of the sentence is: kate. ### \n The translated formal logic program sentence is: in_math_club(kate). ### \n", "DRI_MT": "### \n For example 1: The natural language sentence to be translated is: John and Kate are students in the same class. ### \n The predicate of the sentence is: student. play_sport. in_same_class. ### \n The entities of the sentence is: john. kate. ### \n The translated formal logic program sentence is: student(john). student(kate). in_same_class(john, kate). ### \n For example 2: The natural language sentence to be translated is: Usually students in that class play a sport. ### \n The predicate of the sentence is: play_sport. ### \n The entities of the sentence is: student. ### \n The translated formal logic program sentence is: student(X): play_sport(X) / play_sport(X). ### \n For example 3: The natural language sentence to be translated is: John does not play a sport. ### \n The predicate of the sentence is: play_sport. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: -play_sport(john). ### \n For example 4: The natural language sentence to be translated is: kate sings in the school student. ### \n The predicate of the sentence is: sings_in_school. ### \n The entities of the sentence is: kate. ### \n The translated formal logic program sentence is: sings_in_school(kate). ### \n For example 5: The natural language sentence to be translated is: kate does not sing in the school choir? ### \n The predicate of the sentence is: sings_in_school. ### \n The entities of the sentence is: kate. ### \n The translated formal logic program sentence is: sings_in_school(kate). ### \n", "PBD_MP": "### \n For example 1: The natural language sentence to be translated is: Jenny said the dog dug up the flower bed. ### \n The predicate of the sentence is: dug_flowers. more_trustworthy. person. truthful. made_mess. statement. ### \n The entities of the sentence is: dog. jenn. brother ### \n The translated formal logic program sentence is: statement(jenny, dug_flowers(dog)). statement(jenny, dug_flowers(dog)) : more_trustworthy(jenny,_) / dug_flowers(dog). ### \n For example 2: The natural language sentence to be translated is: Her brother said the dog did not dig up the flower bed. ### \n The predicate of the sentence is: statement. dug_flowers. ### \n The entities of the sentence is: brother. dog. ### \n The translated formal logic program sentence is: statement(brother, -dug_flowers(dog)). statement(brother, -dug_flowers(dog)) : more_trustworthy(brother,_) / -dug_flowers(dog). ### \n For example 3: The natural language sentence to be translated is: People usually tell the truth. ### \n The predicate of the sentence is: truthful. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: person(X): truthful(X) / truthful(X). ### \n For example 4: The natural language sentence to be translated is: Jenny is more trustworthy than her brother. ### \n The predicate of the sentence is: more_trustworthy. ### \n The entities of the sentence is: jenny. brother. ### \n The translated formal logic program sentence is: more_trustworthy(jenny, brother). ### \n For example 5: The natural language sentence to be translated is: If the dog dug up the flowers, it likely made a mess. ### \n The predicate of the sentence is: made_mess. dug_flowers. ### \n The entities of the sentence is: dog. ### \n The translated formal logic program sentence is: dug_flowers(dog): made_mess(dog) / made_mess(dog). ### \n For example 6: The natural language sentence to be translated is: dog made a mess? ### \n The predicate of the sentence is: made_mess. ### \n The entities of the sentence is: dog. ### \n The translated formal logic program sentence is: made_mess(dog). ### \n", "PBD_MT": "### \n For example 1: The natural language sentence to be translated is: John said the dog is friendly. John seems more reliable than Mary. ### \n The predicate of the sentence is: people. said. aggressive. claim. right. more_reliable. ### \n The entities of the sentence is: john. mary. dog. ### \n The translated formal logic program sentence is: people(john). people(mary). said(john, friendly(dog)). said(john, friendly(dog)) : more_reliable(john,_) / friendly(dog). ### \n For example 2: The natural language sentence to be translated is: the dog is friendly? ### \n The predicate of the sentence is: aggressive. said. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: said(mary, aggressive(dog)). said(mary, aggressive(dog)) : more_reliable(mary, _) / aggressive(dog). ### \n For example 3: The natural language sentence to be translated is: People are usually right when they make such claims. ### \n The predicate of the sentence is: right. claim. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: claim(X) : right(X), people(X) / right(X). ### \n For example 4: The natural language sentence to be translated is: John seems more reliable than Mary. ### \n The predicate of the sentence is: more_reliable. ### \n The entities of the sentence is: john. mary. ### \n The translated formal logic program sentence is: more_reliable(john, mary). ### \n For example 5: The natural language sentence to be translated is: the dog is friendly? ### \n The predicate of the sentence is: friendly. ### \n The entities of the sentence is: dog. ### \n The translated formal logic program sentence is: friendly(dog). ### \n ", "REI_MP": "### \n For example 1: The natural language sentence to be translated is: Jake, Emma, and Noah are students who took a math test. ### \n The predicate of the sentence is: student. studied_hard. scored_well. prepared_thoroughly. ### \n The entities of the sentence is: jake. emma. noah. ### \n The translated formal logic program sentence is: student(jake). student(emma). student(noah).  scored_well(noah) : prepared_thoroughly(noah) / prepared_thoroughly(noah). ### \n For example 2: The natural language sentence to be translated is: Typically, students who study hard for the math test score well. ### \n The predicate of the sentence is: studied_hard. student. scored_well. ### \n The entities of the sentence is: noah. ### \n The translated formal logic program sentence is: student(X): studied_hard(X) / studied_hard(X). student(X) : scored_well(X) / scored_well(X). ### \n For example 3: The natural language sentence to be translated is: Jake and Emma did not study hard for the test. ### \n The predicate of the sentence is: studied_hard. ### \n The entities of the sentence is: jake. emma. ### \n The translated formal logic program sentence is: -studied_hard(jake). -studied_hard(emma). ### \n For example 4: The natural language sentence to be translated is: If Noah scored well on the test, then he must have prepared thoroughly. ### \n The predicate of the sentence is: prepared_thoroughly. ### \n The entities of the sentence is: noah. ### \n The translated formal logic program sentence is: prepared_thoroughly(noah). ### \n For example 5: The natural language sentence to be translated is: Noah prepared thoroughly for the math test? ### \n The predicate of the sentence is: prepared_thoroughly. ### \n The entities of the sentence is: noah. ### \n The translated formal logic program sentence is: prepared_thoroughly(noah). ### \n", "REI_MT": "### \n For example 1: The natural language sentence to be translated is: John, Mike and Emma are students in the same class. ### \n The predicate of the sentence is: student. same_class. scored_well. late_submission. sick_this_week. ### \n The entities of the sentence is: john. emma. mike. ### \n The translated formal logic program sentence is: student(john). student(mike). student(emma). same_class(john). same_class(mike). same_class(emma). ### \n For example 2: The natural language sentence to be translated is: Usually, students in this class submit their assignments on time. ### \n The predicate of the sentence is: same_class. late_submission. submit_on_time. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: same_class(X): -late_submission(X) / submit_on_time(X). ### \n For example 3: The natural language sentence to be translated is: John and Mike have submitted one or more assignments late. ### \n The predicate of the sentence is: late_submission. ### \n The entities of the sentence is: john. mike. ### \n The translated formal logic program sentence is: late_submission(john). late_submission(mike). ### \n For example 4: The natural language sentence to be translated is: If Emma has been sick this week, then she likely also submitted an assignment late. ### \n The predicate of the sentence is: sick_this_week. late_submission. ### \n The entities of the sentence is: emma. ### \n The translated formal logic program sentence is: sick_this_week(emma) : late_submission(emma) / late_submission(emma). ### \n For example 5: The natural language sentence to be translated is: emma has been sick this week? ### \n The predicate of the sentence is: sick_this_week. ### \n The entities of the sentence is: emma. ### \n The translated formal logic program sentence is: sick_this_week(emma). ### \n ", "REII_MP": "### \n For example 1: The natural language sentence to be translated is: John bought a new phone. If a phone has a warranty, then it has customer support. ### \n The predicate of the sentence is: phone. bought. customer_support. warranty. sick_this_week. ### \n The entities of the sentence is: john. john_phone. mike. ### \n The translated formal logic program sentence is: new_phone(john_phone). ### \n For example 2: The natural language sentence to be translated is: New phones usually come with a warranty. ### \n The predicate of the sentence is: warranty. new_phone. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: new_phone(X) : warranty(X) / warranty(X). ### \n For example 3: The natural language sentence to be translated is: However, some new phones do not come with a warranty. ### \n The predicate of the sentence is: new_phone. warranty. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: new_phone(X) : -warranty(X) / -warranty(X). ### \n For example 4: The natural language sentence to be translated is: If a phone has a warranty, then it has customer support. ### \n The predicate of the sentence is: customer_support. warranty. ### \n The entities of the sentence is:X. ### \n The translated formal logic program sentence is: warranty(X) : customer_support(X) / customer_support(X). ### \n For example 5: The natural language sentence to be translated is: John's new phone has customer support? ### \n The predicate of the sentence is: customer_support. ### \n The entities of the sentence is: john_phone. ### \n The translated formal logic program sentence is: customer_support(john_phone). ### \n ", "REII_MT": "### \n For example 1: The natural language sentence to be translated is: John is a student at school X. ### \n The predicate of the sentence is: student_school_x. submits_on_time. sick_this_week. ### \n The entities of the sentence is: john. john_phone. one_student. ### \n The translated formal logic program sentence is: student_school_x(john). ### \n For example 2: The natural language sentence to be translated is: Students at school X typically submit their assignments on time. ### \n The predicate of the sentence is: student_school_x. submits_on_time. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: student_school_x(X) : submits_on_time(X) / submits_on_time(X).### \n For example 3: The natural language sentence to be translated is: There is at least one student at school X who does not submit assignments on time. ### \n The predicate of the sentence is: submits_on_time. ### \n The entities of the sentence is: one_student. ### \n The translated formal logic program sentence is: -submits_on_time(one_student). ### \n For example 4: The natural language sentence to be translated is: John has been sick this week? ### \n The predicate of the sentence is: sick_this_week. submits_on_time. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: sick_this_week(john) : -submits_on_time(john) / -submits_on_time(john). ### \n For example 5: The natural language sentence to be translated is: If John has been sick this week, then he likely did not submit the assignment on time. ### \n The predicate of the sentence is: sick_this_week. ### \n The entities of the sentence is: john. ### \n The translated formal logic program sentence is: sick_this_week(john). ### \n"}
LogicEvalD3_DL_Allatonce_Example_Dict_from_Test = {"d3_1": "For example 1: The natural language sentence to be translated is: There are two devices X and Y both equipped with thermal sensors. Typically, devices with thermal sensors also have motion detection capability. If device X has motion detection capability, then room Z turns on the lights. If room Z turns on the lights, then person W wakes up. person W does not wake up. ### \n The predicate of the sentence is: device. has_thermal_sensor. has_motion_detection. lights_on. wakes_up. ### \n The entities of the sentence is: jim. pam. ### \n The translated formal logic program sentence is: has_thermal_sensor(device_x). has_thermal_sensor(device_y). has_thermal_sensor(X), device(X): has_motion_detection(X) / has_motion_detection(X). has_motion_detection(device_x) : lights_on(room_z) / lights_on(room_z). lights_on(room_z): wakes_up(people_w) / wakes_up(people_w). -wakes_up(people_w). ### \n For example 2: The natural language sentence to be translated is: device Y has motion detection capability? ### \n The predicate of the sentence is: has_motion_detection. ### \n The entities of the sentence is: device_y. ### \n The translated formal logic program sentence is: has_motion_detection(device_y). ### \n", "d3_2": "### \n For example 1: The natural language sentence to be translated is: dogs and cats are mammals with fur. Usually, mammals with fur have tails. If a horse has a mane, then that horse is likely to be strong. Either a dog has a tail or a horse does not have a mane, or both. a horse does not have strength. ### \n The predicate of the sentence is: mammals_with_fur. has_tail. has_mane. strong. ### \n The entities of the sentence is: dog. cat. horse. ### \n The translated formal logic program sentence is: mammals_with_fur(dog). mammals_with_fur(cat). mammals_with_fur(X) : has_tail(X) / has_tail(X). has_mane(horse) : strong(horse) / strong(horse). has_tail(dog) | -has_mane(horse). -strength(horse). ### \n For example 2: The natural language sentence to be translated is: a cat has a tail? ### \n The predicate of the sentence is: has_tail. ### \n The entities of the sentence is: cat. ### \n The translated formal logic program sentence is: has_tail(cat). ### \n", "d4_1": "### \n For example 1: The natural language sentence to be translated is: Red and Blue cars have sunroofs. Typically, cars with sunroofs have leather seats. If a vehicle is a convertible, it has a top that can be retracted. If a motorcycle has a sidecar, it can carry an additional passenger. Either a convertible has a retractable top or a motorcycle with a sidecar can carry an extra passenger or both. If a red car has leather seats, then a convertible has a retractable top. a vehicle does not have a retractable top. ### \n The predicate of the sentence is: sunroofs. has_tail. have_leather_seats. retracted_top. carry_passenger. ### \n The entities of the sentence is: red_cars. blue_cars. cars. convertible. motocycle. ### \n The translated formal logic program sentence is: cars(red_cars). cars(blue_cars). sunroofs(red_cars). sunroofs(blue_cars). cars(X), sunroofs(X) : have_leather_seats(X) / have_leather_seats(X). retracted_top(convertible). sidecar(motocycle) : carry_passenger(motocycle) / carry_passenger(motocycle). retracted_top(convertible) | carry_passenger(motocycle). has_leather_seats(red_cars) : retracted_top(convertible) / retracted_top(convertible). -retracted_top(convertible). ### \n For example 2: The natural language sentence to be translated is: a blue car has leather seats? ### \n The predicate of the sentence is: has_leather_seats. ### \n The entities of the sentence is: blue_cat. ### \n The translated formal logic program sentence is: has_leather_seats(blue_cat). ### \n", "d4_2": "### \n For example 1: The natural language sentence to be translated is: Assume M and N are students with good attendance records. Typically, students with good attendance also perform well academically. If a student P scores high on tests, then student P submits assignments on time. If student Q is in the debate club, then student Q is a good public speaker. Either student P does not submit assignments on time or student R does not score high on tests. If student M performs well academically, then student R scores high on tests. student Q is a good public speaker. ### \n The predicate of the sentence is: good_anntendance. perform_well_academically. score_high_on_test. submit_assignments_on_time. submit_assignments_on_time. good_public_speaker. perform_well_academically. ### \n The entities of the sentence is: student_p. student_q. student_m. student_r. horse. ### \n The translated formal logic program sentence is: good_anntendance(student_m). good_anntendance(student_n). good_attendance(X) : perform_well_academically(X) / perform_well_academically(X). scores_high_test(student_p) : submit_assignments_on_time(student_p) / submit_assignments_on_time(student_p). debate_club(student_q) : good_public_speaker(student_q) / good_public_speaker(student_q). -submit_assignments_on_time(student_p) | -score_high_on_test(student_r). perform_well_academically(student_m) : score_high_on_test(student_m) / score_high_on_test(student_m). good_public_speaker(student_q). ### \n For example 2: The natural language sentence to be translated is: student N performs well academically? ### \n The predicate of the sentence is: perform_well_academically. ### \n The entities of the sentence is: student_n. ### \n The translated formal logic program sentence is: perform_well_academically(student_n) ### \n ", "d5_1": "### \n For example 1: The natural language sentence to be translated is: Tom and Jerry are students who are diligent. Typically, diligent students also excel academically. If a student studies computer science, and they are skilled in coding, they can develop software. If a student chooses biology as their major and excels in laboratory work, they can pursue a career in research. Either a student studies computer science or a student can pursue a career in research, or both. If Peter has developed software, then Mary excels in laboratory work. If Tom excels academically, then Peter has developed software. Mary does not excel in laboratory work. ### \n The predicate of the sentence is: studen. diligent. studies_computer_science. skilled_in_coding. develop_software. excel_academically. pursue_career_in_research. excel_in_labratory_work. ### \n The entities of the sentence is: tom. jerry. student_m. student_r. horse. ### \n The translated formal logic program sentence is: student(tom). student(jerry). diligent(tom). diligent(tom). student(X), diligent(X) : excel_academically(X) / excel_academically(X). student(X), studies_computer_science(X) : skilled_in_coding(X), develop_software(X) / skilled_in_coding(X), develop_software(X). student(X), excel_in_labratory_work(X) : pursue_career_in_research(X) / pursue_career_in_research(X). student(X): studies_computer_science(X) / studies_computer_science(X) | student(X) : pursue_a_career_in_reasearch(X) / pursue_a_career_in_reasearch(X). developed_software(peter) : excel_in_laboratory_work(mary) / excel_in_laboratory_work(mary). excels_academically(tom) : developed_software(peter) / developed_software(peter). -excel_in_laboratory_work(mary). ### \n For example 2: The natural language sentence to be translated is: Jerry excels academically? ### \n The predicate of the sentence is: excels_academically. ### \n The entities of the sentence is: jerry. ### \n The translated formal logic program sentence is: excels_academically(jerry). ### \n "}
LogicEvalD3_DL_onebyone_Example_Dict_from_Test = {"d3_1": "For example 1: The natural language sentence to be translated is: There are two devices X and Y both equipped with thermal sensors. ### \n The predicate of the sentence is: device. has_thermal_sensor. ### \n The entities of the sentence is: device_x. device_y. ### \n The translated formal logic program sentence is: has_thermal_sensor(device_x). has_thermal_sensor(device_y). ### \n For example 2: The natural language sentence to be translated is: Typically, devices with thermal sensors also have motion detection capability. ### \n The predicate of the sentence is: has_thermal_sensor. has_motion_detection. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: has_thermal_sensor(X), device(X): has_motion_detection(X) / has_motion_detection(X). ### \n For example 3: The natural language sentence to be translated is: If device X has motion detection capability, then room Z turns on the lights. ### \n The predicate of the sentence is: has_motion_detection. lights_on. ### \n The entities of the sentence is: device_x. room_z. ### \n The translated formal logic program sentence is: has_motion_detection(device_x) : lights_on(room_z) / lights_on(room_z). ### \n For example 4: The natural language sentence to be translated is: If room Z turns on the lights, then person W wakes up. ### \n The predicate of the sentence is: lights_on. wakes_up. ### \n The entities of the sentence is: room_z. people_w. ### \n The translated formal logic program sentence is: lights_on(room_z): wakes_up(people_w) / wakes_up(people_w). ### \n For example 5: The natural language sentence to be translated is: person W does not wake up. ### \n The predicate of the sentence is: wakes_up. ### \n The entities of the sentence is: people_w. ### \n The translated formal logic program sentence is: -wakes_up(people_w). ### \n For example 6: The natural language sentence to be translated is: device Y has motion detection capability? ### \n The predicate of the sentence is: has_motion_detection. ### \n The entities of the sentence is: device_y. ### \n The translated formal logic program sentence is: has_motion_detection(device_y). ### \n", "d3_2": "### \n For example 1: The natural language sentence to be translated is: dogs and cats are mammals with fur. ### \n The predicate of the sentence is: mammals_with_fur. ### \n The entities of the sentence is: dog. cat. ### \n The translated formal logic program sentence is: mammals_with_fur(dog). mammals_with_fur(cat). ### \n For example 2: The natural language sentence to be translated is: Usually, mammals with fur have tails. ### \n The predicate of the sentence is: mammals_with_fur. has_tail. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: mammals_with_fur(X) : has_tail(X) / has_tail(X). ### \n For example 3: The natural language sentence to be translated is: If a horse has a mane, then that horse is likely to be strong. ### \n The predicate of the sentence is: has_mane. strong. ### \n The entities of the sentence is: horse. ### \n The translated formal logic program sentence is: has_mane(horse) : strong(horse) / strong(horse). ### \n For example 4: The natural language sentence to be translated is: Either a dog has a tail or a horse does not have a mane, or both. ### \n The predicate of the sentence is: has_tail. has_mane. ### \n The entities of the sentence is: horse. ### \n The translated formal logic program sentence is: has_tail(dog) | -has_mane(horse). ### \n For example 5: The natural language sentence to be translated is: a horse does not have strength. ### \n The predicate of the sentence is: strength. ### \n The entities of the sentence is: horse. ### \n The translated formal logic program sentence is: -strength(horse). ### \n For example 6: The natural language sentence to be translated is: a cat has a tail? ### \n The predicate of the sentence is: has_tail. ### \n The entities of the sentence is: cat. ### \n The translated formal logic program sentence is: has_tail(cat). ### \n", "d4_1": "### \n For example 1: The natural language sentence to be translated is: Red and Blue cars have sunroofs. ### \n The predicate of the sentence is: sunroofs. ### \n The entities of the sentence is: red_cars. blue_cars. cars. ### \n The translated formal logic program sentence is: cars(red_cars). cars(blue_cars). sunroofs(red_cars). sunroofs(blue_cars). ### \n For example 2: The natural language sentence to be translated is: Typically, cars with sunroofs have leather seats. ### \n The predicate of the sentence is: cars. sunroofs. has_leather_seats. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: cars(X), sunroofs(X) : have_leather_seats(X) / have_leather_seats(X). ### \n For example 3: The natural language sentence to be translated is: If a vehicle is a convertible, it has a top that can be retracted. ### \n The predicate of the sentence is: retracted_top. ### \n The entities of the sentence is: convertible. ### \n The translated formal logic program sentence is: retracted_top(convertible). ### \n For example 4: The natural language sentence to be translated is: If a motorcycle has a sidecar, it can carry an additional passenger. ### \n The predicate of the sentence is: carry_passenger. ### \n The entities of the sentence is: motocycle. ### \n The translated formal logic program sentence is: sidecar(motocycle) : carry_passenger(motocycle) / carry_passenger(motocycle). ### \n For example 5: The natural language sentence to be translated is: Either a convertible has a retractable top or a motorcycle with a sidecar can carry an extra passenger or both. ### \n The predicate of the sentence is: carry_passenger. retracted_top. ### \n The entities of the sentence is: convertible. motocycle. ### \n The translated formal logic program sentence is: retracted_top(convertible) | carry_passenger(motocycle). ### \n For example 6: The natural language sentence to be translated is: If a red car has leather seats, then a convertible has a retractable top. ### \n The predicate of the sentence is: retracted_top. has_leather_seats. ### \n The entities of the sentence is: convertible. red_cars. ### \n The translated formal logic program sentence is: has_leather_seats(red_cars) : retracted_top(convertible) / retracted_top(convertible). ### \n For example 7: The natural language sentence to be translated is: a vehicle does not have a retractable top. ### \n The predicate of the sentence is: retracted_top. ### \n The entities of the sentence is: convertible. ### \n The translated formal logic program sentence is: -retracted_top(convertible). ### \n For example 8: The natural language sentence to be translated is: a blue car has leather seats? ### \n The predicate of the sentence is: has_leather_seats. ### \n The entities of the sentence is: blue_cat. ### \n The translated formal logic program sentence is: has_leather_seats(blue_cat). ### \n", "d4_2": "### \n For example 1: The natural language sentence to be translated is: Assume M and N are students with good attendance records. ### \n The predicate of the sentence is: good_anntendance. ### \n The entities of the sentence is: student_m. student_n. ### \n The translated formal logic program sentence is: good_anntendance(student_m). good_anntendance(student_n). ### \n For example 2: The natural language sentence to be translated is: Typically, students with good attendance also perform well academically. ### \n The predicate of the sentence is: perform_well_academically. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: good_attendance(X) : perform_well_academically(X) / perform_well_academically(X). ### \n For example 3: The natural language sentence to be translated is: If a student P scores high on tests, then student P submits assignments on time. ### \n The predicate of the sentence is: scores_high_test. submit_assignments_on_time. ### \n The entities of the sentence is: student_p. ### \n The translated formal logic program sentence is: scores_high_test(student_p) : submit_assignments_on_time(student_p) / submit_assignments_on_time(student_p). ### \n For example 4: The natural language sentence to be translated is: If student Q is in the debate club, then student Q is a good public speaker. ### \n The predicate of the sentence is: debate_club. good_public_speaker. ### \n The entities of the sentence is: student_q. ### \n The translated formal logic program sentence is: debate_club(student_q) : good_public_speaker(student_q) / good_public_speaker(student_q). ### \n For example 5: The natural language sentence to be translated is: Either student P does not submit assignments on time or student R does not score high on tests. ### \n The predicate of the sentence is: submit_assignments_on_time. score_high_on_test. ### \n The entities of the sentence is: student_p. student_r. ### \n The translated formal logic program sentence is: -submit_assignments_on_time(student_p) | -score_high_on_test(student_r). ### \n For example 6: The natural language sentence to be translated is: If student M performs well academically, then student R scores high on tests. student Q is a good public speaker. ### \n The predicate of the sentence is: perform_well_academically. ### \n The entities of the sentence is: student_n. ### \n The translated formal logic program sentence is: perform_well_academically(student_m) : score_high_on_test(student_r) / score_high_on_test(student_r). ### \n For example 7: The natural language sentence to be translated is: student Q is a good public speaker. ### \n The predicate of the sentence is: good_public_speaker. ### \n The entities of the sentence is: student_q. ### \n The translated formal logic program sentence is: good_public_speaker(student_q). ### \n For example 8: The natural language sentence to be translated is: student N performs well academically? ### \n The predicate of the sentence is: perform_well_academically. ### \n The entities of the sentence is: student_n. ### \n The translated formal logic program sentence is: perform_well_academically(student_n). ### \n ", "d5_1": "### \n For example 1: The natural language sentence to be translated is: Tom and Jerry are students who are diligent. ### \n The predicate of the sentence is: studen. diligent. ### \n The entities of the sentence is: tom. jerry. ### \n The translated formal logic program sentence is: student(tom). student(jerry). diligent(tom). diligent(tom). ### \n For example 2: The natural language sentence to be translated is: Typically, diligent students also excel academically. ### \n The predicate of the sentence is: student. diligent. excels_academically. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: student(X), diligent(X) : excel_academically(X) / excel_academically(X). ### \n For example 3: The natural language sentence to be translated is: If a student studies computer science, and they are skilled in coding, they can develop software. ### \n The predicate of the sentence is: studies_computer_science. skilled_in_coding. develop_software. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: student(X), studies_computer_science(X) : skilled_in_coding(X), develop_software(X) / skilled_in_coding(X), develop_software(X). ### \n For example 4: The natural language sentence to be translated is: If a student chooses biology as their major and excels in laboratory work, they can pursue a career in research. ### \n The predicate of the sentence is: student. excel_in_labratory_work. pursue_career_in_research. ### \n The entities of the sentence is: jerry. ### \n The translated formal logic program sentence is: student(X), excel_in_labratory_work(X) : pursue_career_in_research(X) / pursue_career_in_research(X). ### \n For example 5: The natural language sentence to be translated is: Either a student studies computer science or a student can pursue a career in research, or both. ### \n The predicate of the sentence is: student. studies_computer_science. pursue_a_career_in_reasearch. ### \n The entities of the sentence is: X. ### \n The translated formal logic program sentence is: student(X): studies_computer_science(X) / studies_computer_science(X) | student(X) : pursue_a_career_in_reasearch(X) / pursue_a_career_in_reasearch(X). ### \n For example 6: The natural language sentence to be translated is: If Peter has developed software, then Mary excels in laboratory work. ### \n The predicate of the sentence is: developed_software. excel_in_laboratory_work. ### \n The entities of the sentence is: peter. mary. ### \n The translated formal logic program sentence is: developed_software(peter) : excel_in_laboratory_work(mary) / excel_in_laboratory_work(mary). ### \n For example 7: The natural language sentence to be translated is: If Tom excels academically, then Peter has developed software. ### \n The predicate of the sentence is: excels_academically. developed_software. ### \n The entities of the sentence is: peter. tom. ### \n The translated formal logic program sentence is: excels_academically(tom) : developed_software(peter) / developed_software(peter). ### \n For example 8: The natural language sentence to be translated is: Mary does not excel in laboratory work. ### \n The predicate of the sentence is: excel_in_laboratory_work. ### \n The entities of the sentence is: mary. ### \n The translated formal logic program sentence is: -excel_in_laboratory_work(mary). ### \n For example 9: The natural language sentence to be translated is: Jerry excels academically? ### \n The predicate of the sentence is: excels_academically. ### \n The entities of the sentence is: jerry. ### \n The translated formal logic program sentence is: excels_academically(jerry). ### \n "}

def Prompt_List(NMR_Category):
    global Prompt_with_Extract_Fact_Rule_From_Context,Prompt_with_Extract_Sentence_from_Context,Prompt_with_Rewrite_Extract_Fact_Rule_From_Context,Prompt_with_Verifier_Extract_Fact_Rule_From_Context
    global Prompt_with_Generate_Default_Logic_Code_for_LogicBench, Prompt_with_Generate_ASP_Code_for_LogicBench,Prompt_with_Predicate_Consistency_Alignment_for_LogicBench,Credulous_Reasoning_Prompt_for_LogicBench,Skeptical_Reasoning_Prompt_for_LogicBench, LogicBench_DL_Onebyone_Example_Dict
    global Semantic_Score_Prompt_with_ASP_for_LogicBench,LogicBench_DL_Allatonce_Example_Dict,Reasoning_Prompt_for_LogicBench
    global Semantic_Score_Prompt_with_ASP_for_LogicEvalD1,Semantic_Score_Prompt_with_ASP_for_LogicEvalD2, Semantic_Score_Prompt_with_ASP_for_LogicEvalD3
    global Fine_Tune_Generator_Instruction, Fine_Tune_Score_Instruction
    # Prompt the model to generate the initial ASP program  # TODO: Manual translation needed
    # Prompt the model to generate the initial ASP program  # TODO: Manual translation needed
    # Prompt the model to generate default logic  # TODO: Manual translation needed

    # Prompt_with_Generate_Default_Logic_Code_for_LogicBench = '###Task: \n You are an expert trained in default logic. Our goal is to translate the natural language sentence into default logic. The general fact of default logic is: a(X). This fact means that X is a. The general rule of default logic is: b(X) : c(X) / a(X). This rule means that if x is b and believe that he is c, then it can be inferred that x is a. \n The input format is: The natural language sentence to be translated is:"". \n The output format is: The predicate of the sentence is:. ### \n The entities of the sentence is:. ### \n The translated sentence is:. ### \n For example 1: The natural language sentence to be translated is: kangaroos and emus are marsupials. ### marsupials usually carry their young in a pouch. ### kangaroos are possibly an exception to this rule. ### emus carry their young in a pouch? ### emus don\'t carry their young in a pouch? \n The predicate of the sentence is: marsupials. carry. ### \n The entities of the sentence is: kangaroos. emus. ### \n The translated sentence is: marsupials(kangaroos). marsupials(emus). ### marsupials (X): -carry_their_young_in_a_pouch(X) / carry_their_young_in_a_pouch(X). ### -carry_their_young_in_a_pouch(kangaroos). ### carry_their_young_in_a_pouch(emus). ### -carry_their_young_in_a_pouch(emus). ### \n For example 2: The natural language sentence to be translated is: dogs and cats are animals. ### animals typically live in homes. ### dogs are not living in homes. ### dogs are loyal companions. ### cats are living in homes? ### cats aren\'t living in homes? ### \n The predicate of the sentence is: animals. live_in_homes. ### \n The entities of the sentence is: dogs. cats. ### \n The translated sentence is: animals(dogs). animals(cats). ### animals(X): -live_in_homes(X) / live_in_home(X). ### -live_in_homes(dogs). ### loyal_companions(dogs). ### live_in_homes(cats). ### - live_in_homes(cats). ### \n For example 3: The natural language sentence to be translated is: lemurs are primates. ### primates have opposable thumbs. ### lemurs do not have opposable thumbs. ### all other primates than lemurs have opposable thumbs? ### all other primates than lemurs don\'t have opposable thumbs? ### \n The predicate of the sentence is: primates.opposable_thumbs. ### \n The entities of the sentence is: lemurs. ### \n The translated sentence is: primates(lemurs). ### opposable_thumbs (primates). ### -opposable_thumbs(lemurs). ### opposable_thumbs(primates). -opposable(lemurs). ### -opposable_thumbs (primates). opposable_thumbs (lemurs). ### \n For example 4: The natural language sentence to be translated is: john and tim are friends. ### friends are loyal. ### friends are always supportive. ### john is not loyal. ### tim is not supportive. ### tim is loyal and john is supportive? ### tim isn\'t loyal and john is supportive? ### tim is loyal and john isn\'t supportive? ### tim isn\'t loyal and john isn\'t supportive? ### \n The predicate of the sentence is: friends. loyal. supportive. ### \n The entities of the sentence is: john. tim. ### \n The translated sentence is: friends(john,tim). ### friends(X,Y): -loyal(X) / loyal(X). friends(X,Y): -loyal(Y) / loyal(Y). ### friends(X,Y): -supportive(X) / supportive(X). friends(X,Y): -supportive(Y) / supportive(Y). ### -loyal(john). ### -supportive(tim). ### loyal(tim) ∧supportive(john). ### -loyal(tim) ∧supportive(john). ### loyal(tim) ∧-supportive(john). ### -loyal(tim) ∧-supportive(john). ### \n For example 5: The natural language sentence to be translated is: apples, oranges, and bananas are fruits. ### fruits are typically rich in vitamins. ### at least one of apples or oranges does not contain vitamins. ### bananas are rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### bananas aren\'t rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### \n The predicate of the sentence is: fruits. vitamins. ### \n The entities of the sentence is: apples. oranges. bananas. ### \n The translated sentence is: fruits(apples). fruits(oranges). fruits(bananas). ### fruits(X): -vitamins(X) / vitamins(X). ### -vitamins(apples) ∨ -vitamins(oranges). ### vitamins(bananas) ∧(-vitamins(apples) ∨ -vitamins(oranges)). ### -vitamins(bananas) ∧(-vitamins(apples) ∨ -vitamins(oranges)). ### \n For example 6: The natural language sentence to be translated is: cars drive on roads. ### at least one car doesn\'t drive on roads. ### exactly one car doesn\'t drive on roads? ### \n The predicate of the sentence is: drive_on_roads. ### \n The entities of the sentence is: cars. ### \n The translated sentence is: drive_on_roads(cars). ### -drive_on_roads(one_car). ### -drive_on_roads(one_car). ### \n For example 7: The natural language sentence to be translated is: cats are carnivores. ### carnivores normally eat meat. ### at least one carnivore does not eat meat. ### cats usually eat meat? ### cats usually don\'t eat meat? ### \n The predicate of the sentence is: carnivores.eat_meat. ### \n The entities of the sentence is: cats. ### \n The translated sentence is: carnivores(cats). ###  carnivores(X): -eat_meat(X) / eat_meat(X). ### -eat_meat(one_carnivore). ###  eat_meat(cats). ### -eat_meat(cats). ### \n For example 8: The natural language sentence to be translated is: john asserts that the cat is in the park. ### jane asserts that the cat is not in the park. ### jane\'s evidence is more reliable than john\'s. ### the cat is not in the park? ### the cat is in the park? ### \n The predicate of the sentence is: in_the_park. ### \n The entities of the sentence is: john. jane. cat.### \n The translated sentence is: asserts(john): -in_the_park(cat) / in_the_park(X). ### assert(jane): in_the_park(cat) / -in_the_park(cat). ### asserts(jane). -asserts(john). ### -in_the_park(cat). ### in_the_park(cat). ### \n'
    Example_NMR_Category,Examples_Dict, Examples_Dict1,Examples_Dict2 = '',None,None,None
    if Allatonce_Flag == True:      
        if Dataset_Name =='LogicBench' and Formal_Natural_Language == 'DL':
            Examples_Dict = LogicBench_DL_Allatonce_Example_Dict_from_Test
    elif Allatonce_Flag == False:
        if Dataset_Name =='LogicBench' and Formal_Natural_Language == 'DL':
            Examples_Dict = LogicBench_DL_Onebyone_Example_Dict_from_Test
        elif Dataset_Name =='LogicBench' and Formal_Natural_Language =='ASP':
            Examples_Dict = LogicBench_ASP_Onebyone_Example_Dict_from_Test

    else:
        raise ValueError('Dataset_Name is not valid')   

    # Define prompts for extracting and rewriting facts and rules  # TODO: Manual translation needed
    Prompt_with_Extract_Fact_Rule_From_Context = "###Task \n Given the context and question over natural language, you need to first extract predicates and entities from the question and context. Then, you need to extract atomized facts and default rules about predicates and entities from the context. The generated facts and rules are required to be used to reason and answer questions. Fact is a specific, unconditional, and ground statement sentence about particular entities, their properties, or their relationships, such as entityA is predicateB. Default Rule is a general rule that applies to a class of entities but allows for exceptions, such as predicateA is usually predicateB. Information in the context that is not related to reasoning and answering questions can be simplified or omitted. In addition, exceptions in facts and rules need to be replaced by corresponding predicates. Finally, you should first extract all the facts for reasoning question, then extract all the default rules. The extracted facts cannot contradict each other. The extracted individual facts and rules are separated by periods. \n The input format is: The natural language context sentences are:''. ### \n The questions are:''. ### \n The output format is: The extracted entities are: ''. \n The extracted predicate are: ''. \n The extracted facts and rules in context are: ''. ### \n The extracted questions are: ''. ### \n" + LogicBench_Extract_FR_From_Context_from_Test[NMR_Category] + " \n Don\'t output your reasoning or thinking process."     
    Prompt_with_Extract_Sentence_from_Context = "###Task \n Given a natural language context and a question, and facts and rules extracted from the context that are easy to formalize for reasoning about the answer, a sentence consistently fails during formalization. Therefore, you need to re-extract the correctly formalized natural language sentence based on the original context and error message. \n  Fact is a specific, unconditional, and ground statement sentence about particular entities, their properties, or their relationships, such as entityA is predicateB. Default Rule is a general rule that applies to a class of entities but allows for exceptions, such as predicateA is usually predicateB. Information in the context that is not related to reasoning and answering questions can be simplified or omitted. In addition, exceptions in facts and rules need to be replaced by corresponding predicates. \n The input format is: The natural language context sentences are:''. ### \n The questions are:''. ### \n The extracted sentences are:''. ### \n The incorrectly formalized natural language sentence is:'' ### \n The error message is: ''. ### \n The output format is: The reextracted sentence in context are: ''. ### \n + Don\'t output your reasoning or thinking process." 
    # Prompt_with_Extract_Fact_Rule_From_Context = "### Given a context and quesions, Your task extract facts and default rules from the context. The extracted atomized facts and rules are required to be used to reason and answer questions. \n Specifically, you need to first identify the entities and predicates in the sentence of the context and questions. Then, you need to generate all atomized facts and default rules from context , which are sufficient to reason and answer questions.  \n Fact is a specific, unconditional, and ground statement sentence about particular entities, their properties, or their relationships, such as entityA is predicateB. Default Rule is a general rule that applies to a class of entities but allows for exceptions, such as predicateA is usually predicateB. \n Facts or default rules in the context that is not related to reasoning and answering questions can be omitted, and exceptions need to be converted to specific facts or rules.  \n The input format is: The natural language context sentences are:''. ### \n The questions are:''. ### \n The output format is: The extracted entities are: ''. \n The extracted predicate are: ''. \n The extracted facts and rules in context are: ''. ### \n The extracted questions are: ''. ### \n" + LogicBench_Extract_FR_From_Context_from_Test[NMR_Category] + " \n Don\'t output your reasoning or thinking process."
    
    Prompt_with_Verifier_Extract_Fact_Rule_From_Context = " You are a rigorous logical analyst, your task is to evaluate the correctness of a set of facts and default rules extracted from a context for the purpose of answering reasoning-based questions. It is worth noting that you should only extract facts and default rules from the context that are necessary to answer the question; facts and default rules not related to the reasoning question can be omitted. A fact is a specific, unconditional, and ground statement about particular entities, their properties, or their relationships. Facts often use copulas such as 'is' to define attributes or categories. A default rule is a general rule that applies to a class of entities but allows for exceptions and is often signaled in natural language by adverbs like 'typically' or 'usually'. You must verify them along two dimensions: first, soundness, meaning all facts and rules must be entirely derived from the context and faithful to its semantics; and second, completeness, meaning the facts and rules must be sufficient to form a complete reasoning chain to definitively answer the question. Please conduct your analysis and adhere to the following output rules: If both soundness and completeness are met, your sole output should be 'yes # ' and the output suggestion is ' None # '. If either criterion is not met, output 'no # '; you only need to generate suggested facts or default rule sentences. Do not generate already extracted facts and rules. \n The input format is: The natural language context sentences are:''. ### \n The extracted facts and default rules are:''. ### \n The questions are:''. ### \n The output format is: The verification result is: '... #'. ### \n The suggestion of extracted facts and default rules is:'... #'. ### \n The extracted questions are: ''. ### \n  Don\'t output your reasoning or thinking process." 

    Prompt_with_Rewrite_Extract_Fact_Rule_From_Context = "### You are a rigorous natural language logical reasoning expert. Given a natural language context, a set of facts and default rules sentences extracted from context and quesions, your task is to review, rewrite, and optimize a preliminary set of facts and rules extracted from a given context, making them more concise, consistent, and sufficient to answer a specific question through logical reasoning. For example, you should remove facts or default rules that are irrelevant or redundant to the reasoning question.  You should try to maintain the consistency of similar semantic predicates in different facts and rules.  \n The input format is: The natural language context sentences are:''. ### \n The extracted facts and default rules are:''. ### \n The questions are:''. ### \n The output format is: The rewrited facts and default rules are: ''. ### \n The extracted questions are: ''. ### \n  Don\'t output your reasoning or thinking process."
    Prompt_with_Extract_Fact_Rule_From_Sentence = "### You are a natural language sentence-level abstractor. Given a context, a sentence to be abstracted, and a question. The sentence to be abstracted comes from the context. You simply extract facts and default rules from the sentence that are to reason and answer questions. Fact is a specific, unconditional, and ground statement sentence about particular entities, their properties, or their relationships. Facts often use copulas such as 'is' to define attributes or categories. Default Rule is a general rule that applies to a class of entities but allows for exceptions and is often signaled in natural language by adverbs like 'typically' or 'usually'. In addition, facts or default rules in the context that is not related to reasoning and answering questions can be omitted, and exceptions need to be converted to specific facts or rules.  \n Specifically, you need to first identify the entities and predicates in the sentence and questions, and try to maintain the consistency of similar semantic predicates in facts and rules. Then, you need to generate atomized facts and default rules.  \n The input format is: The sentence to be extracted is:''. ### \n The questions are:''. ### \n The output format is: The extracted entities are: ''. \n The extracted predicate are: ''. \n The extracted facts and rules from sentence are: ''. ### \n The extracted questions are: ''. ### \n" + LogicBench_Extract_FR_From_Context_from_Test[NMR_Category] + " \n Don\'t output your reasoning or thinking process."
    
    Prompt_with_Generate_Default_Logic_Code_for_LogicBench = '###Task: \n You are an default logic expert. you need to translate the given natural language sentence into default logic. \n You need to first determine whether the given natural language sentence is a fact or a default rule. Then translate the natural language into the corresponding facts or default rules. Fact in default logic is represented as atomic formulas composed of predicates and entities, such as "predicate1(entity1)." stating that enity1 is predicate1 or entity1 has the property predicate1. Default rules are represented as logical formulas composed of predicates and variables,  such as default rule "predicate1(X) : predicate2(X) / predicate2(X)." signifies that if X is predicate1 then X is typically inferred to be predicate2. \n Specifically, you need to extract entities or variables and predicates from the sentence first, and no spaces are allowed in entities and predicates. Then, the natural language sentence is converted into the default logic based on the extracted entity or variable and predicates. \n To ensure consistent predicates across formal sentences, you should try to use predicates and entities extracted from the context. \n The input format is: The natural language context sentences are:'' \n The extracted predicates from context are:'' \n The extracted entities from context are:'' \n The translated formal logic program context sentences are: '' \n The natural language sentence to be translated is: "". \n The output format is: The predicate of the sentence is: "". ### \n The entities of the sentence is: "". ### \n The translated formal logic program sentence is: "".' + Examples_Dict[NMR_Category]  + "\n Don\'t output your reasoning or thinking process."      
    
    Prompt_with_Generate_ASP_Code_for_LogicBench = '###Task: \n You are an expert trained in Answer Set Programming. You need to extract entities and predicates from the sentence first, and no spaces are allowed between entities and predicates. Then, the natural language is converted into the answer set program language based on the extracted entities and predicates. The facts in the answer set program can be expressed as "predicates(entity).". The rules in the answer set program can be expressed as: prediacte1(X) :- predicate2(X), not predicate3(X). This rule means that if X is predicate1 then he is predicate2, unless he is predicate3. \n The input format is: The natural language sentence to be translated is:"". \n The output format is: The predicate of the sentence is:. ### \n The entities of the sentence is:. ### \n The translated sentence is:. ### \n' + Examples_Dict[NMR_Category] + " \n Don\'t output your reasoning or thinking process."      
    Prompt_with_Predicate_Consistency_Alignment_for_LogicBench = '###Task: \n You are an expert in answer set programming. Our goal is to align given ASP sentences with given predicates. If you think the predicate in the ASP sentence is semantically similar to the given predicate, you need to rewrite the ASP sentence with the given predicate; if the predicate in the ASP sentence is different from the given predicate, then directly output the given ASP sentence. ### \n The input format is: ### \n The natural language sentences are: ‘’ ### \n The extracted predicate list are:’’. ### \n The formal logic program that needs to be aligned are:’’. The output format is: The aligned formal logic program are:''. ### \n Note that you only need to output the aligned formal logic program.\n' + " Don\'t output your reasoning or thinking process."
    # Prompt the model to repair the ASP program  # TODO: Manual translation needed
    Semantic_Score_Prompt_with_ASP_for_LogicBench = "You are an expert in answer set programming logic and linguistics. In Answer Set Programming, a fact is represented as an atomic formula composed of predicates and entities, such as 'predicate1(entity1).' stating that enity1 is predicate1 or entity1 has the property predicate1. An ASP rule is represented as a logical formula composed of predicates and variables. A rule 'predicate2(X) :- predicate1(X), not -predicate2(X).' signifies that if X is predicate1 then X is typically inferred to be predicate2. \n Your task is to evaluate the correctness of the translation from a natural language sentence to an ASP statement based on syntactic correctness, semantic equivalence, consistency of atomic propositions, and conciseness. You are required to provide a final overall score. The score must range from 0 to 1, where 1 means the translated ASP statement is completely correct, and 0 means it is completely wrong. \n The input format is: The natural language sentences are:''. The translated logic program sentences are:''. \n The output format is: The score is:. ### \n For example 1: The natural language sentences are: tall stature is often playing basketball. \n The translated logic program sentences are: playBasketball(X) :- tall(X), not -playBasketball(X). \n The score is: 0.9. ### \n For example 2: The natural language sentences are: anna is not plays basketball. \n The translated logic program sentences are: playBasketball(jenny). \n The score is: 0.1. ### \n For example 3: The natural language sentences are: Dogs known for their loyalty. \n The translated logic program sentences are: loyalty(dogs). \n The score is: 0.8. ### \n For example 4: The natural language sentences are: Dogs known for their loyalty. \n The translated logic program sentences are: loyalty(X) :- dogs(X), -loyalty(X). \n The score is: 0.1. ### \n For example 5: The natural language sentences are: either cats or dogs are not considered particularly intelligent. \n The translated logic program sentences are: -intelligent(cats). -intelligent(dogs). \n The score is: 0.9. ### \n For example 6: The natural language sentences are: either cats or dogs are not considered particularly intelligent. \n The translated logic program sentences are: -intelligent(cats). \n The score is: 0.5. ### \n For example 7: The natural language sentences are: cat are usually has fur. \n The translated logic program sentences are: fur(cats) :- fur(cats), not -fur(cats). \n The score is: 0.1. ### \n For example 8: The natural language sentences are: jane asserts that sally was not in the store. \n The translated logic program sentences are: asserts(jane, -inStore(sally)). -inStore(sally) :- asserts(jane, -inStore(sally)), not reliable(_, sally). \n The score is: 0.95. ### \n For example 9: The natural language sentences are: john adamantly claims that sally was present at the store. \n The translated logic program sentences are: claims(john, atStore(sally)). \n The score is: 0.4. ### \n For example 10: The natural language sentences are: tim isn\'t loyal and john is supportive. \n The translated logic program sentences are: loyal(tim). supportive(john). \n The score is: 0.99. ### \n For example 11: The natural language sentences are: Parents are usually loving and supportive. \n The translated logic program sentences are: lovingSupport(X) :- parents(X), not -lovingSupport(X). \n The score is: 0.9. ### \n For example 12: The natural language sentences are: all other birds than hummingbirds migrate south for the winter. \n The translated logic program sentences are: migrationSouthForWinter(allOtherBirds) :- birds(allOtherBirds). \n The score is: 0.9. ### \n For example 13: The natural language sentences are: john is more reliable than jane. \n The translated logic program sentences are: reliable(john, jane). \n The score is: 0.9. ### \n For example 14: The natural language sentences are: jill's evidence is less reliable than steve's. \n The translated logic program sentences are: reliable(steve, jill). \n The score is: 0.9. ### \n For example 15: The natural language sentences are: jill's evidence is less reliable than steve's. \n The translated logic program sentences are: reliable(jill, steve). \n The score is: 0.1. ### \n Note that you only need to output the semantic similarity score. Don\'t output your reasoning or thinking process."     
    Semantic_Score_Prompt_with_ASP_for_LogicEvalD1 = "You are an expert in answer set programming logic and linguistics. Fact in answer set programming is represented as atomic formulas composed of predicates and entities, such as 'predicate1(entity1).' stating that enity1 is predicate1 or entity1 has the property predicate1. Answer set programm rules are represented as logical formulas composed of predicates and variables, such as rule 'predicate2(X) :- predicate1(X), not -predicate2(X).' signifies that if X is predicate1 then X is typically inferred to be predicate2. \n Your task is to evaluate the correctness of the translation from natural language sentences to answer set programming sentences based on syntactic correctness, semantic equivalence, consistency of atomic propositions, and conciseness. You required to provide a final overall score. The score ranges from 0 to 1, where 1 means that the translated logic program is completely correct, while a score of 0 means that the translated logic program sentence is completely wrong. \n The input format is: The natural language sentences are:''. The translated logic program sentences are:''. \n The output format is: The score is:. ### \n For example 1: The natural language sentences are: John and Maria are students in math class. \n The translated logic program sentences are: student(john). student(maria). \n The score is: 0.9. ### \n For example 2: The natural language sentences are: John and Maria are students in math class. \n The translated logic program sentences are: student(maria). \n The score is: 0.3. ### \n For example 3: The natural language sentences are: Usually students with high GPAs get academic scholarships. \n The translated logic program sentences are: high_GPAs(X): academic_scholarships(X) / academic_scholarships(X). \n The score is: 0.95. ### \n For example 4: The natural language sentences are: Usually students with high GPAs get academic scholarships. \n The translated logic program sentences are: academic_scholarships(X). \n The score is: 0.3. ### \n For example 5: The natural language sentences are: However, at their next gig, either John or Jane will not be playing an instrument. \n The translated logic program sentences are: -play_instruments(john) | -play_instruments(jane). \n The score is: 0.99. ### \n For example 6: The natural language sentences are: However, at their next gig, either John or Jane will not be playing an instrument. \n The translated logic program sentences are: -play_instruments(john). \n The score is: 0.4. ### \n For example 7: The natural language sentences are: Even though apples are usually red, this apple was a deep green color. \n The translated logic program sentences are: apple(X) : red(X) / red(X). green_color(green_apple). green_color(X) : -red(X) / -red(X). apple(green_apple). \n The score is: 0.9. ### \n For example 8: The natural language sentences are: Even though apples are usually red, this apple was a deep green color. \n The translated logic program sentences are: apple(X) : red(X) / red(X). \n The score is: 0.4. ### \n For example 9: The natural language sentences are: From experience, John knew that red cars typically had four wheels. \n The translated logic program sentences are: red_car(X): four_wheels(X) / four_wheels(X). \n The score is: 0.99. ### \n For example 10: The natural language sentences are: From experience, John knew that red cars typically had four wheels. \n The translated logic program sentences are: red_car(X) \n The score is: 0.2. ### \n Note that you only need to output the semantic similarity score."    
    Semantic_Score_Prompt_with_ASP_for_LogicEvalD2 = "You are an expert in answer set programming logic and linguistics. Fact in answer set programming is represented as atomic formulas composed of predicates and entities, such as 'predicate1(entity1).' stating that enity1 is predicate1 or entity1 has the property predicate1. Answer set programm rules are represented as logical formulas composed of predicates and variables, such as rule 'predicate2(X) :- predicate1(X), not -predicate2(X).' signifies that if X is predicate1 then X is typically inferred to be predicate2. \n Your task is to evaluate the correctness of the translation from natural language sentences to answer set programming sentences based on syntactic correctness, semantic equivalence, consistency of atomic propositions, and conciseness. You required to provide a final overall score. The score ranges from 0 to 1, where 1 means that the translated logic program is completely correct, while a score of 0 means that the translated logic program sentence is completely wrong. \n The input format is: The natural language sentences are:''. The translated logic program sentences are:''. \n The output format is: The score is:. ### \n For example 1: The natural language sentences are: John, Mike and Emma are students in the same class. \n The translated logic program sentences are: student(john). student(mike). student(emma). same_class(john). same_class(mike). same_class(emma). \n The score is: 0.9. ### \n For example 2: The natural language sentences are: John, Mike and Emma are students in the same class. \n The translated logic program sentences are: t student(emma). same_class(john). \n The score is: 0.3. ### \n For example 3: The natural language sentences are: Normally, employees at that office get free lunch. \n The translated logic program sentences are: employee(X), works_at_office(X) :- free_lunch(X) / free_lunch(X). \n The score is: 0.95. ### \n For example 4: The natural language sentences are: Normally, employees at that office get free lunch. \n The translated logic program sentences are: free_lunch(employee). \n The score is: 0.3. ### \n For example 5: The natural language sentences are: Jenny said the dog dug up the flower bed. \n The translated logic program sentences are: statement(jenny, dug_flowers(dog)). statement(jenny, dug_flowers(dog)) : more_trustworthy(jenny,_) / dug_flowers(dog). \n The score is: 0.99. ### \n For example 6: The natural language sentences are: Jenny said the dog dug up the flower bed. \n The translated logic program sentences are: statement(jenny, dug_flowers(dog)). \n The score is: 0.5. ### \n For example 7: The natural language sentences are: If Mary has debate club during math class, then she does not take quizzes in math class. \n The translated logic program sentences are: in_math_class(mary), has_debate_club(mary) : -takes_quiz(mary) / -takes_quiz(mary). \n The score is: 0.95. ### \n For example 8: The natural language sentences are: If Mary has debate club during math class, then she does not take quizzes in math class. \n The translated logic program sentences are: in_math_class(mary), has_debate_club(mary). \n The score is: 0.4. ### \n For example 9: The natural language sentences are: Usually students in that class submit homework assignments. The translated logic program sentences are: student(X) : submits_homework(X) / submits_homework(X). \n The score is: 0.9. ### \n For example 10: The natural language sentences are: Usually students in that class submit homework assignments. \n The translated logic program sentences are: submits_homework(student). \n The score is: 0.3. ### \n Note that you only need to output the semantic similarity score."     
    Semantic_Score_Prompt_with_ASP_for_LogicEvalD3 = "You are an expert in answer set programming logic and linguistics. Fact in answer set programming is represented as atomic formulas composed of predicates and entities, such as 'predicate1(entity1).' stating that enity1 is predicate1 or entity1 has the property predicate1. Answer set programm rules are represented as logical formulas composed of predicates and variables, such as rule 'predicate2(X) :- predicate1(X), not -predicate2(X).' signifies that if X is predicate1 then X is typically inferred to be predicate2. \n Your task is to evaluate the correctness of the translation from natural language sentences to answer set programming sentences based on syntactic correctness, semantic equivalence, consistency of atomic propositions, and conciseness. You required to provide a final overall score. The score ranges from 0 to 1, where 1 means that the translated logic program is completely correct, while a score of 0 means that the translated logic program sentence is completely wrong. \n The input format is: The natural language sentences are:''. The translated logic program sentences are:''. \n The output format is: The score is:. ### \n For example 1: The natural language sentences are: Typically, devices with thermal sensors also have motion detection capability. \n The translated logic program sentences are: has_thermal_sensor(X), device(X): has_motion_detection(X) / has_motion_detection(X). \n The score is: 0.9. ### \n For example 2: The natural language sentences are: Typically, devices with thermal sensors also have motion detection capability. \n The translated logic program sentences are: has_thermal_sensor(X), device(X): has_motion_detection(X). \n The score is: 0.4. ### \n For example 3: The natural language sentences are: Either a dog has a tail or a horse does not have a mane, or both. \n The translated logic program sentences are: has_tail(dog) | -has_mane(horse). \n The score is: 0.95. ### \n For example 4: The natural language sentences are: Either a dog has a tail or a horse does not have a mane, or both. \n The translated logic program sentences are: has_tail(dog). \n The score is: 0.3. ### \n For example 5: The natural language sentences are: If student Q is in the debate club, then student Q is a good public speaker. \n The translated logic program sentences are: debate_club(student_q) : good_public_speaker(student_q) / good_public_speaker(student_q). \n The score is: 0.99. ### \n For example 6: The natural language sentences are: If student Q is in the debate club, then student Q is a good public speaker. \n The translated logic program sentences are: good_public_speaker(student_q) \n The score is: 0.4. ### \n For example 7: The natural language sentences are: If a student studies computer science, and they are skilled in coding, they can develop software. \n The translated logic program sentences are: student(X), studies_computer_science(X) : skilled_in_coding(X), develop_software(X) / skilled_in_coding(X), develop_software(X). \n The score is: 0.95. ### \n For example 8: The natural language sentences are: If a student studies computer science, and they are skilled in coding, they can develop software.\n The translated logic program sentences are: student(X), studies_computer_science(X) : skilled_in_coding(X), develop_software(X). \n The score is: 0.4. ### \n For example 9: The natural language sentences are: dogs and cats are mammals with fur. \n The translated logic program sentences are: mammals_with_fur(dog). mammals_with_fur(cat). \n The score is: 0.99. ### \n For example 10: The natural language sentences are: dogs and cats are mammals with fur. \n The translated logic program sentences are: mammals_with_fur(dog). \n The score is: 0.4. ### \n Note that you only need to output the semantic similarity score."  
    # Prompt in cautious reasoning mode  # TODO: Manual translation needed
    Credulous_Reasoning_Prompt_for_LogicBench= 'Dask Description: \n Given the extensions and question, and each extension consists of facts. you need to answer the questions according to the given extensions. The question only in "True" or "False". If the question can be inferred based on a certain facts set, the answer label of the question is "True"; if the negation of the question can be inferred based on a certain facts set, the answer label of the question is "False". The input format is: The extension 1 are:''. The extension 2 are:''. The question is:".  The output format is: The answer is:".  \n For example :  The extension 1 are: "Magnus and Malcolm is spurn. Magnus is difficult. Magnus is arrogant. Magnus is nasty. Magnus is dangerous. Magnus is important. Magnus is vast. Magnus is handsome.".  The extension 2 are: "Magnus is not important. Magnus is vast. Magnus is dramatic. Magnus is not handsome. Magnus is poor. Magnus is sensitive.". The question is: "Magnus is important". The output is: "True". The question is: "Magnus is not dramatic. ". The answer is: "False". Note that you only need to generate the answer label for the question without giving an explanation or justification. Please read all extensions carefully and answer the question. '
    # Skeptical reasoning mode, let the large model reason based on the labeling method of skeptical reasoning mode  # TODO: Manual translation needed
    Skeptical_Reasoning_Prompt_for_LogicBench = 'Dask Description: \n Given the extensions and question, and each extension consists of facts. you need to answer the questions according to the given extensions. The question only in "True" or "False". If the question can be inferred based on a certain facts set, the answer label of the question is "True"; if the negation of the question can be inferred based on a certain facts set, the answer label of the question is "False".  The input format is: The extension 1 are:''. The extension 2 are:''. The question is:".  The output format is: The answer is:".  \n For example :  The extension 1 are: "Magnus and Malcolm is spurn. Magnus is difficult. Magnus is arrogant. Magnus is nasty. Magnus is dangerous. Magnus is important. Magnus is vast. Magnus is handsome.".  The extension 2 are: "Magnus is not important. Magnus is vast. Magnus is dramatic. Magnus is not handsome. Magnus is poor. Magnus is sensitive.". The question is: "Magnus is important". The output is: "True". The question is: "Magnus is not dramatic. ". The answer is: "False". Note that you only need to generate the answer label for the question without giving an explanation or justification. Please read all extensions carefully and answer the question. '
    Reasoning_Prompt_for_LogicBench= 'Dask Description: \n Given the extensions and question, and an extension consists of facts by default logic. you need to answer the questions according to the given extensions. The question only in "True" or "False". If the question can be inferred based on the extension, the answer label of the question is "True"; if the negation of the question can be inferred based on a certain facts set, the answer label of the question is "False". The input format is: The extension are:''.  The question is:".  The output format is: The answer is:".  \n For example :  The extension are: "tall(jenny). tall(anna). playBasketball(jenny). playBasketball(anna).".  The question is: "-playBasketball(anna).". The output is: "False". The question is: "tall(anna).". The answer is: "True". \n Note that you only need to generate the answer label for the question without giving an explanation or justification. Please read all extensions carefully and answer the question. '


    # Prompt the model to critique the ASP program  # TODO: Manual translation needed
    Fine_Tune_Generator_Instruction = Prompt_with_Generate_ASP_Code_for_LogicBench if Formal_Natural_Language =='ASP' else Prompt_with_Generate_Default_Logic_Code_for_LogicBench # Represents the fine-tuning prompt, the fine-tuning model prompt is consistent with the reasoning model prompt
    Fine_Tune_Score_Instruction = Semantic_Score_Prompt_with_ASP_for_LogicBench

Yeliang_API_Key = "sk-a8d0bb10d3ae4862a2d79e0f26fa169b" # "sk-wYnDOGnqs7X62a2DEcFa8094B6384f2aAf12AfD88d1dC649", "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b"
Base_URL =  "https://api.deepseek.com/v1" #  "https://api.nhyun.top" #"https://35.aigcbest.top/v1"


Train_Dataset, Test_Datset = None, None
Label2Text = {'T':'True', 'F':'False', 'M':'Unknown'}

llama3_8B_model, llama3_model_tokenizer = None, None
from unsloth import FastLanguageModel

Translated_Sentence_Pattern_for_LogicBench = None
Extract_Fact_Rule_Pattern,Extract_Questions_Pattern = None,None
Extract_Predicate_Pattern, Extract_Entity_Pattern, Translated_Sentence_Pattern = None, None, None

Predicate_Entity_ASP_Pattern, Repair_Sentence_Program_Pattern= None, None
Repair_ASP_Program_Pattern_With_GPT4, Repair_Explanation_With_GPT4 = None, None
Semantic_Score_Pattern, Semantic_Explanation_Pattern, Grammar_Score_Pattern = None, None, None
Aligned_ASP_Pattern = None

# Define template for calling LLAMA31 model to generate ASP extraction results  # TODO: Manual translation needed
Predicate_Entity_ASP_Pattern = ".*?(?=### Step 1)"
Extract_Fact_Rules_Pattern = "(?<=The extracted facts and rules in context are:).*?(?=The extracted questions are|#|Instruction|1```1|```|The entities of the sentence is|\n)"  # Used to extract LLAMA3 output results
Extract_Questions_Pattern = "(?<=The extracted questions are:).*?(?=The reasoning process|The extracted facts and rules in context are correct|The extracted questions are correct|#|Instruction|1```1|```|The entities of the sentence is|\n)"  # Used to extract LLAMA3 output results
Extract_Predicate_Pattern = "(?<=The predicate of the sentence is:).*?(?=The entities of the sentence|#|Instruction|1```1|```|The entities of the sentence is|\n)"  # Used to extract LLAMA3 output results
Extract_Entity_Pattern = "(?<=The entities of the sentence are:).*?(?=The translated formal logic program sentence|#|Instruction|Instantiation|1```1|```|The translated formal logic program sentence is|\n)"  # Used to extract LLAMA3 output results
Veritier_Fact_Rules_Pattern = "(?<=The verification result is:).*?(?=#|Instruction|1```1|```|The entities of the sentence is|\n)"  # Used to extract LLAMA3 output results
Veritier_Suggestion_Pattern = "(?<=The suggestion of extracted facts and default rules is:).*?(?=#|Instruction|1```1|```|The entities of the sentence is|\n)"  # Used to extract LLAMA3 output results

Translated_Sentence_Pattern = "(?<=The translated formal logic program sentence is:).*?(?=\.|Note|###|Instruction|1```1|Final Answer|```|\n)"  # Used to extract LLAMA3 output results # Final Answer:
Translated_Sentence_Pattern_for_LogicBench = "(?<=The translated formal logic program sentence is:).*?(?=Note|###|Instruction|1```1|Final Answer|```|\n)"  # Used to extract LLAMA3 output results # Final Answer:

# Define template for directly calling LLAMA31 model to repair extraction results  # TODO: Manual translation needed
Aligned_ASP_Pattern = "(?<=The aligned formal logic program are:).*?(?=#|Note|#|The score of the aligned logic program are|Instruction|1```1|Final Answer|```|\n)"  # Used to extract LLAMA3 output results # Final Answer:
# Define template for directly calling LLAMA31 model to repair extraction results  # TODO: Manual translation needed
Repair_Sentence_Program_Pattern = "(?<=The reextracted sentence is:).*?(?=Note|###|Instruction|1```1|Final Answer|```|\n)" # Used to extract LLAMA3 output results during repair iteration
# Define template for directly calling GPT4o repair module extraction results  # TODO: Manual translation needed
Repair_ASP_Program_Pattern_With_GPT4 = "(?<=Repaired ASP program is:).*?(?=The repair explanation is|###|Instruction|1```1|Final Answer|```|\n)" # Used to extract LLAMA3 output results during repair iteration
Repair_Explanation_With_GPT4 = "(?<=The repair explanation is:).*?(?=#|Instruction|1```1|Final Answer|```|\n)" # Used to extract LLAMA3 output results during repair iteration
# Define template for extraction results in critique module  # TODO: Manual translation needed
Critic_Result_Pattern = "(?<=The result of verification is:).*?(?=#|The verification explanation is|Instruction|1```1|Final Answer|```|\n)"
Critic_Explanation_Pattern = "(?<=The verification explanation is:).*?(?=#|Instruction|1```1|Final Answer|```|\n)"

Semantic_Score_Pattern = "(?<= is:).*?(?=#|The explanation is|The natural language sentences are|1```1|Final Answer|```|\n)"
Semantic_Explanation_Pattern = "(?<=explanation is:).*?(?=#|Instruction|1```1|Final Answer|```|\n)"

Grammar_Score_Pattern = "(?<=score is:).*?(?=#|The logical program sentences are|1```1|Final Answer|```|\n)"

# Define a model for calculating similarity based on embedding  # TODO: Manual translation needed
# Load model from HuggingFace Hub
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
embedding_tokenizer = AutoTokenizer.from_pretrained('/home/yeliangxiu/Projects/Pre_trained_Models/distilbert-base-nli-stsb-mean-tokens')
embedding_model = AutoModel.from_pretrained('/home/yeliangxiu/Projects/Pre_trained_Models/distilbert-base-nli-stsb-mean-tokens').to(device)

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] #First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

# Define a function for calculating similarity based on embedding  # TODO: Manual translation needed
def Embedding_Similarity(str1, str2):
    # # Convert sentences to vector representation  # TODO: Manual translation needed
    # sentence1_embedding = sentence_transformersmodel.encode(str1)
    # sentence2_embedding = sentence_transformersmodel.encode(str2)
    # # Calculate similarity between sentences  # TODO: Manual translation needed
    # cosine_similarity = util.cos_sim(sentence1_embedding, sentence2_embedding)

    encoded_input01 = embedding_tokenizer(str1, padding=True, truncation=True, return_tensors='pt').to(device)
    # Compute token embeddings
    with torch.no_grad():
        model_output01 = embedding_model(**encoded_input01)
    # Perform pooling. In this case, max pooling.
    sentence_embeddings01 = mean_pooling(model_output01, encoded_input01['attention_mask'])

    encoded_input02 = embedding_tokenizer(str2, padding=True, truncation=True, return_tensors='pt').to(device)
    # Compute token embeddings
    with torch.no_grad():
        model_output02 = embedding_model(**encoded_input02)
    # Perform pooling. In this case, max pooling.
    sentence_embeddings02 = mean_pooling(model_output02, encoded_input02['attention_mask'])
    cosine_similarity = util.cos_sim(sentence_embeddings01, sentence_embeddings02)

    return cosine_similarity


# Define a Tree_Search class  # TODO: Manual translation needed
class Tree_Search:
    """
    Monte Carlo tree search class, used to gradually translate sentences in context into ASP sentences.
    """

    def __init__(self, exploration_weight=1):

        # Use dictionary structure to store child nodes of each node  # TODO: Manual translation needed
        # Initialize as empty dictionary, gradually add child nodes as search progresses  # TODO: Manual translation needed
        # Key is parent node, value is the set of all child nodes of this node  # TODO: Manual translation needed
        self.children = dict() # Used to store MCTS tree structure
        self.exploration_weight = exploration_weight  # Exploration weight

    def _Tree_Search(self, node):
        "Returns the reward for a random simulation (to completion) of `node`"
        while True:
            if node.is_terminal():
                return node
            node = node.find_children()


class Node(ABC):
    """
    Representation of a single board state.
    MCTS works by constructing a tree of these nodes.
    Can be a board state such as chess or checkers.
    """

    @abstractmethod
    def find_children(self):
        """All possible successors of this board state"""
        return set()
    

    @abstractmethod
    def is_terminal(self):
        """Return True if node has no children"""
        return True


    @abstractmethod
    def __hash__(self):
        """Node must be hashable"""
        return 123456789

    @abstractmethod
    def __eq__(node1, node2):
        """Node must be comparable"""
        return True

# Load test model for inference, first load is the untuned model, subsequent loads are the fine-tuned model  # TODO: Manual translation needed
# When Expert_Iterative_Number=0, load the untuned model  # TODO: Manual translation needed


def DeepSeek_Solver(instructions, context):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key)
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="deepseek-reasoner", # deepseek-chat(DeepSeek-V3-0324); deepseek-reasoner(DeepSeek-R1-0528)
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context}
                ],
              temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send error {while_count01 + 1}attempts: {e}")
            while_count01 += 1
    return ""

class Context:
    # get features/words from a string of space separated words
    def gen_feature(self, x):
        ret = []
        for term in str(x.string).split(' '):
            ret.append(parse_term(term))
        return ret
# ASP language verifier  # TODO: Manual translation needed
def ASP_Verifier_Solver(translated_context_sentences,Context_ASP_Text, opt=False):
    """
        Args:
            program (str): a string of ASP program
            opt (bool): if true, only optimal answer sets are returned
                        leave it to False when there is no weak constraint
        args of Control: args that will be passed to the solver.
            --models: the num of models that are output, would output all models when 0
            --opt-mode: optimization mode, opt or ignore, etc.
            --parallel-mode: num of parallel threads, set to 4 here.
        """
    Context_ASP_Text = translated_context_sentences + Context_ASP_Text
    clingo_control = Control(['--models=0', '--warn=none', '--opt-mode=optN', '-t', '4'])
    models = []
    try:
        clingo_control.add('base', [], Context_ASP_Text)
        clingo_control.ground([('base', [])], context=Context())
    except Exception as e:
        # breakpoint()
        #print('e={}'.format(e))
        return ["error",str(e)]
    if opt:
        clingo_control.solve(
            on_model=lambda model: models.append(model.symbols(atoms=True)) if model.optimality_proven else None)
    else:
        clingo_control.solve(on_model=lambda model: models.append(model.symbols(atoms=True)))
    models = [[str(atom) for atom in model] for model in models]
    return models


# Define a function to call LLAMA3.1 model, requiring the model to return question answers based on instructions  # TODO: Manual translation needed
def Calling_LLAMA3_with_API(Instruction, Context_Text_String):
    return DeepSeek_Solver(Instruction, Context_Text_String)

# Define a semantic verifier based on large models, requiring calculation of semantic similarity between natural language sentences and translated ASP sentences  # TODO: Manual translation needed
def Semantic_Similarity_Checker(context_sentence, translated_sentence, model_name, model_tokenizer, Similarity_with_LLAMA31_Flag, Similarity_with_Sentence_Transformer_Flag, Similarity_with_GPT4_Flag):
    # Use GPT-4o to calculate semantic similarity  # TODO: Manual translation needed
    response = None
    Context = f"The natural language sentences are: {context_sentence}\n The formal logic program Sentences are: {translated_sentence}"
    # Use GPT-4o to calculate semantic similarity  # TODO: Manual translation needed
    # Use LLAMA3.1 to calculate semantic similarity  # TODO: Manual translation needed
    
    similarity_score = 0.5
    while_count02 = 0
    while True:
        if while_count02 >= 2:  # If LLAMA3.1 is called more than 10 times, return default value 0.5
            print("Use default value 0.5")
            similarity_score = 0.5
            break
        simlarity_response = Calling_LLAMA3_with_API(Semantic_Score_Prompt_with_ASP_for_LogicBench, Context)
        simlarity_response = simlarity_response.split('</think>')[-1]
        if 'is:' not in simlarity_response:
            simlarity_response = ' is:' + simlarity_response
        simlarity_response = simlarity_response.replace('\n','')
        while_count02 = while_count02 +1
        # Get similarity score from generated string  # TODO: Manual translation needed
        # Use regular expression to extract similarity score  # TODO: Manual translation needed
        if len(simlarity_response) > 0:
            simlarity_response = simlarity_response + '###' if simlarity_response[-1] != '#' else simlarity_response

        similarity_score_list = re.findall(Semantic_Score_Pattern, simlarity_response)

        if len(similarity_score_list) > 0:
            try:    
                similarity_score = similarity_score_list[0].replace(' ','')
                similarity_score = float(similarity_score[:-1].replace(' ','')) if similarity_score[-1] == '.' else float(similarity_score.replace(' ',''))
                # Determine if score is a natural number, otherwise regenerate score  # TODO: Manual translation needed
                if not (isinstance(similarity_score, float) or similarity_score < 0 or similarity_score > 1):
                    print("Similarity score not in [0,1] range or format error, regenerate score, simlarity_response={}".format(simlarity_response))
                    continue
                else:
                    break
            except Exception as e:
                print("Semantic_Similarity_Checker cannot parse similarity score, use default value 0.5, simlarity_response={}".format(simlarity_response))
                similarity_score = 0.5
                break
    return similarity_score

# Define predicate consistency alignment function, context_asp_sentences represents already translated ASP sentences in context, translated_asp_sentence represents currently translated ASP sentence  # TODO: Manual translation needed
def Predicate_Consistency_Alignment(context_sentences, extracted_context_predicates, extracted_context_entities, context_asp_sentences, next_extracted_predicates,next_nl_sentences, next_asp_sentence, llama3_8B_model, llama3_model_tokenizer):

    Total_Context_NL_Sentences =  next_nl_sentences
    Total_Context_ASP_Sentences =  next_asp_sentence 
    Total_Extracted_Predicates = extracted_context_predicates
    Total_Extracted_Entities = extracted_context_entities
    total_context_asp_sentences = 'The natural language sentences are:' + Total_Context_NL_Sentences + ' The extracted predicates list are:' + Total_Extracted_Predicates + ' The extracted entities list are:' + Total_Extracted_Entities + ' The formal logic program that needs to be aligned are:' + Total_Context_ASP_Sentences
    # Call large model to align semantically similar predicates.  # TODO: Manual translation needed
    Aliged_Context_ASP_Sentences = ''
    while_count01 = 0
    while True:

        Models_Results = Calling_LLAMA3_with_API(Prompt_with_Predicate_Consistency_Alignment_for_LogicBench, total_context_asp_sentences)
        Models_Results = Models_Results.replace('\n','').replace('`','').replace(' .','. ')
        Models_Results = Models_Results.split('</think>')[-1]
        if len(Models_Results) > 0:
            Models_Results = Models_Results + '###' if Models_Results[-1] != '#' else Models_Results
        Aliged_Context_ASP_Sentences_list = re.findall(Aligned_ASP_Pattern, Models_Results)
        if len(Aliged_Context_ASP_Sentences_list) > 0:
            Aliged_Context_ASP_Sentences = Aliged_Context_ASP_Sentences_list[0].replace('\n','').strip()
        elif 'The aligned logic program are:' in Models_Results:
            Aliged_Context_ASP_Sentences = Models_Results.replace('The aligned logic program are:','').strip()
        elif 'The aligned formal logic program are:' in Models_Results:
            Aliged_Context_ASP_Sentences = Models_Results.replace('The aligned formal logic program are:','').strip()
        elif 'The aligned formal logic program is:' in Models_Results:
            Aliged_Context_ASP_Sentences = Models_Results.replace('The aligned formal logic program is:','').strip()
        elif 'The aligned logic program would be:' in Models_Results:
            Aliged_Context_ASP_Sentences = Models_Results.replace('The aligned logic program would be:','').strip()
        elif 'The aligned logic program is:' in Models_Results:
            Aliged_Context_ASP_Sentences = Models_Results.replace('The aligned logic program is:','').strip()
        else:
            Aliged_Context_ASP_Sentences = ''
        Aliged_Context_ASP_Sentences_list01 = Aliged_Context_ASP_Sentences.split('#')
        Aliged_Context_ASP_Sentences = Aliged_Context_ASP_Sentences_list01[0].replace('\n','')
        while_count01 = while_count01 + 1
        # Evaluate semantic similarity between aligned ASP sentences and natural language  # TODO: Manual translation needed
       
        if while_count01 >5: # If predicate alignment fails, directly return ASP sentence before alignment
            Aliged_Context_ASP_Sentences = context_asp_sentences
            print('Context predicate alignment failed! ASP sentence before predicate alignment: {}. ASP sentence after predicate alignment: {}'.format(context_asp_sentences, Aliged_Context_ASP_Sentences))
            break
        elif len(Aliged_Context_ASP_Sentences) > 10:
            break
        else:
            Aliged_Context_ASP_Sentences = ''
            continue
    
    return Aliged_Context_ASP_Sentences

  

# Define a function to convert default rules into logic programs.  # TODO: Manual translation needed
# sentence_to_be_translated: natural language sentence to be translated, DLsentence: generated default rule  # TODO: Manual translation needed
def DL2ASP(sentence_to_be_translated,All_DLsentence):
    # Convert default rules to ASP logic programs  # TODO: Manual translation needed
    # Process input default rule string  # TODO: Manual translation needed
    # Convert default rules to ASP logic programs  # TODO: Manual translation needed
    # Process input default rule string  # TODO: Manual translation needed
    All_DLsentence = All_DLsentence.replace(" ", "").replace(".", "").replace("¬", "-").replace("∨", ", ").replace("∧", ", ").replace("∼","-").replace('!','').replace('not','-').replace('~','-')  # Remove spaces and periods
    DLsentence_list01 = All_DLsentence.split('.') # Divide DL rules, one sentence translation may generate multiple default rules.
    DLsentence_list = []
    for key in range(len(DLsentence_list01)):
        if len(DLsentence_list01[key])>5:
            dl_sentence = DLsentence_list01[key]
            DLsentence_list.append(dl_sentence)
    total_dl2asp_sentence = ''
    for dl_key in range(len(DLsentence_list)):
        DLsentence = DLsentence_list[dl_key]
        # Separate rule head and body  # TODO: Manual translation needed
        if ":" not in DLsentence or "/" not in DLsentence:
            print('Input default rule format error!')
            return ''
        try:    
            prerequisites, justification_conclusion = DLsentence.split(":")
        except Exception as e:
            print('Input default rule format error!')
            return ''
        try:    
            justification, conclusion = justification_conclusion.split("/")
        except Exception as e:
            print('Input default rule format error!')
            return ''
        
        # Process rule head  # TODO: Manual translation needed
        heads = prerequisites.split("∧") if "∧" in prerequisites else [prerequisites]
        head_predicates = []
        for h in heads:
            if h.startswith("-"):
                head_predicates.append(f" -{h[1:]}")
            else:
                head_predicates.append(h)
                
        # Process prerequisites  # TODO: Manual translation needed
        justification_predicates = []

        # Use regular expression to match predicates, avoid incorrectly splitting commas in binary predicates  # TODO: Manual translation needed
        # Prohibit splitting commas inside parentheses  # TODO: Manual translation needed
        # Use regular expression to match commas not in parentheses for splitting  # TODO: Manual translation needed
        def split_outside_parentheses(s):
            result = []
            current = ''
            depth = 0
            for char in s:
                if char == '(':
                    depth += 1
                    current += char
                elif char == ')':
                    depth -= 1
                    current += char
                elif char == ',' and depth == 0:
                    result.append(current)
                    current = ''
                else:
                    current += char
            if current:
                result.append(current)
            return [item.strip() for item in result if item.strip() != '']

        justification_list = split_outside_parentheses(justification)
        if len(justification_list) == 0:
            print('Consistency condition of default rule is empty!')
            justification_predicates = []
        else:
            for p in justification_list:
                if p.startswith("-"):
                    justification_predicate01 = f" {p[1:]}"
                    justification_predicates.append(justification_predicate01)
                else:
                    justification_predicate01 = f" -{p[0:]}"
                    justification_predicates.append(justification_predicate01)
                    
        # Process conclusion  # TODO: Manual translation needed
        # if ',' in conclusion: # If conclusion contains comma, it means multiple conclusions  # TODO: Manual translation needed
        #     return ''
        if conclusion.startswith("-"):
            conclusion_predicate = f" -{conclusion[1:]}"
        else:
            conclusion_predicate = conclusion
            
        # Build ASP rule  # TODO: Manual translation needed
        asp_rule = conclusion_predicate + " :- "
        # Add prerequisites again  # TODO: Manual translation needed
        for head_pred in head_predicates:
            if len(justification_predicates)>0:
                asp_rule += head_pred + ", " 
            else:
                asp_rule += head_pred + ". "

        # Add consistency conditions again  # TODO: Manual translation needed
        if len(justification_predicates) > 0:
            for key01 in range(len(justification_predicates)):
                justification_predicates[key01] = justification_predicates[key01].replace(' ','') # Remove spaces
                if key01 != len(justification_predicates) - 1:
                    asp_rule += f" not {justification_predicates[key01]}, "
                else:
                    asp_rule += f" not {justification_predicates[key01]}."

        asp_rule = asp_rule.replace("not - -", "not ").replace("not -–", "not ").replace(' --',' ').replace('(x)','(X)').replace('(a)','(X)').replace('(b)','(Y)').replace('(a,b)','(X,Y)')
        total_dl2asp_sentence = total_dl2asp_sentence + asp_rule
    print('Natural language sentence: {}, input default rule: {}, converted ASP rule: {}'.format(sentence_to_be_translated, All_DLsentence, total_dl2asp_sentence))
        
    return total_dl2asp_sentence
# Define a function to re-abstract natural language sentences that fail translation verification  # TODO: Manual translation needed
# NL_Context represents original context, Extracted_Context represents extracted facts and default rules, Reabstraction_Sentence represents sentence to be re-extracted. Error_message represents error information, used as feedback  # TODO: Manual translation needed
def Reastraction_Sentence_with_Context(Dataset_Type,Reabstraction_Sentence, Error_message):
    global Origin_Context_List, Origin_Question_List,Astraction_Sentence_List,Astraction_Question_List

    NL_Context = ' '.join(Origin_Context_List)
    Questions = ' '.join(Origin_Question_List)
    Extracted_Context = ' '.join(Astraction_Sentence_List)
    Extracted_Question = ' '.join(Astraction_Question_List)
    Result_sentence = ''
    Extract_Sentence_list = []
    Models_Results = ''
    if Dataset_Type!='question': # When context
        Context_Input_Format_String = 'The natural language context sentences are: '+ NL_Context + ' ### \n. The questions are: '+ Extracted_Question + ' ### \n. The extracted sentences are: '+ Extracted_Context + ' ### \n. The incorrectly formalized natural language sentence is: '+ Reabstraction_Sentence + ' ### \n. The error message is: '+ Error_message + ' ### \n. '
        Models_Results = Calling_LLAMA3_with_API(Prompt_with_Extract_Sentence_from_Context, Context_Input_Format_String,1)[0]
    else:
        Context_Input_Format_String = ' ### \n. The questions are: '+ Questions + ' ### \n. The extracted Question are: '+ Extracted_Question + ' ### \n. The incorrectly formalized natural language sentence is: '+ Reabstraction_Sentence + ' ### \n. The error message is: '+ Error_message + ' ### \n. '
        Models_Results = Calling_LLAMA3_with_API(Prompt_with_Extract_Sentence_from_Context, Context_Input_Format_String,1)[0]

    Models_Results = Models_Results.split('</think>')[-1] if '</think>' in Models_Results else Models_Results
    Models_Results = Models_Results.replace('\n','')
    if len(Models_Results) > 0:
        Models_Results = Models_Results + '###' if Models_Results[-1] != '#' else Models_Results
    Models_Results = Models_Results.replace("The reextracted sentence are","The reextracted sentence is").replace('The reextracted sentence in context are','The reextracted sentence is')
    Extract_Sentence_list = re.findall(Repair_Sentence_Program_Pattern, Models_Results) # Returns a list
    Result_sentence = Extract_Sentence_list[0] if len(Extract_Sentence_list) > 0 else Reabstraction_Sentence
    # If the re-extracted sentence in abstraction module still contains multiple sentences, we select the first one  # TODO: Manual translation needed
    Result_Sentence_List = Result_sentence.split('. ')
    if len(Result_Sentence_List) > 1:
        Result_sentence = Result_Sentence_List[0] + '.'
    return Result_sentence

'''
The input format is: The context sentence is:''. The translated context sentence is:''. The extracted predicates are:''. The extracted entities are:''. The sentence to be translated is:''. \n  
The output format is: The predicate used in the sentence is:''. \n  The entities in the sentence is:''. \n The translated ASP program of the sentence is:''. \n
'''
# Define a function to call large model to translate a sentence  # TODO: Manual translation needed
# Define a function to call large model to translate a sentence  # TODO: Manual translation needed

def LLM_ASP_Solver_Single_Sentence(Dataset_Type, context_sentences, translated_context_asp_sentences, translated_context_default_logic_sentences, extracted_predicates, extracted_entities, sentence_to_be_translated, llama3_8B_model, llama3_model_tokenizer, fine_tune_f2):
    '''
    context_sentences: already translated context natural language sentences
    translated_context_sentences: translated context corresponding ASP sentences
    extracted_predicates: extracted predicates
    extracted_entities: extracted entities
    sentence_to_be_translated: sentence to be translated
    llama3_8B_model: loaded large model
    llama3_model_tokenizer: large model tokenizer
    '''

    Translated_ASP_Program_of_Sentence, Translated_ASP_Program_of_Sentence_list = '', [''] # Used to store currently translated ASP sentences
    Origin_Translated_ASP_Program_of_Sentence = '' # Used to store original ASP sentences
    Repaired_Translated_ASP_Program_of_Sentence = '' # Used to store repaired ASP sentences
    Repaired_Translated_ASP_Program_of_Sentence_list = [''] # Used to store repaired ASP sentenceslist
    Repair_Explanation = '' # Used to store repair explanation
    verifier_result = '' # Used to store ASP solver verification results
    Critic_Result = '' # Used to store critique results
    Critic_Explanation = '' # Used to store critique explanation
    Explanation = '' # Used to store explanation
    Translated_Input_Format_String = '' # Used to store input format string

    reastraction_count = 0
    while True: # If all symbol verifiers of candidate formalized sentences error, re-extract sentences and re-translate
        
        if reastraction_count >=2:
            print('Number of calls to abstraction module feedback mechanism reached limit!')
            break
        reastraction_count = reastraction_count + 1

        if Formal_Natural_Language == 'ASP':
            Translated_Input_Format_String = 'The natural language context sentences are: '+ context_sentences + '.'+ ' The extracted predicates are: ' + extracted_predicates + ' The extracted entities are: ' + extracted_entities + ' The translated formal logic program context sentences are: ' + translated_context_asp_sentences + '\n' + ' The natural language sentence to be translated is: '+ sentence_to_be_translated + '\n'  
        else:
            # 'The natural language context sentences are: '+ context_sentences + 'The translated formal logic program context sentences are: ' + translated_context_default_logic_sentences + '\n' +
            # The natural language context sentences are: '+ context_sentences + '.' + ' The extracted predicates are: ' + extracted_predicates + ' The extracted entities are: ' + extracted_entities + ' The translated formal logic program context sentences are: ' + translated_context_default_logic_sentences + '\n' +
            Translated_Input_Format_String = 'The natural language context sentences are: '+ context_sentences + '.' + ' The extracted predicates are: ' + extracted_predicates + ' The extracted entities are: ' + extracted_entities + ' The translated formal logic program context sentences are: ' + translated_context_default_logic_sentences + '\n' +  'The natural language sentence to be translated is: '+ sentence_to_be_translated + '\n'

        while_Count0 = 0
        verifier_result = ''
        # For each sentence, consider translating multiple times, then call verifier for verification, if verification fails use as negative sample for fine-tuning, if verification succeeds use as positive sample;  # TODO: Manual translation needed
        # Define translation count for each sentence  # TODO: Manual translation needed
        global Translation_Sentences_Number
        Total_Entities_in_ASP_Sentence_Lists, Total_Predicate_Used_in_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists = [], [], []
        Total_Verfier_Result_Lists, Total_Translated_ASP_Program_of_Sentence_Lists,Total_Translated_Default_Logic_of_Sentence_Lists = [], [], []
        Semantic_Score_Lists = [] # Used to store all candidate semantic consistency scores
        Translated_DL_Program_of_Sentence, Translated_ASP_Program_of_Sentence = '', ''
        Translation_Number01 = Translation_Sentences_Number # Represents the number of generated candidate ASP sentences, default translation count is 1
        while_Count01 = 0
        Semantic_count01 = 0
        verifier_count = 1

        Predicate_Used_in_Sentence, Entities_in_Sentence = '','' # Used to store currently translated extracted predicates and entities
        Models_Results_List,Models_Results =[], ''
        Translated_DL_Program_of_Sentence, Translated_ASP_Program_of_Sentence = '', ''
        semantic_score,verifier_result = None,None

        if Formal_Natural_Language == 'DL':
            Models_Results_List = Calling_LLAMA3_with_API(Prompt_with_Generate_Default_Logic_Code_for_LogicBench, Translated_Input_Format_String,Translation_Number01,0.7)
        elif Formal_Natural_Language == 'ASP':
            Models_Results_List = Calling_LLAMA3_with_API(Prompt_with_Generate_ASP_Code_for_LogicBench, Translated_Input_Format_String,Translation_Number01,0.7)
        else:
            print('Formal_Natural_Language input error!')


        while True:
            if while_Count01 >=5: # If translation count (including normal and error cases) reaches limit, and grammar verification has no errors, break out of loop
                print('Sentence translation count reached limit! Translation result error!')
                if len(Total_Verfier_Result_Lists) !=0 and len(Total_Translated_ASP_Program_of_Sentence_Lists) !=0:
                    Aligned_Translated_ASP_Program_of_Sentence = Translated_ASP_Program_of_Sentence
                    break
                else:   # After multiple attempts, still cannot satisfy semantic detection
                    if len(Translated_DL_Program_of_Sentence)>0:
                        Total_Verfier_Result_Lists=[['']] # Add verification results to list
                        Total_Entities_in_ASP_Sentence_Lists.append(Entities_in_Sentence)
                        Total_Predicate_Used_in_Sentence_Lists.append(Predicate_Used_in_Sentence)
                        Total_Translated_ASP_Program_of_Sentence_Lists.append(Translated_ASP_Program_of_Sentence)
                        Total_Translated_Default_Logic_of_Sentence_Lists.append(Translated_DL_Program_of_Sentence)
                        Semantic_Score_Lists.append(semantic_score)  
                    else:
                        Total_Verfier_Result_Lists=[['error']] # Add verification results to list
                    break
            # If translation count reaches limit, and grammar verification has no errors, break out of loop  # TODO: Manual translation needed
            if len(Total_Translated_ASP_Program_of_Sentence_Lists) >= Translation_Number01:
                print('Candidate ASP sentence translation count reached limit! Translated candidate ASP sentence list: {}'.format(Total_Translated_ASP_Program_of_Sentence_Lists))
                break
            # Step 1: Call large model to first translate facts/rules into ASP. Deduction step first extracts predicates, then translates multiple candidate sentences  # TODO: Manual translation needed
            Models_Results = ''
            Aligned_Translated_ASP_Program_of_Sentence = ''
            Translated_DL_Program_of_Sentence, Translated_ASP_Program_of_Sentence = '', ''

            Models_Results = Models_Results_List[while_Count01] if len(Models_Results_List)>while_Count01 else ''

            Models_Results = Models_Results.replace('\n','').replace('`','').replace(' .','. ')
            Models_Results = Models_Results.split('</think>')[-1]
            if len(Models_Results) > 0:
                Models_Results = Models_Results + '###' if Models_Results[-1] != '#' else Models_Results
            # Parse large model output results  # TODO: Manual translation needed
            # Step 1 first extract all answers  # TODO: Manual translation needed
            while_Count01 = while_Count01 + 1
            Models_Results = Models_Results.replace("The entities of the sentence is","The entities of the sentence are")
            Models_Results = Models_Results.replace("The translated sentence is","The translated formal logic program sentence is")
            Predicate_Used_in_Sentence_list = re.findall(Extract_Predicate_Pattern, Models_Results) # Returns a list
            Entities_in_Sentence_list = re.findall(Extract_Entity_Pattern, Models_Results)
            if 'The translated formal logic program sentence is:' not in Models_Results:
                    continue
            if Formal_Natural_Language == 'DL':
                Translated_DL_Program_of_Sentence_list = re.findall(Translated_Sentence_Pattern_for_LogicBench, Models_Results)
            else:
                Translated_DL_Program_of_Sentence_list = re.findall(Translated_Sentence_Pattern, Models_Results)
            Translated_DL_Program_of_Sentence_list00 = []
            for key01 in range(len(Translated_DL_Program_of_Sentence_list)):
                if len(Translated_DL_Program_of_Sentence_list[key01])>10:
                    Translated_DL_Program_of_Sentence_list00.append(Translated_DL_Program_of_Sentence_list[key01])
            Translated_DL_Program_of_Sentence_list = copy.deepcopy(Translated_DL_Program_of_Sentence_list00)        

            if len(Translated_DL_Program_of_Sentence_list) == 0:
                print('Failed to extract translated formal sentence, re-translate Models_Results={}'.format( Models_Results))
                continue

            # Extract sentence between "The translated default logic of the sentence is:" and "." in Models_Results using regular expression  # TODO: Manual translation needed
            Predicate_Used_in_Sentence, Entities_in_Sentence = '','' # Used to store currently translated extracted predicates and entities
            if len(Predicate_Used_in_Sentence_list) != 0:
                for predicate in Predicate_Used_in_Sentence_list:
                    Predicate_Used_in_Sentence = Predicate_Used_in_Sentence + predicate.replace('.',',').replace('#','')
            else:
                print('Predicate extraction failed!')
                Predicate_Used_in_Sentence = ''

            if len(Entities_in_Sentence_list) != 0:
                for entity in Entities_in_Sentence_list:
                    Entities_in_Sentence = Entities_in_Sentence + entity.replace('.',',').replace('#','')
            else:
                print('Entity extraction failed!')
                Entities_in_Sentence = ''
            if len(Translated_DL_Program_of_Sentence_list) != 0 and len(Translated_DL_Program_of_Sentence_list[0]) > 2:
                dl_sentence = Translated_DL_Program_of_Sentence_list[0]+'.'
                Translated_DL_Program_of_Sentence = dl_sentence.replace('#','').replace('. ','.').replace(',.','.').replace('..','.').replace('. .','. ').replace('"','')
            else:
                print('Format error in step 1 translation output, re-translate!while_Count01={}'.format(while_Count01))
                continue

            # If generated is a default rule, need to convert it to ASP rule  # TODO: Manual translation needed
            if Formal_Natural_Language == 'DL':
                Translated_DL_Program_of_Sentence_list02 =[]
                Translated_DL_Program_of_Sentence_list01 = Translated_DL_Program_of_Sentence.split('.')
                for key in range(len(Translated_DL_Program_of_Sentence_list01)): # Translated sentence may contain multiple formalized sentences, split by ., if split sentence length is greater than 2, convert DL rules to ASP rules sentence by sentence
                    if len(Translated_DL_Program_of_Sentence_list01[key]) > 2:
                        candidate_dl_sentence01 = Translated_DL_Program_of_Sentence_list01[key] + '.'
                        candidate_dl_sentence01 = candidate_dl_sentence01.replace(' (','(')
                        Translated_DL_Program_of_Sentence_list02.append(candidate_dl_sentence01)

                for key in range(len(Translated_DL_Program_of_Sentence_list02)):
                    candidate_dl_sentence = Translated_DL_Program_of_Sentence_list02[key]
                    if ':' in candidate_dl_sentence and '/' not in candidate_dl_sentence: # If generated sentence has no /, it means it is a default rule
                        print('Generated default rule format error, re-translate!while_Count01={}'.format(while_Count01))
                        continue
                    if ':' not in candidate_dl_sentence and '/' in candidate_dl_sentence: # If generated sentence has no :, it means it is a deductive rule
                        print('Generated default rule format error, re-translate!while_Count01={}'.format(while_Count01))
                        continue
                    if ':' in candidate_dl_sentence and '/' in candidate_dl_sentence:
                        candidate_asp_sentence = DL2ASP(sentence_to_be_translated, candidate_dl_sentence)
                        # If translation error occurs, break out of loop  # TODO: Manual translation needed
                        if len(candidate_asp_sentence) == 0:
                            continue
                    else:
                        candidate_dl_sentence = candidate_dl_sentence.replace('∧','. ')
                        candidate_asp_sentence = candidate_dl_sentence.replace('¬', '-')
                    Translated_ASP_Program_of_Sentence = Translated_ASP_Program_of_Sentence + candidate_asp_sentence
            else:
                Translated_ASP_Program_of_Sentence = Translated_DL_Program_of_Sentence.replace('∧','. ')
                Translated_ASP_Program_of_Sentence = Translated_ASP_Program_of_Sentence.replace('¬', '-').replace('- ','-')

            # After translation completes, perform predicate consistency alignment  # TODO: Manual translation needed
            if Aligned_Rules_Flag==True: # If performing predicate consistency alignment, need to merge ASP sentences in context
                if Aligned_Rules_Flag == True and len(translated_context_asp_sentences) > 0: # If performing predicate consistency alignment, need to merge ASP sentences in context
                    Aligned_Translated_ASP_Program_of_Sentence = Predicate_Consistency_Alignment(context_sentences, extracted_predicates, extracted_entities, translated_context_asp_sentences, Predicate_Used_in_Sentence, sentence_to_be_translated, Translated_ASP_Program_of_Sentence, llama3_8B_model, llama3_model_tokenizer)
                    if len(Aligned_Translated_ASP_Program_of_Sentence) == 0:
                        print('Predicate consistency alignment failed, re-translate!while_Count01={}'.format(while_Count01))
                        continue
                    if Dataset_Type == 'question':
                        # Determine if number of aligned sentences matches number before alignment  # TODO: Manual translation needed
                        Aligned_Translated_ASP_Program_of_Sentence_list = Aligned_Translated_ASP_Program_of_Sentence.split('.')
                        before_aligned_asp_sentence_list = Translated_ASP_Program_of_Sentence.split('.')
                        if len(Aligned_Translated_ASP_Program_of_Sentence_list) != len(before_aligned_asp_sentence_list):
                            print('questionPredicate consistency alignment failed, re-translate!while_Count01={},Aligned_Translated_ASP_Program_of_Sentence={}, Translated_ASP_Program_of_Sentence={}'.format(while_Count01, Aligned_Translated_ASP_Program_of_Sentence, Translated_ASP_Program_of_Sentence))
                            continue
                else:
                    Translated_ASP_Program_of_Sentence = Translated_ASP_Program_of_Sentence[:-1] + '.' if Translated_ASP_Program_of_Sentence[-1] == ',' else Translated_ASP_Program_of_Sentence
                    Aligned_Translated_ASP_Program_of_Sentence = Translated_ASP_Program_of_Sentence

                print('ASP sentence before alignment: {}, ASP sentence after predicate consistency alignment: {}'.format(Translated_ASP_Program_of_Sentence, Aligned_Translated_ASP_Program_of_Sentence))
            else:
                Aligned_Translated_ASP_Program_of_Sentence = Translated_ASP_Program_of_Sentence

                # Step 2: Call symbol verifier to verify single sentence translated_context_asp_sentences  # TODO: Manual translation needed
            verifier_result = ''

            if Grammaer_Verifier_Flag == True:
                if Dataset_Type == 'question':
                    question_asp_sentences01 = Aligned_Translated_ASP_Program_of_Sentence.replace(':-','.').replace(': -','.')
                    verifier_result = ASP_Verifier_Solver('', question_asp_sentences01, opt=False) # If verifying question, verify currently translated ASP sentence
                else: # If verifying context, need to merge ASP sentences in context
                    Aligned_Translated_ASP_Program_of_Sentence_string = ''
                    Aligned_Translated_ASP_Program_of_Sentence02 = copy.deepcopy(Aligned_Translated_ASP_Program_of_Sentence)
                    Aligned_Translated_ASP_Program_of_Sentence_list02 = Aligned_Translated_ASP_Program_of_Sentence02.split('.')[:-1]
                    translated_context_asp_sentences02 = translated_context_asp_sentences
                    # Here we verify generated ASP sentences sentence by sentence, and add sentences that pass ASP symbol solver verification  # TODO: Manual translation needed
                    for key in range(len(Aligned_Translated_ASP_Program_of_Sentence_list02)): # Translated sentence may contain multiple formalized sentences, split by ., if split sentence length is greater than 2, convert DL rules to ASP rules sentence by sentence
                        aligned_facts = Aligned_Translated_ASP_Program_of_Sentence_list02[key] + '.'
                        # [[]] means sentence syntax is correct but has no extension, [] means added fact contradicts facts in context.  # TODO: Manual translation needed
                        verifier_result = ASP_Verifier_Solver(translated_context_asp_sentences02, aligned_facts, opt=False)
                
                        if 'error' in verifier_result:
                            continue
                        elif len(verifier_result)>0:
                            translated_context_asp_sentences02 = translated_context_asp_sentences02 + aligned_facts
                            Aligned_Translated_ASP_Program_of_Sentence_string = Aligned_Translated_ASP_Program_of_Sentence_string + aligned_facts
                        elif len(verifier_result) == 0: # [] means added fact contradicts facts in context.
                            # Call symbol solver multiple times, delete facts in context that contradict current facts  # TODO: Manual translation needed
                            translated_context_asp_sentences03 = copy.deepcopy(translated_context_asp_sentences02)
                            context_asp_list01 = translated_context_asp_sentences03.split('.')
                            context_asp_list = []
                            for key01 in range(len(context_asp_list01)):
                                if len(context_asp_list01[key01])>5:
                                    context_asp_list.append(context_asp_list01[key01]+'. ')
                            # Delete translated ASP sentences in context one by one. Find sentences that contradict current ones  # TODO: Manual translation needed
                            for key01 in range(len(context_asp_list)):
                                context_asp_list02 = copy.deepcopy(context_asp_list)
                                # Delete the key-th element in list context_asp_list02  # TODO: Manual translation needed
                                del context_asp_list02[key01]
                                context_asp_string2 = ' '.join(context_asp_list02)
                                verifier_result01 = ASP_Verifier_Solver(context_asp_string2, aligned_facts, opt=False)
                                if len(verifier_result01)!=0:
                                    translated_context_asp_sentences02 = context_asp_string2 + aligned_facts
                                    Aligned_Translated_ASP_Program_of_Sentence_string = Aligned_Translated_ASP_Program_of_Sentence_string + aligned_facts
                                    verifier_result = copy.deepcopy(verifier_result01) # Replace ASP sentence symbol verification result after deleting contradictory facts with previous result with contradictory facts.
                                    break

                                
                        elif 'error' in verifier_result:
                            continue
                        else:
                            translated_context_asp_sentences02 = translated_context_asp_sentences02 + aligned_facts
                            Aligned_Translated_ASP_Program_of_Sentence_string = Aligned_Translated_ASP_Program_of_Sentence_string + aligned_facts
                    
                    if len(Aligned_Translated_ASP_Program_of_Sentence_string) == 0:
                        if verifier_count< 3:

                            print('ASP verification result is empty, re-translate!while_Count01={}, translated_context_asp_sentences={},Aligned_Translated_ASP_Program_of_Sentence={}'.format(while_Count01, translated_context_asp_sentences, Aligned_Translated_ASP_Program_of_Sentence))
                            verifier_count = verifier_count + 1
                            continue
                        else:
                            print('ASP verification result is empty, re-translate!while_Count01={},verifier_count={}, translated_context_asp_sentences={},Aligned_Translated_ASP_Program_of_Sentence={}'.format(while_Count01, verifier_count, translated_context_asp_sentences, Aligned_Translated_ASP_Program_of_Sentence))
                            Translated_ASP_Program_of_Sentence = ''
                            Aligned_Translated_ASP_Program_of_Sentence = ''
                    else:
                        Translated_ASP_Program_of_Sentence = Aligned_Translated_ASP_Program_of_Sentence_string
                        Aligned_Translated_ASP_Program_of_Sentence = Aligned_Translated_ASP_Program_of_Sentence_string
            
            if Semantic_Verifier_Flag == True:
                # If verification result is not empty, it means passed grammar detection, then perform semantic consistency evaluation on generated sentences  # TODO: Manual translation needed
                semantic_score = Semantic_Similarity_Checker(sentence_to_be_translated, Aligned_Translated_ASP_Program_of_Sentence, llama3_8B_model, llama3_model_tokenizer, True, False, False)
            else:
                semantic_score= 0.5

            
            # Add current translation result to list  # TODO: Manual translation needed
            if len(Aligned_Translated_ASP_Program_of_Sentence) == 0:
                print('Translation result is empty, re-translate!while_Count01={}'.format(while_Count01))
                continue

            Total_Entities_in_ASP_Sentence_Lists.append(Entities_in_Sentence)
            Total_Predicate_Used_in_Sentence_Lists.append(Predicate_Used_in_Sentence)
            Total_Translated_ASP_Program_of_Sentence_Lists.append(Aligned_Translated_ASP_Program_of_Sentence)
            Total_Translated_Default_Logic_of_Sentence_Lists.append(Translated_DL_Program_of_Sentence)
            Total_Verfier_Result_Lists.append(verifier_result)
            Semantic_Score_Lists.append(semantic_score)
                    
            print('Translation attempt {}, verify candidate ASP, translated natural language:{}, generated DL sentence:{}, translated ASP sentence:{} (verification result is answer set generated by current formalized context): {}'.format(while_Count01, sentence_to_be_translated, Translated_DL_Program_of_Sentence, Translated_ASP_Program_of_Sentence, verifier_result))
            
            assert len(Total_Translated_ASP_Program_of_Sentence_Lists) == len(Total_Verfier_Result_Lists)

        # Determine if Total_Verfier_Result_Lists are all 'error' or all empty, if so, then re-extract sentences and re-translate
        if any(len(verifier_result) == 0 for verifier_result in Total_Verfier_Result_Lists) or any(Total_Translated_ASP_Program_of_Sentence_Lists)==0 or any( Semantic_Score01 < 0.5 for Semantic_Score01 in Semantic_Score_Lists) or any('error' in item for item in Total_Verfier_Result_Lists):
            # Need to call re-abstraction module function to re-abstract this sentence   # TODO: Manual translation needed
            Error_message = '' # Total_Verfier_Result_Lists[0]
            # Iterate through Total_Verfier_Result_Lists to collect error information  # TODO: Manual translation needed
            if sum(1 for verifier_result in Total_Verfier_Result_Lists if len(verifier_result) == 0)>= int(len(Total_Verfier_Result_Lists)):
                Error_message = 'The extracted facts are contradictory.'
                print('All candidate formalized sentence symbol verifiers are empty, re-extract sentences and re-translate!Total_Verfier_Result_Lists:{},Semantic_Score_Lists:{},sentence_to_be_translated:{},Total_Translated_ASP_Program_of_Sentence_Lists:{}'.format(Total_Verfier_Result_Lists, Semantic_Score_Lists, sentence_to_be_translated, Models_Results_List))
            elif len(Total_Translated_ASP_Program_of_Sentence_Lists)==0:
                Error_message = 'Sentence grammatical errors. '
                print('All candidate formalized sentence symbol verifications failed with Error, re-extract sentences and re-translate!Total_Verfier_Result_Lists:{},Semantic_Score_Lists:{},sentence_to_be_translated:{},Total_Translated_ASP_Program_of_Sentence_Lists:{}'.format(Total_Verfier_Result_Lists, Semantic_Score_Lists, sentence_to_be_translated, Models_Results_List))
            elif sum(1 for score in Semantic_Score_Lists if score < 0.1) >= int(len(Total_Verfier_Result_Lists)) and len(Semantic_Score_Lists)>=2:
                Error_message = 'The sentences generated by automatic formalization do not match the semantics of natural language sentences.'
                print('All candidate formalized sentence semantic verification scores below threshold, re-extract sentences and re-translate!Total_Verfier_Result_Lists:{},Semantic_Score_Lists:{},sentence_to_be_translated:{},Total_Translated_ASP_Program_of_Sentence_Lists:{}'.format(Total_Verfier_Result_Lists, Semantic_Score_Lists, sentence_to_be_translated, Models_Results_List))
            elif sum(1 for score in Semantic_Score_Lists if score < 0.1) >= 1 and len(Semantic_Score_Lists)==1:
                Error_message = 'The sentences generated by automatic formalization do not match the semantics of natural language sentences.'
                print('All candidate formalized sentence semantic verification scores below threshold, re-extract sentences and re-translate!Total_Verfier_Result_Lists:{},Semantic_Score_Lists:{},sentence_to_be_translated:{},Total_Translated_ASP_Program_of_Sentence_Lists:{}'.format(Total_Verfier_Result_Lists, Semantic_Score_Lists, sentence_to_be_translated, Models_Results_List))
            elif sum( 1 for item in Total_Verfier_Result_Lists if 'error' in item)>= int(len(Total_Verfier_Result_Lists)):
                print('All candidate formalized sentence symbol verifications failed with Error, re-extract sentences and re-translate!Total_Verfier_Result_Lists:{},Semantic_Score_Lists:{},sentence_to_be_translated:{},Total_Translated_ASP_Program_of_Sentence_Lists:{}'.format(Total_Verfier_Result_Lists, Semantic_Score_Lists, sentence_to_be_translated, Models_Results_List))
                for key01 in range(len(Total_Verfier_Result_Lists)):
                    if 'error' in Total_Verfier_Result_Lists[key01]:
                        Error_message = Total_Verfier_Result_Lists[key01][1]
                        break
            else:
                return Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists,Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Semantic_Score_Lists

            
            sentence_to_be_translated = sentence_to_be_translated.strip()
            Reastraction_Sentence = Reastraction_Sentence_with_Context(Dataset_Type,sentence_to_be_translated, Error_message)
            Reastraction_Sentence = Reastraction_Sentence.strip()
            # Replace original extracted fact and rule list sentences with re-extracted sentences, first find original sentence position in list  # TODO: Manual translation needed
            if Dataset_Type != 'question':
                for key01 in range(len(Astraction_Sentence_List)):
                    if Astraction_Sentence_List[key01] == sentence_to_be_translated:
                        Astraction_Sentence_List[key01] = Reastraction_Sentence
                        break
            else:
                for key01 in range(len(Astraction_Question_List)):
                    if Astraction_Question_List[key01] == sentence_to_be_translated:
                        Astraction_Question_List[key01] = Reastraction_Sentence
                        break
                    
            if Reastraction_Sentence != sentence_to_be_translated: # If re-extracted sentence differs from original sentence, replace original sentence
                sentence_to_be_translated = Reastraction_Sentence
                print('Re-extracted sentence successfully replaced original extracted fact and rule list sentences!Reastraction_Sentence:{},sentence_to_be_translated:{}'.format(Reastraction_Sentence, sentence_to_be_translated))
                continue
            else: # If re-extracted sentence is same as original sentence, break out of loop
                print('Re-extracted sentence failed to replace original extracted fact and rule list sentences!Reastraction_Sentence={},sentence_to_be_translated={}'.format(Reastraction_Sentence, sentence_to_be_translated))
                sentence_to_be_translated = Reastraction_Sentence
                break
        else:
            break

    return Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists,Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Semantic_Score_Lists

from collections import namedtuple
_TTTB = namedtuple("ASPTranslationNode", "translated context asp sentences")


# Define MCTS node class  # TODO: Manual translation needed
class ASPTranslationNode( Node):
    def __init__(self, Dataset_Type, Context_List, translated_context_sentences, translated_context_asp_sentences, translated_context_default_logic_sentences, extracted_predicates, extracted_entities, llama3_8B_model, llama3_model_tokenizer, fine_tune_f2, repair_f3, current_sentence_index, translated_asp_sentence, Question_ASP_List, Origin_Question_Label_Lists,FineTune_Positive_Sample_List, FineTune_Negative_Sample_List):
        # Initialize node attributes  # TODO: Manual translation needed
        self.Dataset_Type = Dataset_Type  # Dataset type
        self.Context_List = Context_List  # Context sentence list
        self.translated_context_sentences = translated_context_sentences  # 
        self.translated_context_asp_sentences = translated_context_asp_sentences  # Translated context sentence list
        self.translated_context_default_logic_sentences = translated_context_default_logic_sentences  # Translated context sentence list
        self.extracted_context_predicates = extracted_predicates  # Extracted predicates
        self.extracted_context_entities = extracted_entities  # Extracted entities
        self.llama3_8B_model = llama3_8B_model  # Large model
        self.llama3_model_tokenizer = llama3_model_tokenizer  # Large model tokenizer
        self.fine_tune_f2 = fine_tune_f2  # File for saving fine-tuning dataset
        self.repair_f3 = repair_f3  # Repair function
        self.current_sentence_index = current_sentence_index  # Index of sentence currently being translated
        self.node_nl_sentence = Context_List[current_sentence_index] # Sentence currently being translated
        self.node_asp_sentence = translated_asp_sentence # ASP sentence translated in current node
        self.Question_ASP_List = Question_ASP_List # List of translated ASP sentences corresponding to questions
        self.Origin_Question_Label_Lists = Origin_Question_Label_Lists # List of true labels for original questions
        # Define parameters for calculating similarity  # TODO: Manual translation needed
        self.Similarity_with_LLAMA31_Flag = Similarity_with_LLAMA31_Flag # Whether to use LLAMA3.1 to calculate similarity
        self.Similarity_with_Sentence_Transformer_Flag = Similarity_with_Sentence_Transformer_Flag # Whether to use Sentence-Transformer to calculate similarity
        self.Similarity_with_GPT4_Flag = Similarity_with_GPT4_Flag # Whether to use GPT-4O to calculate similarity
        self.FineTune_Positive_Sample_List = FineTune_Positive_Sample_List
        self.FineTune_Negative_Sample_List = FineTune_Negative_Sample_List

    def find_children(self):
        if self.is_terminal():
            return set()
        # Generate possible ASP translations for current sentence and create child nodes  # TODO: Manual translation needed
        child_node_index = self.current_sentence_index + 1
        self.node_nl_sentence = self.Context_List[child_node_index] # Sentence currently being translated
        child_node_sentence = self.Context_List[child_node_index] # Sentence currently being translated
        Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists,Total_Semantic_Score_Lists = self.generate_possible_translations(child_node_sentence)
        
        # Select optimal translation result based on majority voting principle of consistency  # TODO: Manual translation needed
        # Iterate through translation results for each sentence, asp_sentence_score_list represents comprehensive score for each translation result, including semantic consistency score and grammar consistency score  # TODO: Manual translation needed
        asp_sentence_score_list,Total_Semantic_Score_Lists, Total_Predicate_Used_in_Sentence_list , Total_Entities_in_ASP_Sentence_list, Total_Translated_Default_Logic_of_Sentence_list, Total_Translated_ASP_Program_of_Sentence_list, Total_Verfier_Result_list = self.Select_Optimal_Translation_Result(self.node_nl_sentence, Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists,Total_Semantic_Score_Lists)
        # Return index of maximum value in asp_sentence_score_list  # TODO: Manual translation needed
        best_asp_sentence_index_list_index =[]
        if Selected_Sentence_Number==1 and len(asp_sentence_score_list)>=1: 
            best_asp_sentence_index = asp_sentence_score_list.index(max(asp_sentence_score_list))
            best_asp_sentence_index_list_index = [best_asp_sentence_index] # List of indices for best translation results
        elif len(asp_sentence_score_list)>=2: # If selecting multiple (>=2) translation results, select indices corresponding to two maximum values from asp_sentence_score_list
            index_list01 = sorted(asp_sentence_score_list, reverse=True)[:Selected_Sentence_Number] # Sort from large to small
            for index in index_list01:
                best_asp_sentence_index_list_index.append(asp_sentence_score_list.index(index))
        else:
            return ASPTranslationNode(self.Dataset_Type, self.Context_List, self.translated_context_sentences, 
                                   self.translated_context_asp_sentences, 
                                   self.translated_context_default_logic_sentences,
                                   self.extracted_context_predicates, self.extracted_context_entities, 
                                   self.llama3_8B_model, self.llama3_model_tokenizer, self.fine_tune_f2,
                                   self.repair_f3, child_node_index, '', self.Question_ASP_List,self.Origin_Question_Label_Lists, self.FineTune_Positive_Sample_List,self.FineTune_Negative_Sample_List)

        Predicate_Used_in_Sentence, Entities_in_ASP_Sentence, Translated_Default_Logic_of_Sentence,Translated_ASP_Program_of_Sentence, Verfier_Result = Total_Predicate_Used_in_Sentence_list[best_asp_sentence_index_list_index[0]], Total_Entities_in_ASP_Sentence_list[best_asp_sentence_index_list_index[0]], Total_Translated_Default_Logic_of_Sentence_list[best_asp_sentence_index_list_index[0]],Total_Translated_ASP_Program_of_Sentence_list[best_asp_sentence_index_list_index[0]], Total_Verfier_Result_list[best_asp_sentence_index_list_index[0]]
        # Write best and worst translation results to fine-tuning dataset based on their indices  # TODO: Manual translation needed
        if self.Dataset_Type=='train':
            self.FineTune_Positive_Sample_List,self.FineTune_Negative_Sample_List = self.write_fine_tune_data(asp_sentence_score_list, Total_Semantic_Score_Lists, Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_list,Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists,self.FineTune_Positive_Sample_List, self.FineTune_Negative_Sample_List)
        
        # Update translation result of current node  # TODO: Manual translation needed
        if len(best_asp_sentence_index_list_index) == 1:
            # Before adding this node to context, first perform predicate consistency alignment. Call predicate consistency function for comparison.  # TODO: Manual translation needed
            if 'error' not in Verfier_Result:
                self.translated_context_asp_sentences = self.translated_context_asp_sentences + Translated_ASP_Program_of_Sentence
            else:
                self.translated_context_asp_sentences = self.translated_context_asp_sentences  
            
        else:
            # If selecting multiple translation results, add all translation results to context  # TODO: Manual translation needed
            for index_key in range(len(best_asp_sentence_index_list_index)):
                # First verify through symbol solver, if verification passes (answer set is not empty), add this translation result to context  # TODO: Manual translation needed
                verifier_result = ASP_Verifier_Solver(self.translated_context_asp_sentences, Total_Translated_ASP_Program_of_Sentence_list[best_asp_sentence_index_list_index[index_key]], opt=False)
                if 'error' in verifier_result:
                    continue
                elif len(verifier_result[0]) ==0: # If answer set is empty, skip this translation result
                    continue
                elif len(verifier_result[0]) > 0: # If answer set is not empty, add this translation result to context
                    self.translated_context_asp_sentences = self.translated_context_asp_sentences + ' ' + Total_Translated_ASP_Program_of_Sentence_list[best_asp_sentence_index_list_index[index_key]]
                else:
                    print('Verification result is empty, re-select translation result!')
                    continue
                        
        
        
        print('Translated ASP sentences for current context: {}'.format(self.translated_context_asp_sentences))
        self.translated_context_sentences = self.translated_context_sentences + child_node_sentence  if len(Translated_ASP_Program_of_Sentence) > 0 else self.translated_context_sentences

        # self.translated_context_asp_sentences = self.translated_context_asp_sentences + Translated_ASP_Program_of_Sentence if len(Translated_ASP_Program_of_Sentence) > 0 else self.translated_context_asp_sentences
        if len(best_asp_sentence_index_list_index) ==1:
            self.translated_context_default_logic_sentences = self.translated_context_default_logic_sentences + Total_Translated_Default_Logic_of_Sentence_Lists[best_asp_sentence_index_list_index[0]]
        elif len(best_asp_sentence_index_list_index) == 2:
            self.translated_context_default_logic_sentences = self.translated_context_default_logic_sentences + Total_Translated_Default_Logic_of_Sentence_Lists[best_asp_sentence_index_list_index[0]] + Total_Translated_Default_Logic_of_Sentence_Lists[best_asp_sentence_index_list_index[1]]
        else:
            self.translated_context_default_logic_sentences = self.translated_context_default_logic_sentences

        Predicate_Used_in_Sentence_list01 = Predicate_Used_in_Sentence.split(',') if len(Predicate_Used_in_Sentence) > 0 else ['']
        Predicate_Used_in_Sentence_list02=[]
        for key01 in range(len(Predicate_Used_in_Sentence_list01)):
            if len(Predicate_Used_in_Sentence_list01[key01]) > 1:
                Predicate_Used_in_Sentence_list02.append(Predicate_Used_in_Sentence_list01[key01].strip())  
        Predicate_Used_in_Sentence = ','.join(Predicate_Used_in_Sentence_list02) +','
        
        Entities_in_ASP_Sentence_list01 = Entities_in_ASP_Sentence.split(',') if len(Entities_in_ASP_Sentence) > 0 else ['']
        Entities_in_ASP_Sentence_list02=[]
        for key01 in range(len(Entities_in_ASP_Sentence_list01)):
            if len(Entities_in_ASP_Sentence_list01[key01]) > 1:
                Entities_in_ASP_Sentence_list02.append(Entities_in_ASP_Sentence_list01[key01].strip())
        Entities_in_ASP_Sentence = ','.join(Entities_in_ASP_Sentence_list02) +','
        
        self.extracted_context_predicates = self.extracted_context_predicates + Predicate_Used_in_Sentence if len(Translated_ASP_Program_of_Sentence) > 0 else self.extracted_context_predicates
        self.extracted_context_entities = self.extracted_context_entities + Entities_in_ASP_Sentence if len(Translated_ASP_Program_of_Sentence) > 0 else self.extracted_context_entities
        
        # Remove duplicates from Extracted predicates and entities  # TODO: Manual translation needed
        extracted_context_predicates_list01 = self.extracted_context_predicates.split(',') if len(self.extracted_context_predicates) > 0 else ['']
        extracted_context_predicates_list02=[]
        for key01 in range(len(extracted_context_predicates_list01)):
            if len(extracted_context_predicates_list01[key01]) > 1:
                extracted_context_predicates_list02.append(extracted_context_predicates_list01[key01].strip())
        extracted_context_predicates_list01 = list(set(extracted_context_predicates_list02))
        self.extracted_context_predicates = ','.join(extracted_context_predicates_list01) +','
        extracted_context_entities_list01 = self.extracted_context_entities.split(',') if len(self.extracted_context_entities) > 0 else ['']
        extracted_context_entities_list02=[]
        for key01 in range(len(extracted_context_entities_list01)):
            if len(extracted_context_entities_list01[key01]) > 1:
                extracted_context_entities_list02.append(extracted_context_entities_list01[key01].strip())
        extracted_context_entities_list01 = list(set(extracted_context_entities_list02))
        self.extracted_context_entities = ','.join(extracted_context_entities_list01) +','

        self.node_asp_sentence = Translated_ASP_Program_of_Sentence if len(Translated_ASP_Program_of_Sentence) > 0 else ''
        if len(Translated_ASP_Program_of_Sentence) > 0:
            print('Current node natural language: {}, translated ASP sentence: {}, candidate ASP set generated by translation: {}'.format(self.node_nl_sentence, self.node_asp_sentence, Total_Translated_ASP_Program_of_Sentence_Lists))
        return ASPTranslationNode(self.Dataset_Type, self.Context_List, self.translated_context_sentences, 
                                   self.translated_context_asp_sentences, 
                                   self.translated_context_default_logic_sentences,
                                   self.extracted_context_predicates, self.extracted_context_entities, 
                                   self.llama3_8B_model, self.llama3_model_tokenizer, self.fine_tune_f2,
                                   self.repair_f3, child_node_index, self.node_asp_sentence, self.Question_ASP_List,self.Origin_Question_Label_Lists,self.FineTune_Positive_Sample_List,self.FineTune_Negative_Sample_List)
    

    def is_terminal(self):
        # Determine if it is a terminal node: if current sentence is the last sentence in context  # TODO: Manual translation needed
        return self.current_sentence_index == len(self.Context_List) - 1


    def __hash__(self):
        # Define node hash value  # TODO: Manual translation needed
        # Generate unique hash value for node  # TODO: Manual translation needed
        # Use tuple(self.node_nl_sentence) to convert natural language sentence to immutable tuple  # TODO: Manual translation needed
        # Combine tuple with current sentence index to ensure nodes with same sentence but different positions have different hash values  # TODO: Manual translation needed
        # This method can effectively distinguish different nodes, facilitating unique identification of each node in MCTS tree structure  # TODO: Manual translation needed
        return hash((tuple(self.node_nl_sentence), self.current_sentence_index))

    def __eq__(self, other):
        # Define node equality comparison  # TODO: Manual translation needed
        if isinstance(other, ASPTranslationNode):
            return (self.node_nl_sentence, self.current_sentence_index) == (other.node_nl_sentence, other.current_sentence_index)
        return False
    # Define a function to write positive and negative samples of current node translation results to fine-tuning dataset  # TODO: Manual translation needed
    def write_fine_tune_data(self, asp_sentence_score_list,Total_Semantic_Score_Lists, Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_list, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, FineTune_Positive_Sample_List,FineTune_Negative_Sample_List):
        global Generate_Fine_Tune_Sample_Number
        # Generate one positive sample and one negative sample based on candidate ASP results of current node sentence  # TODO: Manual translation needed
        #Return index of maximum value in asp_sentence_score_list， and use sample corresponding to this index as positive training sample  # TODO: Manual translation needed
        if len(asp_sentence_score_list)>0:
            best_asp_sentence_index = asp_sentence_score_list.index(max(asp_sentence_score_list))
            # Return index of minimum value in asp_sentence_score_list, and use sample corresponding to this index as negative training sample  # TODO: Manual translation needed
            worst_asp_sentence_index = asp_sentence_score_list.index(min(asp_sentence_score_list))
        else: # 
            return FineTune_Positive_Sample_List, FineTune_Negative_Sample_List
        

        if self.Dataset_Type == 'train':
            # If score is greater than 0.95, write positive sample  # TODO: Manual translation needed
            # If score is greater than 0.95, write positive sample  # TODO: Manual translation needed
            if asp_sentence_score_list[best_asp_sentence_index] >= 0.9: # If highest score of this node is greater than 0.8, treat as positive sample   
                Write_fine_tune_Dict = {}
                Write_fine_tune_Dict['Sample_Number'] = Generate_Fine_Tune_Sample_Number
                Write_fine_tune_Dict['Role'] = 'Generator'
                Write_fine_tune_Dict['Instruction'] = Fine_Tune_Instruction
                Write_fine_tune_Dict['translated_context_sentences'] = self.translated_context_sentences 
                Write_fine_tune_Dict['translated_context_asp_sentences'] = self.translated_context_asp_sentences
                Write_fine_tune_Dict['translated_context_default_logic_sentences'] = self.translated_context_default_logic_sentences
                Write_fine_tune_Dict['Extracted_context_predicates'] = self.extracted_context_predicates
                Write_fine_tune_Dict['Extracted_context_entities'] = self.extracted_context_entities
                Write_fine_tune_Dict['Sentence_to_be_translated'] = self.node_nl_sentence
                Write_fine_tune_Dict['Translated_ASP_Program_of_Sentence'] = Total_Translated_ASP_Program_of_Sentence_Lists[best_asp_sentence_index]
                Write_fine_tune_Dict['Translated_Default_Logic_of_Sentence'] = Total_Translated_Default_Logic_of_Sentence_list[best_asp_sentence_index]
                Write_fine_tune_Dict['Predicate_Used_in_Sentence'] = Total_Predicate_Used_in_Sentence_Lists[best_asp_sentence_index]
                Write_fine_tune_Dict['Entities_Used_in_Sentence'] = Total_Entities_in_ASP_Sentence_Lists[best_asp_sentence_index]
                Write_fine_tune_Dict['Score'] = Total_Semantic_Score_Lists[best_asp_sentence_index]
                Write_fine_tune_Dict['Label'] = "True" # True represents positive sample
                FineTune_Positive_Sample_List.append(Write_fine_tune_Dict)
            # If score is less than 0.5, write negative sample  # TODO: Manual translation needed
            if asp_sentence_score_list[worst_asp_sentence_index] <= 0.8: # If lowest score of this node is less than 0.5, treat as negative sample
                Write_fine_tune_Dict = {}
                Write_fine_tune_Dict['Sample_Number'] = Generate_Fine_Tune_Sample_Number
                Write_fine_tune_Dict['Role'] = 'Generator'
                Write_fine_tune_Dict['Instruction'] = Fine_Tune_Instruction
                Write_fine_tune_Dict['translated_context_sentences'] = self.translated_context_sentences 
                Write_fine_tune_Dict['translated_context_asp_sentences'] = self.translated_context_asp_sentences
                Write_fine_tune_Dict['translated_context_default_logic_sentences'] = self.translated_context_default_logic_sentences
                Write_fine_tune_Dict['Extracted_context_predicates'] = self.extracted_context_predicates
                Write_fine_tune_Dict['Extracted_context_entities'] = self.extracted_context_entities
                Write_fine_tune_Dict['Sentence_to_be_translated'] = self.node_nl_sentence
                Write_fine_tune_Dict['Translated_ASP_Program_of_Sentence'] = Total_Translated_ASP_Program_of_Sentence_Lists[worst_asp_sentence_index]
                Write_fine_tune_Dict['Translated_Default_Logic_of_Sentence'] = Total_Translated_Default_Logic_of_Sentence_list[worst_asp_sentence_index]
                Write_fine_tune_Dict['Predicate_Used_in_Sentence'] = Total_Predicate_Used_in_Sentence_Lists[worst_asp_sentence_index]
                Write_fine_tune_Dict['Entities_Used_in_Sentence'] = Total_Entities_in_ASP_Sentence_Lists[worst_asp_sentence_index]
                Write_fine_tune_Dict['Score'] = Total_Semantic_Score_Lists[best_asp_sentence_index]
                Write_fine_tune_Dict['Label'] = "False" # False represents negative sample
                FineTune_Negative_Sample_List.append(Write_fine_tune_Dict)
                
        return FineTune_Positive_Sample_List, FineTune_Negative_Sample_List


    # 
    def generate_possible_translations(self, node_sentence):
        # Use LLM to generate possible ASP translations for current sentence  # TODO: Manual translation needed
        Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Total_Semantic_Score_Lists = LLM_ASP_Solver_Single_Sentence(self.Dataset_Type, 
                                                              self.translated_context_sentences, 
                                                              self.translated_context_asp_sentences, 
                                                              self.translated_context_default_logic_sentences,
                                                              self.extracted_context_predicates, 
                                                              self.extracted_context_entities, 
                                                              node_sentence,
                                                              self.llama3_8B_model, 
                                                              self.llama3_model_tokenizer, 
                                                              self.fine_tune_f2)
        return Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Total_Semantic_Score_Lists
    # Evaluate symbolic consistency based on similarity of answer sets corresponding to generated ASP, but number of calls to Large model is still high  # TODO: Manual translation needed
        
    
    # Calculate semantics based on number of answer sets  # TODO: Manual translation needed
    def Symbol_Consistency_Checker_based_ASP_Sentence(self, node_nl_sentence,Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Similarity_with_LLAMA31_Flag, Similarity_with_Sentence_Transformer_Flag, Similarity_with_GPT4_Flag):
        Symbolic_score_list, symbolic_score_list01, symbolic_score_list02 = [], [], []
        sentence_nl = node_nl_sentence
        symbolic_score_list01 = [0.0] * len(Total_Translated_ASP_Program_of_Sentence_Lists)

        # Iterate through number of answer sets generated after adding this fact or rule  # TODO: Manual translation needed
        Answer_Set_Number_List = [] # Used to store number of facts in each answer set
        min_number,max_number = 0,0
        for asp_key in range(len(Total_Verfier_Result_Lists)):
            answer_set_list = Total_Verfier_Result_Lists[asp_key]
            # If answer set includes errors, answer set score is 0  # TODO: Manual translation needed
            if 'error' in answer_set_list:
                answer_set_fact_count = 0
                Answer_Set_Number_List.append(answer_set_fact_count)
            else:
                answer_set_fact_count = 1.0 # Used to calculate facts contained in this answer set, answer set may have multiple extensions.
                # for key01 in range(len(answer_set_list)):
                #     answer_set_fact_count = answer_set_fact_count + len(answer_set_list[key01])
                Answer_Set_Number_List.append(answer_set_fact_count)

        # Normalize list of answer set numbers, if fact counts of all answer sets are equal, all are 1.  # TODO: Manual translation needed
        max_number = max(Answer_Set_Number_List)
        min_number = min(Answer_Set_Number_List)
        if max_number == min_number and max_number!=0:
            symbolic_score_list02 = [1.0] * len(Answer_Set_Number_List)
        elif max_number == min_number and max_number==0:
            symbolic_score_list02 = [0.0] * len(Answer_Set_Number_List)
        else:
            # Otherwise normalize list of answer set numbers  # TODO: Manual translation needed
            for answer_set_number in Answer_Set_Number_List:
                symbolic_score_list02.append((answer_set_number) / (max_number))
        print('Symbolic score based on answer set number: {}'.format(symbolic_score_list02))
        

        symbolic_score_list03 = []
        for key01 in range(len(symbolic_score_list01)):
            symbolic_score_list03.append(symbolic_score_list01[key01] + symbolic_score_list02[key01])
        
        max_number03 = max(symbolic_score_list03) if len(symbolic_score_list03) > 0 else 0
        min_number03 = min(symbolic_score_list03) if len(symbolic_score_list03) > 0 else 0
        if len(symbolic_score_list03) == 0:
            Symbolic_score_list = []
        elif max_number03 == min_number03 and max_number03 != 0 and len(symbolic_score_list03) != 0:
            Symbolic_score_list = [1.0] * len(symbolic_score_list03)
        else:
            # Normalize symbolic_score_list  # TODO: Manual translation needed
            for key03 in range(len(symbolic_score_list03)):
                Symbolic_score_list.append((symbolic_score_list03[key03]) / 2)
        
        
        return Symbolic_score_list
        

    def Select_Optimal_Translation_Result(self, NL_sentence, Total_Predicate_Used_in_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Total_Semantic_Score_Lists):
        # Evaluate quality of entire translation  # TODO: Manual translation needed
        symbol_score, semantic_score = 0, 0 # Initialize symbolic consistency score, semantic consistency score, total score
        weight_symbol, weight_semantic = 0.5, 0.5

        # Used to store score for each candidate ASP  # TODO: Manual translation needed
        asp_sentence_score_list = []
        symbolic_score_list, semantic_score_list = [], []
        # Calculate symbolic consistency score  # TODO: Manual translation needed
        symbolic_score_list = self.Symbol_Consistency_Checker_based_ASP_Sentence(NL_sentence, Total_Translated_ASP_Program_of_Sentence_Lists,Total_Verfier_Result_Lists, True, False, False)
        # Iterate through generated candidate translation results  # TODO: Manual translation needed
        print('Iterate through generated candidate translation results{} and verification results {}'.format(Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists))

        # Normalize semantic score by dividing by maximum value  # TODO: Manual translation needed
        # Total_Semantic_Score_Lists01 = copy.deepcopy(Total_Semantic_Score_Lists)
        # max_value = max(Total_Semantic_Score_Lists01)
        # Total_Semantic_Score_Lists02 = copy.deepcopy([])
        # for semantic_score01 in Total_Semantic_Score_Lists01:
        #     Total_Semantic_Score_Lists02.append((semantic_score01) / (max_value))
        # Total_Semantic_Score_Lists = copy.deepcopy(Total_Semantic_Score_Lists02)
          
        # # Iterate through symbolic scores and semantic scores   # TODO: Manual translation needed
        for key01 in range(len(symbolic_score_list)):
            if len(symbolic_score_list) == len(Total_Semantic_Score_Lists):
                # Determine if Total_Semantic_Score_Lists[key01] is float type  # TODO: Manual translation needed
                if not isinstance(Total_Semantic_Score_Lists[key01], float):
                    Total_Semantic_Score_Lists[key01] = 0.0
                asp_sentence_score_list.append(weight_symbol * symbolic_score_list[key01] + weight_semantic * Total_Semantic_Score_Lists[key01])
            else:
                print('Symbolic score and semantic score lengths inconsistent! Set to 0')
                asp_sentence_score_list.append(Total_Semantic_Score_Lists[key01])
        
        
        print('Symbolic correctness score {}'.format(symbolic_score_list))
        print('Semantic correctness score {}'.format(Total_Semantic_Score_Lists))
        print('Comprehensive correctness score {}'.format(asp_sentence_score_list))

        return asp_sentence_score_list, Total_Semantic_Score_Lists, Total_Predicate_Used_in_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists


# Define a function to use Large model to extract facts and rules from natural language context.  # TODO: Manual translation needed
def Extract_Facts_and_Rules_from_Context(Context_List,Question_List,Next_Extracted_Fact_Rules,Origin_Question_Label_Lists,suggestion_string):
    # Convert context list to string  # TODO: Manual translation needed
    # Build prompt  # TODO: Manual translation needed
    # Rewrite sentences in context sentence by sentence  # TODO: Manual translation needed
    Total_Fact_Rules, Total_Question_List =[],[]

    Extracted_Fact_Rules, Extracted_Questions = '','' # Used to store extracted facts and rules
    # for context_key in range(len(Context_List)):
        
    Context_String = ' '.join(Context_List)  # The extracted fact and rules are:' + Extracted_Fact_Rules + '### \n ' +
    Question_String = ' '.join(Question_List)
    Next_Extracted_Fact_Rules_String = ' '.join(Next_Extracted_Fact_Rules)
    Question_String = Question_String.replace('?','.')
    Origin_Context = ''
    if len(suggestion_string)>10:
        Origin_Context = '### \n The natural language context sentences are: ' + Context_String  + ' ### \n The Questions are: ' + Question_String +' \n These are the facts and rules previously extracted from the context: ' + Next_Extracted_Fact_Rules_String+ ' ### \n Here are some suggestions for extracting facts and default rules, but these suggestions may not be completely correct, so you need to analyze and refer to them more carefully: ' + suggestion_string    
    else:
        Origin_Context = '### \n The natural language context sentences are: ' + Context_String  + ' ### \n The Questions are: ' + Question_String 
    # Call Large model to generate common sense knowledge  # TODO: Manual translation needed
    while_count = 1
    while True:
        Total_Fact_Rules, Total_Question_List =[],[]
        Facts_and_Rules_List = []

        if while_count > 2:
            Total_Fact_Rules = [copy.deepcopy(Context_String)]
            Total_Question_List = [copy.deepcopy(Question_String)]
            break
        while_count = while_count + 1
        model_result = Calling_LLAMA3_with_API(Prompt_with_Extract_Fact_Rule_From_Context, Origin_Context,1,0.7)[0]
        model_result = model_result.replace('\n', '')
        model_result = model_result.split('</think>')[-1] if '</think>' in model_result else model_result
        if len(model_result) > 0:
            model_result = model_result+ '###' if model_result[-1] != '#' else model_result
        model_result = model_result.strip()
        # Use regular expression to extract facts and rules  # TODO: Manual translation needed
        Facts_and_Rules = re.findall(Extract_Fact_Rules_Pattern, model_result)
        Extracte_questions = re.findall(Extract_Questions_Pattern, model_result)
        if len(Facts_and_Rules)>0 and len(Extracte_questions)>0:
            Facts_and_Rules = Facts_and_Rules[0]
            Questions = Extracte_questions[0].replace('?','.')
        else:
            continue
        Facts_and_Rules_List01 = Facts_and_Rules.split('.')
        for fact_rule in Facts_and_Rules_List01:
            if fact_rule:
                # Remove leading and trailing spaces  # TODO: Manual translation needed
                fact_rule = fact_rule.strip() + '.'
                if len(fact_rule)>10:
                    # Add sentence to list  # TODO: Manual translation needed
                    Facts_and_Rules_List.append(fact_rule.lower())
                    Total_Fact_Rules.append(fact_rule.lower())
                    Extracted_Fact_Rules = Extracted_Fact_Rules + fact_rule
                    
        Questions = Questions.replace(', ','. ')
        Questions_list01 = Questions.split('.')
        for question_key in range(len(Questions_list01)):
            if int(question_key)>=len(Origin_Question_Label_Lists):
                continue
            if len(Questions_list01[question_key])>5:
                question_fact = Questions_list01[question_key].strip() + '.'
                Total_Question_List.append(question_fact.lower())

        if len(Total_Fact_Rules) > 0 and len(Total_Question_List)>0:
            break
    print('Extracted facts and rules: {}, generated questions: {}'.format(Total_Fact_Rules,Total_Question_List))


    return Total_Fact_Rules,Total_Question_List

# Define a function to use Large model to extract facts and rules from natural language context.  # TODO: Manual translation needed
def Verifier_Extract_Facts_and_Rules_from_Context(Context_List,Extracted_Context,Question_List,Origin_Question_Label_Lists):
    # Convert context list to string  # TODO: Manual translation needed
    # Build prompt  # TODO: Manual translation needed
    # Rewrite sentences in context sentence by sentence  # TODO: Manual translation needed
    Total_Fact_Rules, Total_Question_List =[],[]

    Extracted_Fact_Rules, Extracted_Questions = '','' # Used to store extracted facts and rules
    # for context_key in range(len(Context_List)):
        
    Context_String = ' '.join(Context_List)  # The extracted fact and rules are:' + Extracted_Fact_Rules + '### \n ' +
    Extracted_Context_String = ' '.join(Extracted_Context)
    Question_String = ' '.join(Question_List)
    Question_String = Question_String.replace('?','.')

    Origin_Context = '### \n The natural language context sentences are: ' + Context_String +' ### \n The extracted fact and rules are:' + Extracted_Context_String + ' ### \n The Questions are: ' + Question_String +' \n'
    # Call Large model to generate common sense knowledge  # TODO: Manual translation needed
    while_count = 1
    Verifier_result_string , suggestion_reulst_string = '',''
    while True:
        Facts_and_Rules_List = []
        Total_Fact_Rules, Total_Question_List =[],[]


        if while_count > 5:
            Total_Fact_Rules = [copy.deepcopy(Context_String)]
            Total_Question_List = [Question_String]
            break
        while_count = while_count + 1
        model_result = Calling_LLAMA3_with_API(Prompt_with_Verifier_Extract_Fact_Rule_From_Context, Origin_Context, llama3_8B_model, llama3_model_tokenizer, 500)
        model_result = model_result.replace('\n', '')
        model_result = model_result.split('</think>')[-1] if '</think>' in model_result else model_result
        if len(model_result) > 0:
            model_result = model_result+ '###' if model_result[-1] != '#' else model_result
        model_result = model_result.strip()
        # Use regular expression to extract facts and rules  # TODO: Manual translation needed
        Verifier_result = re.findall(Veritier_Fact_Rules_Pattern, model_result)
        suggestion_reulst = re.findall(Veritier_Suggestion_Pattern, model_result)

        if len(Verifier_result)!=0:
            Verifier_result_string = Verifier_result[0].strip().lower() if len(Verifier_result)>0 else ''
            suggestion_reulst_string = suggestion_reulst[0].strip() if len(suggestion_reulst)>0 else 'None'
            break
    print('Verification result of extracted facts and rules: {}, extracted suggestion={}'.format(Verifier_result_string,suggestion_reulst_string))

    return Verifier_result_string, suggestion_reulst_string

# Define main framework function  # TODO: Manual translation needed
# fine_tune_file1: file for storing fine-tuning model data, select verified data samples from training set  # TODO: Manual translation needed
# Can consider increasing reasoning time, combine search strategy with reward model (verifier, symbol solver). Search: simultaneously generate multiple candidate ASP contexts, then give final answer based on majority voting principle.  # TODO: Manual translation needed
def LLM_ASP_Solver(Sample_number, Question_List, Facts, Rules, llama3_8B_model, llama3_model_tokenizer, Dataset_Type,NMR_Category, fine_tune_f2, repair_f3, Origin_Question_Label_Lists):

    Context_List, Facts_List, Rules_Lists = [],[],[]
    # Used to store positive and negative samples generated from training set samples, if training sample prediction is correct, write positive sample, if label is wrong, write positive sample.  # TODO: Manual translation needed
    FineTune_Positive_Sample_List, FineTune_Negative_Sample_List = [],[] 
    FineTune_Question_Positive_Sample_List, FineTune_Question_Negative_Sample_List = [],[] 
    # For MultiLogicNMR, MultiLogicNMR_OOD, MultiLogicNMR_NL, LogicNMR datasets, need to split Facts and Rules, translate sentence by sentence  # TODO: Manual translation needed
    if Allatonce_Flag != True: # If Allatonce_Flag is not True, it means translate all sentences sentence by sentence
        if len(Facts)>0:
            Facts_List01 = Facts.split('.')
            for fact_key in range(len(Facts_List01)):
                if len(Facts_List01[fact_key]) > 0:
                    fact_text = Facts_List01[fact_key] + '. '
                    fact_text = fact_text.lower()
                    Facts_List.append(fact_text)
                else:
                    continue

        Rules_List01 = Rules.split('.')
        for rule_key in range(len(Rules_List01)):
            if len(Rules_List01[rule_key]) > 0:
                Rule_text = Rules_List01[rule_key] +'. '
                Rule_text = Rule_text.lower()
                Rules_Lists.append(Rule_text)
            else:
                continue
        Context_List.extend(Facts_List)
        Context_List.extend(Rules_Lists)
    else:
        Rules = Rules.lower()
        Context_List.extend([Rules])

    Origin_Context_List = copy.deepcopy(Context_List)
    Origin_Question_List = copy.deepcopy(Question_List)
    # For LogicBench and LogicEval datasets, no need to split, translate directly  # TODO: Manual translation needed

    # Call module to extract facts and rules from context, extract facts and rules from context  # TODO: Manual translation needed
    while_extract_count = 0
    suggestion_string = ''
    Next_Extracted_Fact_Rules = ''
    First_Rewrited_Context =''
    Verifier_result_string =''
    while True:
        if while_extract_count >=2: # Try three times to verify extracted context, if all fail, use facts and rules extracted the first time.
            Context_List = First_Rewrited_Context if len(Rewrited_Context)<=2 or 'yes' not in Verifier_result_string else copy.deepcopy(Context_List) # Replace original context with rewritten context
            Question_List = Extracted_Question_List if len(Extracted_Question_List)==len(Origin_Question_Label_Lists) else copy.deepcopy(Question_List)
            break

        while_extract_count = while_extract_count + 1
        Rewrited_Context, Extracted_Question_List = Extract_Facts_and_Rules_from_Context(Context_List, Origin_Question_List, Next_Extracted_Fact_Rules,Origin_Question_Label_Lists,suggestion_string)        
        if while_extract_count ==1:
            First_Rewrited_Context = copy.deepcopy(Rewrited_Context)
        # Context-level abstractor - organize facts and rules generated by sentence-level abstractor,  # TODO: Manual translation needed
        Verifier_result_string, suggestion_reulst_string = Verifier_Extract_Facts_and_Rules_from_Context(Context_List,Rewrited_Context, Question_List, Origin_Question_Label_Lists)
        if 'yes' in Verifier_result_string:
            Context_List = Rewrited_Context if len(Rewrited_Context) >=3 else copy.deepcopy(Context_List) # Replace original context with rewritten context
            Question_List = Extracted_Question_List if len(Extracted_Question_List)==len(Origin_Question_Label_Lists) else copy.deepcopy(Question_List)
            break
        elif suggestion_reulst_string=='None':
            Context_List = First_Rewrited_Context if len(Rewrited_Context)>=2 else copy.deepcopy(Context_List) # Replace original context with rewritten context
            Question_List = Extracted_Question_List if len(Extracted_Question_List)==len(Origin_Question_Label_Lists) else copy.deepcopy(Question_List)
            break
        else:
            suggestion_string = copy.deepcopy(suggestion_reulst_string)
            Next_Extracted_Fact_Rules = copy.deepcopy(First_Rewrited_Context)
            continue

    FineTune_Positive_Extracted_Fact_Rule_List,FineTune_Negative_Extracted_Fact_Rule_List = [],[]
    global Generate_Fine_Tune_Sample_Number

    if Dataset_Type=='train':
        if 'yes' in Verifier_result_string:
            Write_fine_tune_Dict = {}
            Write_fine_tune_Dict['Sample_Number'] = Generate_Fine_Tune_Sample_Number
            Write_fine_tune_Dict['Role'] = 'Extractor'
            Write_fine_tune_Dict['Instruction'] = Prompt_with_Extract_Fact_Rule_From_Context
            Write_fine_tune_Dict['Origin_Context_List'] = Origin_Context_List 
            Write_fine_tune_Dict['Origin_Question_List'] = Origin_Question_List
            Write_fine_tune_Dict['Extract_Fact_Rules_List'] = Context_List
            Write_fine_tune_Dict['Question_List'] = Question_List
            Write_fine_tune_Dict['Verifier_result_string'] = 'yes'
            FineTune_Positive_Extracted_Fact_Rule_List.append(Write_fine_tune_Dict)
        if 'no' in Verifier_result_string:
            Write_fine_tune_Dict = {}
            Write_fine_tune_Dict['Sample_Number'] = Generate_Fine_Tune_Sample_Number
            Write_fine_tune_Dict['Role'] = 'Extractor'
            Write_fine_tune_Dict['Instruction'] = Prompt_with_Extract_Fact_Rule_From_Context
            Write_fine_tune_Dict['Origin_Context_List'] = Origin_Context_List
            Write_fine_tune_Dict['Origin_Question_List'] = Origin_Question_List 
            Write_fine_tune_Dict['Extract_Fact_Rules_List'] = Context_List
            Write_fine_tune_Dict['Question_List'] = Question_List
            Write_fine_tune_Dict['Verifier_result_string'] = 'no'
            FineTune_Negative_Extracted_Fact_Rule_List.append(Write_fine_tune_Dict)

    # Sort extracted facts and rules, put facts first, if sentence contains usually, put it last. And so on.  # TODO: Manual translation needed
    Resort_Context_List = []
    fact_list = []
    rule_list = []
    usually_rule_list = []
    for context_sentence in Context_List:
        sentence_lower = context_sentence.lower()
        if ' usually ' in sentence_lower:
            usually_rule_list.append(context_sentence)
        elif sentence_lower.startswith('if ') and ' then ' in sentence_lower:
            rule_list.append(context_sentence)
        else:
            fact_list.append(context_sentence)
    Resort_Context_List = fact_list + rule_list + usually_rule_list
    print('Extracted facts and rules before sorting Context_List: {}, extracted facts and rules after sorting Resort_Context_List: {}'.format(Context_List,Resort_Context_List))
    Astraction_Sentence_List = copy.deepcopy(Context_List) # Used to store abstracted sentences, global variable
    Astraction_Question_List = copy.deepcopy(Question_List) # Used to store abstracted sentences, global variable)
    Context_List = copy.deepcopy(Resort_Context_List)

    # Iterate through facts and rules in context sequentially, and call Large model for translation.  # TODO: Manual translation needed
    Question_ASP_List = []
    translated_context_sentences, translated_context_asp_sentences, translated_context_default_logic_sentences, extracted_predicates, extracted_entities, sentence_to_be_translated =' ',' ',' ',' ',' ',' '
    root = ASPTranslationNode(Dataset_Type, Context_List, '', '', '', '', '', llama3_8B_model, llama3_model_tokenizer, fine_tune_f2, repair_f3, -1, '', Question_ASP_List, Origin_Question_Label_Lists,FineTune_Positive_Sample_List, FineTune_Negative_Sample_List)


    # Model automatically formalized context as MCTS tree  # TODO: Manual translation needed
    # Initialize MCTS  # TODO: Manual translation needed
    mcts = Tree_Search()
    # Define a root node  # TODO: Manual translation needed
    # Perform MCTS search for each context sentence  # TODO: Manual translation needed
        # Execute MCTS search  # TODO: Manual translation needed
    print('Sample {} executing Tree search'.format(str(Sample_number)))
    node = mcts._Tree_Search(root) # Return the last node

    # Get context natural language sentences and ASP sentences of current node  # TODO: Manual translation needed
    translated_context_sentences = node.translated_context_sentences 
    translated_context_asp_sentences = node.translated_context_asp_sentences
    translated_context_default_logic_sentences = node.translated_context_default_logic_sentences
    # Get extracted predicates and entities from current node context  # TODO: Manual translation needed
    extracted_context_predicates = node.extracted_context_predicates
    extracted_context_entities = node.extracted_context_entities
    FineTune_Positive_Sample_List = node.FineTune_Positive_Sample_List # Positive samples for fine-tuning generated after context translation
    FineTune_Negative_Sample_List = node.FineTune_Negative_Sample_List # Negative samples for fine-tuning generated after context translation

    print("Tree search completed, translated ASP results: {}, original context: {}".format(translated_context_asp_sentences, translated_context_sentences))
    print("Extracted predicates：{}".format(extracted_context_predicates))
    print("Extracted entities：{}".format(extracted_context_entities))

    # Then answer questions based on answer sets  # TODO: Manual translation needed
    # Iterate through facts and rules in context sequentially, and call Large model for translation.  # TODO: Manual translation needed
    Question_ASP_List = []
    # translated_context_sentences, translated_context_asp_sentences, extracted_predicates, extracted_entities, sentence_to_be_translated =' ',' ',' ',' ',' '
    root = ASPTranslationNode(Dataset_Type, Question_List, translated_context_sentences, translated_context_asp_sentences, translated_context_default_logic_sentences, extracted_context_predicates, extracted_context_entities, llama3_8B_model, llama3_model_tokenizer, fine_tune_f2, repair_f3, -1, '', Question_ASP_List, Origin_Question_Label_Lists,FineTune_Question_Positive_Sample_List, FineTune_Question_Negative_Sample_List)
    # Iterate through question list, formalize natural language questions into ASP  # TODO: Manual translation needed
    Fact_in_Question_List = [] # Used to store facts or entities contained in questions. eg. all_other_birds. 
    for question_key in range(len(Question_List)):
        Question_sentence = Question_List[question_key]
        sentence_to_be_translated = Question_sentence.lower()
        root.node_nl_sentence = Question_sentence
        # Call Large model to first translate facts/rules into ASP. Deduction step first extracts predicates, then translates multiple candidate sentences  # TODO: Manual translation needed
        Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Total_Semantic_Score_Lists = LLM_ASP_Solver_Single_Sentence('question', translated_context_sentences, translated_context_asp_sentences,translated_context_default_logic_sentences, extracted_context_predicates, extracted_context_entities, sentence_to_be_translated, llama3_8B_model, llama3_model_tokenizer, repair_f3)
        asp_sentence_score_list,Total_Semantic_Score_Lists, Predicate_Used_in_Sentence, Entities_in_ASP_Sentence, Translated_Default_Logic_of_Sentence_list, Translated_ASP_Program_of_Sentence_list, Verfier_Result_list = root.Select_Optimal_Translation_Result(sentence_to_be_translated, Total_Predicate_Used_in_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, Total_Semantic_Score_Lists)
        
        FineTune_Question_Positive_Sample_List, FineTune_Question_Negative_Sample_List = root.write_fine_tune_data(asp_sentence_score_list, Total_Semantic_Score_Lists, Total_Predicate_Used_in_Sentence_Lists, Total_Entities_in_ASP_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists,Total_Translated_ASP_Program_of_Sentence_Lists, Total_Verfier_Result_Lists, FineTune_Question_Positive_Sample_List, FineTune_Question_Negative_Sample_List)

        
        if len(asp_sentence_score_list) > 0 and len(Translated_ASP_Program_of_Sentence_list)>0:
            best_asp_sentence_index = asp_sentence_score_list.index(max(asp_sentence_score_list))
            
            # Formalize the formalization results of questions  # TODO: Manual translation needed
            if len(translated_context_asp_sentences) > 0: # If ASP sentences in context are not empty, perform predicate consistency alignment
                translated_question_sentences =  Question_sentence
                translated_question_asp_sentences = Translated_ASP_Program_of_Sentence_list[best_asp_sentence_index]
                
            else:
                translated_question_asp_sentences = Translated_ASP_Program_of_Sentence_list[best_asp_sentence_index]
            
            if ':-' in translated_question_asp_sentences:
                fact = translated_question_asp_sentences.split(':-')[-1].strip()
                if ', ' in fact:
                    fact = fact.split(', ')[0].strip()
                Fact_in_Question_List.append(fact)
                translated_question_asp_sentences = translated_question_asp_sentences.split(':-')[0].strip()+ '.'
                translated_question_asp_sentences = translated_question_asp_sentences.replace('..', '.')

            Question_ASP_List.extend([translated_question_asp_sentences]) # Add last candidate translation result to question list            print('question_key={}, Question_sentence={}, Translated_ASP_Program_of_Question_Sentence={}'.format(question_key, sentence_to_be_translated, translated_question_asp_sentences))
        else:
            Question_ASP_List.extend([''])
            print('Question translation failed!')

    print('Question translation completed, Question_ASP_List={}'.format(Question_ASP_List))

    FineTune_Question_Positive_Sample_List = root.FineTune_Positive_Sample_List # Positive samples for fine-tuning generated after question translation
    FineTune_Question_Negative_Sample_List = root.FineTune_Negative_Sample_List # Negative samples for fine-tuning generated after question translation


    # If questions contain prerequisites, add to context  # TODO: Manual translation needed
    Fact_in_Question_Str = ''.join([fact if fact.endswith('.') else fact + '.' for fact in Fact_in_Question_List])
    Total_Translated_Context_ASP_Sentences = translated_context_asp_sentences + Fact_in_Question_Str
    
    # Context translation completed, call ASP solver to generate answer sets  # TODO: Manual translation needed
    # If return is error, it means program error, if return [] it means facts in context are contradictory. If return [[]] it means answer set in context is 0  # TODO: Manual translation needed
    Total_Translated_Context_ASP_Sentences = Total_Translated_Context_ASP_Sentences.replace('..','.')
    solver_result_answer_set = ASP_Verifier_Solver(Total_Translated_Context_ASP_Sentences,'', opt=False)
    if len(solver_result_answer_set) == 0 or 'error' in solver_result_answer_set: # If return is error, it means program error, if return [] it means facts in context are contradictory. If return [[]] it means answer set in context is 0
        solver_result_answer_set = []
        
        # Call symbol solver multiple times, delete facts in context that contradict current facts  # TODO: Manual translation needed
        translated_context_asp_sentences03 = copy.deepcopy(Total_Translated_Context_ASP_Sentences)
        context_asp_list01 = translated_context_asp_sentences03.split('.')
        context_asp_list = []
        for key01 in range(len(context_asp_list01)):
            if len(context_asp_list01[key01])>5:
                context_asp_list.append(context_asp_list01[key01] + '.')
        # Delete translated ASP sentences in context one by one. Find sentences that contradict current ones  # TODO: Manual translation needed
        context_asp_string2,context_asp_string3 = '',''
        for key01 in range(len(context_asp_list)):
            next_fact = context_asp_list[key01]
            context_asp_string3 = context_asp_string2 + next_fact
            verifier_result01 = ASP_Verifier_Solver(context_asp_string3, '', opt=False)
            if len(verifier_result01)!=0 and 'error' not in verifier_result01:
                if len(verifier_result01[0])!=0:
                    context_asp_string2 = copy.deepcopy(context_asp_string3)
                    solver_result_answer_set = copy.deepcopy(verifier_result01)


    if len(solver_result_answer_set) == 1 and len(solver_result_answer_set[0])==0: # If return is error, it means program error, if return [] it means facts in context are contradictory. If return [[]] it means answer set in context is 0
        solver_result_answer_set = []
        # Call symbol solver multiple times, delete facts in context that contradict current facts  # TODO: Manual translation needed
        translated_context_asp_sentences03 = copy.deepcopy(Total_Translated_Context_ASP_Sentences)
        context_asp_list01 = translated_context_asp_sentences03.split('.')
        context_asp_list = []
        for key01 in range(len(context_asp_list01)):
            if len(context_asp_list01[key01])>5:
                context_asp_list.append(context_asp_list01[key01] + '.')
        # Delete translated ASP sentences in context one by one. Find sentences that contradict current ones  # TODO: Manual translation needed
        context_asp_string2,context_asp_string3 = '',''
        for key01 in range(len(context_asp_list)):
            next_fact = context_asp_list[key01]
            context_asp_string3 = context_asp_string2 + next_fact
            verifier_result01 = ASP_Verifier_Solver(context_asp_string3, '', opt=False)
            if len(verifier_result01[0])!=0:
                context_asp_string2 = copy.deepcopy(context_asp_string3)
                solver_result_answer_set = copy.deepcopy(verifier_result01)

                    
            
    

    # If translated context is empty, return directly  # TODO: Manual translation needed
    print('translated_context_sentences={}, len(answer sets)={}, answer set:{}, Question_ASP_List={}'.format(translated_context_sentences, len(solver_result_answer_set), solver_result_answer_set, Question_ASP_List))
    #Iterate through questions  # TODO: Manual translation needed
    LLMs_Generted_Label_List_with_Similarity, LLMs_Generted_Label_List_with_EM, LLMs_Generted_Label_List_with_LLMs = [], [], [] # Used to store labels for each question
    
    for question_key in range(len(Question_ASP_List)):
        question_sentence = Question_ASP_List[question_key]
        if len(question_sentence)==0:
            LLMs_Generted_Label_List_with_EM.append(['F'])
            LLMs_Generted_Label_List_with_Similarity.append(['F'])
        else:
            predicate_question_label_with_EM, predicate_question_label_with_LLMs, predicate_question_label_with_Similarity = Generate_Label_with_Skeptical_Credulous_for_LogicBench(solver_result_answer_set, question_sentence, Reasoning_Mode, llama3_8B_model, llama3_model_tokenizer)
            LLMs_Generted_Label_List_with_EM.append([predicate_question_label_with_EM])
            LLMs_Generted_Label_List_with_Similarity.append([predicate_question_label_with_Similarity])
            LLMs_Generted_Label_List_with_LLMs.append([predicate_question_label_with_LLMs])

    if Dataset_Type=='train': # If data type is training set, need to add samples generated during training to file
        # First determine if training sample answer is correct, if correct add positive sample, if wrong add negative sample, use label generated by similarity method model as standard  # TODO: Manual translation needed
        # Calculate accuracy between LLMs_Generted_Label_List_with_EM and Origin_Question_Label_Lists  # TODO: Manual translation needed
        correct_count = 0
        total_count = 0
        for i in range(len(LLMs_Generted_Label_List_with_EM)):
            pred_label = LLMs_Generted_Label_List_with_EM[i][0] if len(LLMs_Generted_Label_List_with_EM[i]) > 0 else ''
            true_label = Origin_Question_Label_Lists[i][0] if len(Origin_Question_Label_Lists[i]) > 0 else ''
            if pred_label == true_label:
                correct_count += 1
            total_count += 1
        accuracy = correct_count / total_count if total_count > 0 else 0
        print("Accuracy between LLMs_Generted_Label_List_with_EM and Origin_Question_Label_Lists is: {:.4f}".format(accuracy))
        
        if accuracy >= 1.0:
            for positive_key in range(len(FineTune_Positive_Extracted_Fact_Rule_List)): # Write positive training samples in context
                Write_fine_tune_Dict01 = FineTune_Positive_Extracted_Fact_Rule_List[positive_key]
                Write_fine_tune_Dict01['Sample_Number'] = Generate_Fine_Tune_Sample_Number
                Verifier_Label_string= Write_fine_tune_Dict01['Verifier_result_string']
                if 'yes' not in Verifier_Label_string:
                    Write_fine_tune_Dict01['Verifier_result_string'] = 'yes'
                Write_fine_tune_Dict01 = json.dumps(Write_fine_tune_Dict01, ensure_ascii=False)
                fine_tune_f2.write(Write_fine_tune_Dict01 + '\n')
                print('FineTune_Positive_Extract_Fact_Rules_Sample_List:{}, Generate_Fine_Tune_Sample_Number={}'.format(positive_key, Generate_Fine_Tune_Sample_Number)) 
                Generate_Fine_Tune_Sample_Number = Generate_Fine_Tune_Sample_Number + 1

            for positive_key in range(len(FineTune_Positive_Sample_List)): # Write positive training samples in context
                Write_fine_tune_Dict01 = FineTune_Positive_Sample_List[positive_key]
                Write_fine_tune_Dict01['Sample_Number'] = Generate_Fine_Tune_Sample_Number
                Write_fine_tune_Dict01 = json.dumps(Write_fine_tune_Dict01, ensure_ascii=False)
                fine_tune_f2.write(Write_fine_tune_Dict01 + '\n')
                print('FineTune_Positive_Sample_List:{}, Generate_Fine_Tune_Sample_Number={}'.format(positive_key, Generate_Fine_Tune_Sample_Number)) 
                Generate_Fine_Tune_Sample_Number = Generate_Fine_Tune_Sample_Number + 1
            
            for question_positive_key in range(len(FineTune_Question_Positive_Sample_List)):
                Write_fine_tune_Dict01 = FineTune_Question_Positive_Sample_List[question_positive_key]
                Write_fine_tune_Dict01['Sample_Number'] = Generate_Fine_Tune_Sample_Number
                Write_fine_tune_Dict01 = json.dumps(Write_fine_tune_Dict01, ensure_ascii=False)
                fine_tune_f2.write(Write_fine_tune_Dict01 + '\n')
                print('FineTune_Question_Positive_Sample_List:{}, Generate_Fine_Tune_Sample_Number={}'.format(question_positive_key, Generate_Fine_Tune_Sample_Number))
                Generate_Fine_Tune_Sample_Number = Generate_Fine_Tune_Sample_Number + 1

        if accuracy <=0.3: # If accuracy is below 0.3, then consider output of extracted facts and default rule module as error
            for negative_key in range(len(FineTune_Negative_Extracted_Fact_Rule_List)): # Write positive training samples in context
                Write_fine_tune_Dict01 = FineTune_Negative_Extracted_Fact_Rule_List[negative_key]
                Write_fine_tune_Dict01['Sample_Number'] = Generate_Fine_Tune_Sample_Number
                Verifier_Label_string= Write_fine_tune_Dict01['Verifier_result_string']
                if 'no' not in Verifier_Label_string:
                    continue
                Write_fine_tune_Dict01 = json.dumps(Write_fine_tune_Dict01, ensure_ascii=False)
                fine_tune_f2.write(Write_fine_tune_Dict01 + '\n')
                print('FineTune_Negative_Extracted_Fact_Rule_List:{}, Generate_Fine_Tune_Sample_Number={}'.format(negative_key, Generate_Fine_Tune_Sample_Number)) 
                Generate_Fine_Tune_Sample_Number = Generate_Fine_Tune_Sample_Number + 1


        for negative_key in range(len(FineTune_Negative_Sample_List)): # Write negative training samples generated in context
            Write_fine_tune_Dict01 = FineTune_Negative_Sample_List[negative_key]
            Write_fine_tune_Dict01['Sample_Number'] = Generate_Fine_Tune_Sample_Number
            Write_fine_tune_Dict01 = json.dumps(Write_fine_tune_Dict01, ensure_ascii=False)
            fine_tune_f2.write(Write_fine_tune_Dict01 + '\n')
            print('FineTune_Negative_Sample_List:{}, Generate_Fine_Tune_Sample_Number={}'.format(negative_key,Generate_Fine_Tune_Sample_Number))
            Generate_Fine_Tune_Sample_Number = Generate_Fine_Tune_Sample_Number + 1


        for question_negative_key in range(len(FineTune_Question_Negative_Sample_List)):
            Write_fine_tune_Dict01 = FineTune_Question_Negative_Sample_List[question_negative_key]
            Write_fine_tune_Dict01['Sample_Number'] = Generate_Fine_Tune_Sample_Number
            Write_fine_tune_Dict01 = json.dumps(Write_fine_tune_Dict01, ensure_ascii=False)
            fine_tune_f2.write(Write_fine_tune_Dict01 + '\n')
            print('FineTune_Question_Negative_Sample_List:{}, Generate_Fine_Tune_Sample_Number={}'.format(question_negative_key, Generate_Fine_Tune_Sample_Number))
            Generate_Fine_Tune_Sample_Number = Generate_Fine_Tune_Sample_Number + 1

    # Return translated context and questions  # TODO: Manual translation needed
    return translated_context_sentences, solver_result_answer_set,Question_ASP_List, LLMs_Generted_Label_List_with_EM, LLMs_Generted_Label_List_with_Similarity, LLMs_Generted_Label_List_with_LLMs

# Define a function to calculate the longest common subsequence of two strings  # TODO: Manual translation needed
def Longest_Common_Substring(text1, text2):
    m, n = len(text1), len(text2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    max_len = 0  # Record length of longest common substring
    end_index = 0  # Record end position of longest common substring in text1
    
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if text1[i - 1] == text2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
                if dp[i][j] > max_len:
                    max_len = dp[i][j]
                    end_index = i
    
    # Extract longest common substring from text1  # TODO: Manual translation needed
    start_index = end_index - max_len
    longest_substring = text1[start_index:end_index]
    
    return int(len(longest_substring))


# Define a function to reason about questions based on answer sets, Reasoning_Flag indicates whether it is skeptical reasoning or credulous reasoning  # TODO: Manual translation needed
# Define a function to label questions on generated answer sets based on Large model  # TODO: Manual translation needed
def Generate_Label_with_Skeptical_Credulous_for_LogicBench_with_LLMs(answer_sets, question_asp_sentence, Reasoning_Mode, llama3_8B_model, llama3_model_tokenizer):
    return 'M'
    question_label = ''
    # If answer set error, then output label as 'M'
    if len(answer_sets) >0:
            if len(answer_sets[0]) == 0:
                question_label = 'M'
                print('Answer set is empty. answer_sets={}'.format(answer_sets))
                return question_label
    if len(answer_sets) == 0 or 'error' in answer_sets or len(question_asp_sentence) == 0:
        print('Answer set or question is empty or error. answer_sets={}, question_asp_sentence={}'.format(answer_sets, question_asp_sentence))
        question_label = 'M'
        return question_label

    Answer_Set_String_List = []
    for key01 in range(len(answer_sets)): 
        answer_set = answer_sets[key01]
        answer_set_string = ''
        for key02 in range(len(answer_set)): # Convert facts in single extension to string
            answer_set_string = answer_set_string + answer_set[key02] + '. '
        Answer_Set_String_List.append(answer_set_string)

    Reasoning_Instruction= ''
    global Reasoning_Prompt_for_LogicBench
    Reasoning_Instruction = Reasoning_Prompt_for_LogicBench
    # Iterate through Answer_Set_String_List, build prompt content  # TODO: Manual translation needed
    answer_set_string_prompt = ''
    question_asp_sentence01 = question_asp_sentence.strip()
    neg_question_asp_sentence = '-' + question_asp_sentence01 # Store negation of question
    neg_question_asp_sentence = neg_question_asp_sentence.replace('--','')


    question_answer_result_on_Extension_list, neg_question_answer_result_on_Extension_list= [],[]
    # Call Large model to determine if question is in extension  # TODO: Manual translation needed
    for key03 in range(len(Answer_Set_String_List)):
        # Judge each single extension sequentially  # TODO: Manual translation needed
        answer_set_string_prompt = answer_set_string_prompt + 'The extension are: ' + Answer_Set_String_List[key03] + 'The question is: ' + neg_question_asp_sentence


        while_count01 =0
        #Determine if single extension contains question  # TODO: Manual translation needed
        while True:
            if while_count01>5:
                break
            while_count01 = while_count01 + 1

            question_answer_result = Calling_LLAMA3_with_API(Reasoning_Instruction, answer_set_string_prompt)
            print('question_answer_result:'.format(question_answer_result))
            if len(question_answer_result) < 4:
                continue
            else:
                question_answer_result = question_answer_result[0:30]
        ### Add a function to judge format of Large model generation results, if format does not match, regenerate.  # TODO: Manual translation needed
            if 'unknown' not in question_answer_result and 'Unknown' not in question_answer_result and 'true' not in question_answer_result and 'True' not in question_answer_result and 'false' not in question_answer_result and 'False' not in question_answer_result:
                continue
            else:
                break
        if 'unknown' in question_answer_result or 'Unknown' in question_answer_result:
            question_label = 'M'
        elif 'true' in question_answer_result or 'True' in question_answer_result:
            question_label = 'T'
        elif 'false' in question_answer_result or 'False' in question_answer_result:
            question_label = 'F'
        else:
            question_label = 'M'
        question_answer_result_on_Extension_list.append(question_label)
    
    # Call Large model to determine if negation of question is in extension  # TODO: Manual translation needed
    for key03 in range(len(Answer_Set_String_List)):
        # Judge each single extension sequentially  # TODO: Manual translation needed
        answer_set_string_prompt = answer_set_string_prompt + 'The extension are: ' + Answer_Set_String_List[key03] + 'The question is: ' + question_asp_sentence


        while_count01 =0
        #Determine if single extension contains question  # TODO: Manual translation needed
        while True:
            if while_count01>5:
                break
            while_count01 = while_count01 + 1

            neg_question_answer_result = Calling_LLAMA3_with_API(Reasoning_Instruction, answer_set_string_prompt)
            print('neg_question_answer_result:'.format(neg_question_answer_result))
            if len(neg_question_answer_result) < 4:
                continue
            else:
                neg_question_answer_result = neg_question_answer_result[0:30]
        ### Add a function to judge format of Large model generation results, if format does not match, regenerate.  # TODO: Manual translation needed
            if 'unknown' not in neg_question_answer_result and 'Unknown' not in neg_question_answer_result and 'true' not in neg_question_answer_result and 'True' not in neg_question_answer_result and 'false' not in neg_question_answer_result and 'False' not in neg_question_answer_result:
                continue
            else:
                break
        if 'unknown' in neg_question_answer_result or 'Unknown' in neg_question_answer_result:
            question_label = 'M'
        elif 'true' in neg_question_answer_result or 'True' in neg_question_answer_result:
            question_label = 'T'
        elif 'false' in neg_question_answer_result or 'False' in neg_question_answer_result:
            question_label = 'F'
        else:
            question_label = 'M'
        neg_question_answer_result_on_Extension_list.append(question_label)




    
    Finall_Question_Lable = None
    # Credulous reasoning mode  # TODO: Manual translation needed
    if 'true' in question_answer_result_on_Extension_list:
        credulous_predict_label = 'T'
    elif 'true' in neg_question_answer_result_on_Extension_list:
        credulous_predict_label = 'F'
    else:
        credulous_predict_label = 'M'

    # Skeptical reasoning mode  # TODO: Manual translation needed
    if 'false' not in question_answer_result_on_Extension_list and 'unknown' not in question_answer_result_on_Extension_list and 'true' not in neg_question_answer_result_on_Extension_list:
        skeptical_predict_label = 'T'
    elif 'true' not in question_answer_result_on_Extension_list and 'false' not in neg_question_answer_result_on_Extension_list and 'unknown' not in neg_question_answer_result_on_Extension_list:
        skeptical_predict_label = 'F'
    else:
        skeptical_predict_label = 'M'
    Finall_Question_Lable = credulous_predict_label if Reasoning_Mode =='credulous' else skeptical_predict_label

    print('question_text:{}, Finall_Question_Lable:{}, Answer_Set_List:{}'.format(question_asp_sentence, Finall_Question_Lable, answer_sets))

    return Finall_Question_Lable

 
# Label based on similarity using generated answer sets  # TODO: Manual translation needed
def Generate_Label_with_Skeptical_Credulous_for_LogicBench_with_Similarity(answer_sets, question_asp_sentence, Reasoning_Mode):
    Similarity_Value = 0.9

    Total_Question_Label = '' # Used to store label for entire question
    # If answer set error, then output label as 'M'
    if len(answer_sets) >0:
            if len(answer_sets[0]) == 0:
                question_label = 'M'
                print('Answer set is empty. answer_sets={}'.format(answer_sets))
                return question_label
    if len(answer_sets) == 0 or 'error' in answer_sets or len(question_asp_sentence) == 0:
        print('Answer set or question is empty or error. answer_sets={}, question_asp_sentence={}'.format(answer_sets, question_asp_sentence))
        question_label = 'M'
        return question_label

    if len(answer_sets) >= 10:
        answer_sets = answer_sets[:10]
    
    question_fact_label_list = [] #  Used to store labels in question facts, if all are true, then final question is true
    question = question_asp_sentence
    skeptical_question_label_Flag_List = [] # Used to mark if question is in answer set
    skeptical_question_negation_label_Flag_List = [] # Used to mark if negation of question is in answer set


    question_label = ''
    answer_sets01 = copy.deepcopy(answer_sets)
    # If answer set error, then output label as 'M'
    if 'error' in answer_sets01 or len(answer_sets01[0]) == 0:
        print('Answer set is empty or error. answer_sets={}'.format(answer_sets))
        question_label = 'F'
        return question_label
    question01 = copy.deepcopy(question)
    question01 = question01.replace(' ','').strip()
    Extract_predicate = re.compile(r'(.*?)[(]', re.S)  #
    Extract_entity = re.compile(r'[(](.*?)[)]', re.S)  # Used to extract LLAMA3 output results
    question_predicate_list = re.findall(Extract_predicate, question01) if '(' in question01 else ['']
    question_entity_list = re.findall(Extract_entity, question01) if '(' and ')' in question01 else ['']
    if len(question_predicate_list) == 0 or len(question_entity_list) == 0:
        print('Question predicate is empty. question={}'.format(question01))
        question_label = 'M'
        return question_label
    question_predicate_text = question_predicate_list[0]
    question_entity_text = question_entity_list[0]


    question_predicate_negation_text = '-'+ question_predicate_text # Generate negation form of question
    question_predicate_negation_text = question_predicate_negation_text.replace('--', '') # Remove duplicate negative signs
    
    question_negation_text = '-'+ question01 # Generate negation form of question
    question_negation_text = question_negation_text.replace('--', '') # Remove duplicate negative signs

    # Replace '-' in question with 'not'
    question01 = question01.replace('-','not ')
    question_predicate_text = question_predicate_text.replace('-', 'not ')
    question_predicate_negation_text = question_predicate_negation_text.replace('-', 'not ')
    question_negation_text = question_negation_text.replace('-', 'not ')

    answer_predicate_sets01 = copy.deepcopy(answer_sets01)
    answer_entity_sets01 = copy.deepcopy(answer_sets01)
    total_answer_sets01 = copy.deepcopy(answer_sets01)
    for answer_key in range(len(answer_sets01)):

        # Iterate through each fact in answer set, replace '-' with 'not'
        extension_fact_list = answer_sets01[answer_key]
        for key01 in range(len(extension_fact_list)): # Iterate through extensions, convert negation in extensions to 'not '
            generate_predicate_list = re.findall(Extract_predicate, extension_fact_list[key01]) if '(' in question else ['']# Returns a list
            generate_entitie_list = re.findall(Extract_entity, extension_fact_list[key01]) if '(' and ')' in question else ['']

            answer_predicate_sets01[answer_key][key01] = generate_predicate_list[0].replace('-', 'not ') if len(generate_predicate_list) > 0 else extension_fact_list[key01]
            answer_entity_sets01[answer_key][key01] = generate_entitie_list[0].replace('-', 'not ') if len(generate_entitie_list) > 0 else extension_fact_list[key01]
            total_answer_sets01[answer_key][key01] = extension_fact_list[key01].replace('-','not ')

        # Get conclusion facts from fact set  # TODO: Manual translation needed
        # Calculate similarity between question and facts in answer set  # TODO: Manual translation needed
        question_answer_predicate_similarity = Embedding_Similarity([question_predicate_text], answer_predicate_sets01[answer_key])
        question_answer_entity_similarity = Embedding_Similarity([question_entity_text], answer_entity_sets01[answer_key])
        total_question_answer_similarity = Embedding_Similarity([question01], total_answer_sets01[answer_key])
        question_answer_similarity = total_question_answer_similarity 
        print('question_answer_similarity with question={}'.format(question_answer_similarity))
        # If minimum value of maximum similarity for each fact is greater than 0.9, then it means all facts have found corresponding facts  # TODO: Manual translation needed
        max_question_answer_similarity01 = torch.max(question_answer_similarity, dim=1)  # Find maximum value of each row in similarity matrix
        # Calculate similarity between question negation and facts in answer set  # TODO: Manual translation needed
        neg_question_answer_predicate_similarity = Embedding_Similarity([question_predicate_negation_text], answer_sets01[answer_key])
        total_neg_question_answer_similarity = Embedding_Similarity([question_negation_text], total_answer_sets01[answer_key])
        neg_question_answer_similarity = total_neg_question_answer_similarity
        print('question_answer_similarity with question negation={}'.format(neg_question_answer_similarity))

        # If minimum value of maximum similarity for each fact is greater than 0.9, then it means all facts have found corresponding facts  # TODO: Manual translation needed
        max_neg_question_answer_similarity01 = torch.max(neg_question_answer_similarity, dim=1)  # Find maximum value of each row in similarity matrix
        if max_question_answer_similarity01.values >= Similarity_Value and max_question_answer_similarity01.values > max_neg_question_answer_similarity01.values:
            skeptical_question_label_Flag_List.append('True')
        else:
            skeptical_question_label_Flag_List.append('False')
        if max_neg_question_answer_similarity01.values >= Similarity_Value and max_neg_question_answer_similarity01.values > max_question_answer_similarity01.values:
            skeptical_question_negation_label_Flag_List.append('True')
        else:
            skeptical_question_negation_label_Flag_List.append('False')
        
    Finall_Question_Lable = None
    # Credulous reasoning mode  # TODO: Manual translation needed
    if 'True' in skeptical_question_label_Flag_List:
        credulous_predict_label = 'T'
    elif 'True' in skeptical_question_negation_label_Flag_List:
        credulous_predict_label = 'F'
    else:
        credulous_predict_label = 'M'

    # Skeptical reasoning mode  # TODO: Manual translation needed
    if 'False' not in skeptical_question_label_Flag_List and 'Unknown' not in skeptical_question_label_Flag_List and 'True' not in skeptical_question_negation_label_Flag_List:
        skeptical_predict_label = 'T'
    elif 'True' not in skeptical_question_label_Flag_List and 'False' not in skeptical_question_negation_label_Flag_List and 'Unknown' not in skeptical_question_negation_label_Flag_List:
        skeptical_predict_label = 'F'
    else:
        skeptical_predict_label = 'M'
    Finall_Question_Lable = credulous_predict_label if Reasoning_Mode =='credulous' else skeptical_predict_label

    return Finall_Question_Lable



# Define a function to reason about labels for a single question  # TODO: Manual translation needed
def Question_Label_with_EM(answer_sets, question, Reasoning_Mode):
    question_label = ''
    Extract_predicate = re.compile(r'(.*?)[(]', re.S)  #
    Extract_entity = re.compile(r'[(](.*?)[)]', re.S)  # Used to extract LLAMA3 output results
    # If answer set error, then output label as 'M'
    question = question.replace(' ','')
    # Extract predicate of original question  # TODO: Manual translation needed
    question_predicate_list = re.findall(Extract_predicate, question) if '(' in question else ['']
    question_entity_list = re.findall(Extract_entity, question) if '(' and ')' in question else ['']
    if len(question_predicate_list) == 0 or len(question_entity_list) == 0:
        print('Question predicate is empty. question={}'.format(question))
        question_label = 'M'
        return question_label
    question_predicate_text = question_predicate_list[0]
    question_entity_text = question_entity_list[0]
    
    question_negation_text = '-'+question_predicate_text # Generate negation form of question
    question_negation_text = question_negation_text.replace('--', '') # Remove duplicate negative signs
    skeptical_question_label_Flag_List = [] # Used to mark if question is in answer set
    skeptical_question_negation_label_Flag_List = [] # Used to mark if negation of question is in answer set
    skeptical_question_unknown_label_Flag_List = [] # Used to mark if negation of question is in answer set

    
    # Iterate through each answer set  # TODO: Manual translation needed
    # Iterate through each answer set, determine if extension contains question based on exact match  # TODO: Manual translation needed
    for answer_set in answer_sets:
        # Iterate through each element in answer set  # TODO: Manual translation needed
        skeptical_question_label_Flag_List, skeptical_question_negation_label_Flag_List =[], []
        qustion_in_extension_flag = False
        for fact_key in range(len(answer_set)): # Fact is like happy(toby)
            # Extract predicate from fact using regular expression  # TODO: Manual translation needed
            
            generate_predicate_list = re.findall(Extract_predicate, answer_set[fact_key]) if '(' in question else ['']# Returns a list
            generate_entitie_list = re.findall(Extract_entity, answer_set[fact_key]) if '(' and ')' in question else ['']
            generate_predicate, generate_entitie = '',''
            if len(generate_predicate_list)!=0 and len(generate_entitie_list)!=0:
                generate_predicate = generate_predicate_list[0].replace(' ','')
                generate_entitie = generate_entitie_list[0].replace(' ','')
            # Get predicate from answer set, if matches question, then reset question label to True, otherwise False  # TODO: Manual translation needed
            # If matches negation of question, then reset negation question label to True, otherwise False  # TODO: Manual translation needed
            if generate_predicate == question_predicate_text and generate_entitie == question_entity_text:
                skeptical_question_label_Flag_List.append('True')
                qustion_in_extension_flag = True
                break
            elif Longest_Common_Substring(generate_predicate, question_predicate_text) >= 6 and generate_predicate[0] != '-' and question_predicate_text[0] != '-' and generate_entitie == question_entity_text:
                skeptical_question_label_Flag_List.append('True')
                qustion_in_extension_flag = True
                break
            elif Longest_Common_Substring(generate_predicate, question_predicate_text) >= 6 and generate_predicate[0] == '-' and question_predicate_text[0] == '-' and generate_entitie == question_entity_text:
                skeptical_question_label_Flag_List.append('True')
                qustion_in_extension_flag = True
                break
            else: # If all facts in extension do not match question, then mark as False
                continue
        if qustion_in_extension_flag == False: # If question is not in extension, then mark as False
            skeptical_question_label_Flag_List.append('False')
                
            
    # Iterate through each answer set, determine if extension contains question based on exact match  # TODO: Manual translation needed
    for answer_set in answer_sets:
        # Iterate through each element in answer set  # TODO: Manual translation needed
        qustion_in_extension_flag = False
        for fact_key in range(len(answer_set)): # Fact is like happy(toby)
            # Extract predicate from fact using regular expression  # TODO: Manual translation needed
            
            generate_predicate_list = re.findall(Extract_predicate, answer_set[fact_key]) if '(' in question else ['']# Returns a list
            generate_entitie_list = re.findall(Extract_entity, answer_set[fact_key]) if '(' and ')' in question else ['']
            generate_predicate, generate_entitie = '',''
            if len(generate_predicate_list)!=0 and len(generate_entitie_list)!=0:
                generate_predicate = generate_predicate_list[0].replace(' ','')
                generate_entitie = generate_entitie_list[0].replace(' ','')
            if generate_predicate == question_negation_text and generate_entitie == question_entity_text:
                skeptical_question_negation_label_Flag_List.append('True')
                qustion_in_extension_flag = True
                break
            elif Longest_Common_Substring(generate_predicate, question_negation_text) >= 6 and generate_predicate[0] != '-' and question_negation_text[0] != '-' and generate_entitie == question_entity_text:
                skeptical_question_negation_label_Flag_List.append('True')
                qustion_in_extension_flag = True
                break
            elif Longest_Common_Substring(generate_predicate, question_negation_text) >= 6 and generate_predicate[0] == '-' and question_negation_text[0] == '-' and generate_entitie == question_entity_text:
                skeptical_question_negation_label_Flag_List.append('True')
                qustion_in_extension_flag = True
                break
            else: # If iterated to last element, i.e., answer set contains neither predicate nor negation of predicate. Then label is M
                continue
        if qustion_in_extension_flag == False:
            skeptical_question_negation_label_Flag_List.append('False')
                

    Finall_Question_Lable = None
    # Credulous reasoning mode  # TODO: Manual translation needed
    if 'True' in skeptical_question_label_Flag_List:
        credulous_predict_label = 'T'
    elif 'True' in skeptical_question_negation_label_Flag_List:
        credulous_predict_label = 'F'
    else:
        credulous_predict_label = 'M'

    # Skeptical reasoning mode  # TODO: Manual translation needed
    if 'False' not in skeptical_question_label_Flag_List and 'unknown' not in skeptical_question_label_Flag_List and 'True' not in skeptical_question_negation_label_Flag_List:
        skeptical_predict_label = 'T'
    elif 'True' not in skeptical_question_label_Flag_List and 'False' not in skeptical_question_negation_label_Flag_List and 'unknown' not in skeptical_question_negation_label_Flag_List:
        skeptical_predict_label = 'F'
    else:
        skeptical_predict_label = 'M'
    Finall_Question_Lable = credulous_predict_label if Reasoning_Mode =='credulous' else skeptical_predict_label

                

    return Finall_Question_Lable
        


# Define a function to reason about questions based on answer sets, Reasoning_Flag indicates whether it is skeptical reasoning or credulous reasoning, EM= Exact Match  # TODO: Manual translation needed
# question_List represents a conclusion, a conclusion may contain multiple facts  # TODO: Manual translation needed
def Generate_Label_with_Skeptical_Credulous_for_LogicBench(answer_sets, question_asp_sentence, Reasoning_Mode, llama3_8B_model, llama3_model_tokenizer):
    '''
    answer_sets: answer set
    question: question
    Reasoning_Mode: Reasoning mode
    '''
    Total_Question_Label_EM, Total_Question_Label_LLM, Total_Question_Label_Similarity = '','','' # Used to store label for entire question
    if len(answer_sets) >0:
            if len(answer_sets[0]) == 0:
                question_label = 'M'
                print('Answer set is empty. answer_sets={}'.format(answer_sets))
                return question_label,question_label,question_label
    if len(answer_sets) == 0 or 'error' in answer_sets or len(question_asp_sentence) == 0:
        print('Answer set or question is empty or error. answer_sets={}, question_List={}'.format(answer_sets, question_asp_sentence))
        question_label = 'M'
        return question_label,question_label,question_label
    question_list= []
    question_list01 = question_asp_sentence.split('.')
    for question_key in range(len(question_list01)):
        if len(question_list01[question_key])==0:
            continue
        question_list.append(question_list01[question_key])
    
    question_list = question_list[:3] if len(question_list)>=3 else question_list

    question_fact_label_list_EM,question_fact_label_list_LLM, question_fact_label_list_Similariy = [],[],[] #  Used to store labels in question facts, if all are true, then final question is true
    # A question may contain multiple sentences.   # TODO: Manual translation needed
    for question_fact_key in range(len(question_list)):
        question = question_list[question_fact_key]
        question_or_list =[]
        if '|' in question: # Handle case where question has OR relationship
            question_or_list01 = question.split('|')
            for key01 in range(len(question_or_list01)):
                if len(question_or_list01[key01])==0:
                    continue
                question_or_list.append(question_or_list01[key01])
            question_fact_label_list02_EM,question_fact_label_list02_LLM, question_fact_label_list02_Similarity = [],[],[]
            for question_key in range(len(question_or_list)):
                question_label_with_EM = Question_Label_with_EM(answer_sets, question_or_list[question_key], Reasoning_Mode)
                question_label_with_Similarity = Generate_Label_with_Skeptical_Credulous_for_LogicBench_with_Similarity(answer_sets, question_or_list[question_key], Reasoning_Mode)
                question_label_with_LLMs = Generate_Label_with_Skeptical_Credulous_for_LogicBench_with_LLMs(answer_sets, question_or_list[question_key], Reasoning_Mode, llama3_8B_model, llama3_model_tokenizer)

                question_fact_label_list02_EM.append(question_label_with_EM)
                question_fact_label_list02_LLM.append(question_label_with_LLMs)
                question_fact_label_list02_Similarity.append(question_label_with_Similarity)

            if 'T' in question_fact_label_list02_EM: 
                question_fact_label_list_EM.append('T')
            else:
                question_fact_label_list_EM.append('F')
            if 'T' in question_fact_label_list02_LLM: 
                question_fact_label_list_LLM.append('T')
            else:
                question_fact_label_list_LLM.append('F')
            if 'T' in question_fact_label_list02_Similarity: 
                question_fact_label_list_Similariy.append('T')
            else:
                question_fact_label_list_Similariy.append('F')
            

        else: # Handle case without OR
            question_label_EM = Question_Label_with_EM(answer_sets, question, Reasoning_Mode)
            question_label_with_Similarity = Generate_Label_with_Skeptical_Credulous_for_LogicBench_with_Similarity(answer_sets, question, Reasoning_Mode)
            question_label_with_LLMs = Generate_Label_with_Skeptical_Credulous_for_LogicBench_with_LLMs(answer_sets, question, Reasoning_Mode, llama3_8B_model, llama3_model_tokenizer)

            question_fact_label_list_EM.append(question_label_EM)
            question_fact_label_list_LLM.append(question_label_with_LLMs)
            question_fact_label_list_Similariy.append(question_label_with_Similarity)
    
    # Based on labels of all facts in question, give final conclusion label  # TODO: Manual translation needed
    # Generally, question is true only when all facts in question are true  # TODO: Manual translation needed

    if 'F' in question_fact_label_list_EM:
        Total_Question_Label_EM = 'F'
    elif 'T' in question_fact_label_list_EM and 'F' not in question_fact_label_list_EM and 'M' not in question_fact_label_list_EM:
        Total_Question_Label_EM = 'T'
    elif 'M' in question_fact_label_list_EM:
        Total_Question_Label_EM = 'M'
    else:
        Total_Question_Label_EM = 'M'

    if 'F' in question_fact_label_list_LLM:
        Total_Question_Label_LLM = 'F'
    elif 'T' in question_fact_label_list_LLM and 'F' not in question_fact_label_list_LLM and 'M' not in question_fact_label_list_LLM:
        Total_Question_Label_LLM = 'T'
    elif 'M' in question_fact_label_list_LLM:
        Total_Question_Label_LLM = 'M'
    else:
        Total_Question_Label_LLM = 'M'

    if 'F' in question_fact_label_list_Similariy:
        Total_Question_Label_Similarity = 'F'
    elif 'T' in question_fact_label_list_Similariy and 'F' not in question_fact_label_list_Similariy and 'M' not in question_fact_label_list_Similariy:
        Total_Question_Label_Similarity = 'T'
    elif 'M' in question_fact_label_list_Similariy:
        Total_Question_Label_Similarity = 'M'
    else:
        Total_Question_Label_Similarity = 'M'
    
    
    return Total_Question_Label_EM, Total_Question_Label_LLM, Total_Question_Label_Similarity





def Evaluation_Train_Test_Data_for_LogicBench(Read_Test_Data_file, Write_fine_tune_file_path, Write_Result_file_path, Expert_Iterative_Number, llama3_8B_model, llama3_model_tokenizer, NMR_Category, Dataset_Type):
    repair_f3 = None
    with open(Read_Test_Data_file, 'r') as f0, open(Write_Result_file_path, 'w', encoding='utf-8') as result_f1, open(Write_fine_tune_file_path, 'a', encoding='utf-8') as fine_tune_f2: #, open(Write_Repair_file_path, 'a', encoding='utf-8') as repair_f3:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict = {}
        Label_Dict = {'yes': 'T', 'no': 'F'}

        global Answer_Set_List, Soft_Answer_Set_List, Prerequisite_Conclusion_Consistent_Facts_Dict
        global Each_Example_chatgpt_Number
        Each_Example_chatgpt_Number = 0
        LLMs_Generted_Label_List = []
        LLMs_Generted_Answer_Set_Explanation_List = []
        js = json.load(f0)
        # Divide dataset into train/validation/test  # TODO: Manual translation needed
        # print(json.dumps(js, ensure_ascii=False))
        type = js['type']
        axiom = js['axiom']
        samples_List = js['samples']  if Dataset_Type == 'test' else js['data_samples']  # Calculate number of facts in default theory
        samples_number = 0
        for sample in samples_List:
            
            Write_Result_Dict = {}  # This dictionary is used to store final results
            Each_Example_chatgpt_Number = 0
            Sample_number = sample['id'] if Dataset_Type == 'test' else samples_number
            # if samples_number ==0:
            #     samples_number = samples_number + 1
            #     continue
            samples_number = samples_number + 1

            if int(Sample_number)< -1: # 418
                continue

            if Dataset_Type=='train' and int(Sample_number)>50:
                continue
            context = sample['context'].lower()
            qa_pairs = sample['qa_pairs']
            Question_text_List,Label_List = [],[]
            Question_context_List = [] # Used to store prerequisites in original question If...
            for qa_pair in qa_pairs:
                question_text = qa_pair['question'].lower()
                question_text = question_text.replace(' usually ', ' ').replace(', ',' ')
                if 'if ' in question_text and 'does this mean that' in question_text:
                    question_text_list = question_text.replace('if','').split('does this mean that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'if ' in question_text and 'does this entail that' in question_text:
                    question_text_list = question_text.replace('if','').split('does this entail that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'if ' in question_text and 'does this imply that' in question_text:
                    question_text_list = question_text.replace('if','').split('does this imply that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'if ' in question_text and 'does this suggest that' in question_text:
                    question_text_list = question_text.replace('if','').split('does this suggest that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                else:
                    question_text = question_text.replace('does this entail that ','').replace('does this mean that ','').replace('does this imply that ','').replace('does this suggest that ','').replace('does the context imply that ','').replace('does this conclude that ','').replace('can we imply that ','').replace('does this conclude that ','').replace('?','.').replace('does the context conclude that','').replace('can we conclude that', '')

                answer = qa_pair['answer']
                Question_text_List.append(question_text)
                Label_List.append(Label_Dict[answer])
        
            if len(Question_context_List)>0:
                solver_result_answer_set_List = []
                Question_ASP_List_List, LLMs_Generted_Label_List_with_EM_List, LLMs_Generted_Label_List_with_Similarity_List,  LLMs_Generted_Label_List_with_LLMs_List = [],[],[],[]
                for key01 in range(len(Question_context_List)):
                    Write_Result_Dict = {}  # This dictionary is used to store final results

                    total_context = Question_context_List[key01] + context
                    question_text_list = [Question_text_List[key01]]
                    label_list = [Label_List[key01]]
                    translated_context_sentences, solver_result_answer_set,Question_ASP_List, LLMs_Generted_Label_List_with_EM, LLMs_Generted_Label_List_with_Similarity, LLMs_Generted_Label_List_with_LLMs = LLM_ASP_Solver(Sample_number, question_text_list, '', total_context, llama3_8B_model, llama3_model_tokenizer, Dataset_Type,NMR_Category, fine_tune_f2, repair_f3, label_list)
                    Question_ASP_List_List.extend(Question_ASP_List)
                    LLMs_Generted_Label_List_with_EM_List.extend(LLMs_Generted_Label_List_with_EM)
                    LLMs_Generted_Label_List_with_Similarity_List.extend(LLMs_Generted_Label_List_with_Similarity)
                    LLMs_Generted_Label_List_with_LLMs_List.extend(LLMs_Generted_Label_List_with_LLMs)
                    solver_result_answer_set_List.append(solver_result_answer_set)

                Total_count01 = Total_count01 + 1
                Write_Result_Dict['Sample_number'] = str(Sample_number)  # Sample number
                Write_Result_Dict['type'] = type
                Write_Result_Dict['axiom'] = axiom
                Write_Result_Dict['context'] = total_context
                Write_Result_Dict['Generated_ASP_Facts_Rules'] = translated_context_sentences
                Write_Result_Dict['Generated_ASP_Questions'] = Question_ASP_List_List
                Write_Result_Dict['NL_Origin_Question_Text'] = Question_text_List
                Write_Result_Dict['Origin_Question_Label_Lists'] = Label_List
                Write_Result_Dict['Answer_set'] = solver_result_answer_set_List
                Write_Result_Dict['LLMs_Generted_Label_List_with_EM'] = LLMs_Generted_Label_List_with_EM_List
                Write_Result_Dict['LLMs_Generted_Label_List_with_Similarity'] = LLMs_Generted_Label_List_with_Similarity_List
                Write_Result_Dict['LLMs_Generted_Label_List_with_LLMs'] = LLMs_Generted_Label_List_with_LLMs_List
                Write_Result_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
                Write_Result_Dict['Each_Example_chatgpt_Number'] = Each_Example_chatgpt_Number

                Write_Result_Dict['LLMs_Repose'] = ''
                Write_Result_Dict = json.dumps(Write_Result_Dict, ensure_ascii=False)
                result_f1.write(Write_Result_Dict + '\n')

                print('Sample {} completed! Generated EM labels: {}, generated similarity labels: {}, generated LLMs labels: {}, true labels: {}'.format(str(Sample_number), LLMs_Generted_Label_List_with_EM_List, LLMs_Generted_Label_List_with_Similarity_List , LLMs_Generted_Label_List_with_LLMs_List, Label_List))

            else:
                translated_context_sentences, solver_result_answer_set,Question_ASP_List, LLMs_Generted_Label_List_with_EM, LLMs_Generted_Label_List_with_Similarity, LLMs_Generted_Label_List_with_LLMs = LLM_ASP_Solver(Sample_number, Question_text_List, '', context, llama3_8B_model, llama3_model_tokenizer, Dataset_Type,NMR_Category, fine_tune_f2, repair_f3, Label_List)


                Total_count01 = Total_count01 + 1

                Write_Result_Dict['Sample_number'] = str(Sample_number)  # Sample number
                Write_Result_Dict['type'] = type
                Write_Result_Dict['axiom'] = axiom
                Write_Result_Dict['context'] = context
                Write_Result_Dict['Generated_ASP_Facts_Rules'] = translated_context_sentences
                Write_Result_Dict['Generated_ASP_Questions'] = Question_ASP_List
                Write_Result_Dict['NL_Origin_Question_Text'] = Question_text_List
                Write_Result_Dict['Origin_Question_Label_Lists'] = Label_List
                Write_Result_Dict['Answer_set'] = solver_result_answer_set
                Write_Result_Dict['LLMs_Generted_Label_List_with_EM'] = LLMs_Generted_Label_List_with_EM
                Write_Result_Dict['LLMs_Generted_Label_List_with_Similarity'] = LLMs_Generted_Label_List_with_Similarity
                Write_Result_Dict['LLMs_Generted_Label_List_with_LLMs'] = LLMs_Generted_Label_List_with_LLMs
                Write_Result_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
                Write_Result_Dict['Each_Example_chatgpt_Number'] = Each_Example_chatgpt_Number

                Write_Result_Dict['LLMs_Repose'] = ''
                Write_Result_Dict = json.dumps(Write_Result_Dict, ensure_ascii=False)
                result_f1.write(Write_Result_Dict + '\n')

                print('Reasoning mode{}!Sample {} completed! Generated EM labels: {}, generated similarity labels: {}, generated LLMs labels: {}, true labels: {}'.format(NMR_Category, str(Sample_number), LLMs_Generted_Label_List_with_EM, LLMs_Generted_Label_List_with_Similarity , LLMs_Generted_Label_List_with_LLMs, Label_List))



        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # Calculate accuracy
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List, average = 'macro')
        print('accuracy={},F1={}'.format(accuracy,F1))


# Define a function to get read and write file paths  # TODO: Manual translation needed
def Get_Read_and_Write_file_path(Expert_Iterative_Number, Dataset_Type):
        Read_Data_file = ''
        if Dataset_Name == 'LogicBench' and Dataset_Type == 'test':
            Read_Data_file = read_file_path + 'data/LogicBench(Eval)/' + str(Task_Type) + '/' + 'nm_logic/' + str(NMR_Category) +'/'+ 'data_instances'+ '.json'
        elif Dataset_Name == 'LogicBench' and Dataset_Type == 'train':
            Read_Data_file = read_file_path + 'data/LogicBench(Aug)/' + 'nm_logic/'  + str(NMR_Category) + '/'+ 'data_instances'+ '.json' # + 'default_reasoning_default' +
        else:
            print('Dataset does not exist!')
            exit()
        # Used to save final solution results of samples LLMs_Models_Choise:['DeepSeek'] ;Dataset_Type:['test', 'train'], Reasoning_Mode:['skeptical', 'credulous']  # TODO: Manual translation needed
        # ASP_Number_ Represents the number of translations for each sentence
        Write_Result_file_path = ''
        if Dataset_Name == 'LogicBench':
            Write_Result_file_path = write_file_path + 'SC-NMRer_Tree' + str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Semantic_Verifier_' + str(Semantic_Verifier_Flag) + '_Grammaer_Verifier_' + str(Grammaer_Verifier_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type +'_' + NMR_Category + '_balance' + '.json'
        elif Dataset_Name == 'LogicEval':
            Write_Result_file_path = write_file_path + 'SC-NMRer_Tree' + str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Semantic_Verifier_' + str(Semantic_Verifier_Flag) + '_Grammaer_Verifier_' + str(Grammaer_Verifier_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_Deep' + Reasoning_Deep + '_' + NMR_Category + '_balance' + '.json'
        else:
            print('Dataset does not exist!')
            exit()
        # Used to save fine-tuning training set  # TODO: Manual translation needed
        Write_fine_tune_file_path = write_file_path + 'SC-NMRer_Tree'+ str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Semantic_Verifier_' + str(Semantic_Verifier_Flag) + '_Grammaer_Verifier_' + str(Grammaer_Verifier_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_fine_tune_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type + '_balance' + '.json'
        # Read data for fine-tuning model  # TODO: Manual translation needed
        Read_fine_tune_Data_file = write_file_path + 'SC-NMRer_Tree' + str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Semantic_Verifier_' + str(Semantic_Verifier_Flag) + '_Grammaer_Verifier_' + str(Grammaer_Verifier_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_fine_tune_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type + '_balance' + '.json'
        
        return Read_Data_file, Write_Result_file_path, Write_fine_tune_file_path, Read_fine_tune_Data_file #, Write_Repair_file_path_ASP_Repair, Read_Repair_Data_file_ASP_Repair

if __name__ == '__main__':
    # Perform expert iteration for model framework  # TODO: Manual translation needed
    # Perform expert iteration for model framework  # TODO: Manual translation needed
    Expert_Iterative_Number = Total_Expert_Iterative_Number # Expert iteration count, starting from 0
    # Dataset_Type indicates whether currently reading test set or validation set, test means test set, train means training set  # TODO: Manual translation needed
    Test_llama3_8B_model, Test_llama3_model_tokenizer = None, None

    for Category_key in range(len(NMR_Category_List)): # Iterate through each reasoning mode once
        if int(Category_key)<-1:
            continue
        # if int(Category_key)>=7:
        #     continue
        NMR_Category = NMR_Category_List[Category_key]
        Prompt_List(NMR_Category)
        print('Start evaluating samples in reasoning mode {}!'.format(NMR_Category))
        # Load initial model  # TODO: Manual translation needed
        
    
        # First step: evaluate test set  # TODO: Manual translation needed
        # Get read and write file paths, currently reading test set  # TODO: Manual translation needed
        if Dataset_Type == 'test': # If currently test set, need to evaluate test set
            Read_Data_file, Write_Result_file_path, Write_fine_tune_file_path, Read_fine_tune_Data_file = Get_Read_and_Write_file_path(Expert_Iterative_Number, Dataset_Type)
            # Read dataset and test, if only test set, only generate test set results. If training set, generate both fine-tuning samples and results.  # TODO: Manual translation needed
            # Read_Test_Data_file represents path of test dataset, Write_file_path02 is path for saving test set output results  # TODO: Manual translation needed
            Evaluation_Train_Test_Data_for_LogicBench(Read_Data_file, Write_fine_tune_file_path, Write_Result_file_path, Expert_Iterative_Number, Test_llama3_8B_model, Test_llama3_model_tokenizer,NMR_Category, Dataset_Type='test')
            print('Evaluation of samples in reasoning mode {} of test set completed!'.format(NMR_Category))
        
