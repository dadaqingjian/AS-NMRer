"""
Calculate the results produced by the large model through evaluation metrics,
"""
import copy
import random
import sys
import re
import httpx

sys.path.append('/home/Projects/LLM_ASP_NeSY_Solver/Datasets')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
import json
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import torch
from clingo.control import Control
from clingo.symbol import parse_term

from transformers import TrainingArguments
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
max_seq_length = 2048
Reasoning_Mode = 'credulous' # [credulous, skeptical]
Fine_Tune_Iterative_Number = 0 # Used to indicate which iteration of fine-tuning it is, 1 means the first iteration, 2 means the second iteration, and so on
Translation_Sentences_Number = 3 # Represents the number of translations for each sentence
Semantic_Verifier_Flag, Grammaer_Verifier_Flag,Aligned_Rules_Flag = True, True, False
Allatonce_Flag = True # Used to indicate whether it is allatonce mode
Formal_Natural_Language = 'ASP' # ['ASP','DL']
Reasoning_With_Similarity = False # Used to indicate whether to reason about the question on the answer set based on similarity or directly use the large model to reason about the question
Dataset_Type = 'test' # ['train', 'dev', 'test']
M_as_F_Flag = True # Used to indicate whether it is M as F
LLMs_Models_Choise = "DeepSeek_V32_671B" # ['GPT4o_mini','DeepSeek_V31_671B','DeepSeek_R1_671B','DeepSeek_R1_8B','DeepSeek_R1','Gemma3_27B','Gemma2_9B','Gemma3_4B','Qwen3_4B']

# LLASP_0_DeepSeek_R1_32B_ASP_Number_3_FNL_ASP_Semantic_Verifier_True_Grammaer_Verifier_True_Aligned_False_Allatonce_True_fine_tune_on_LogicBench_credulous_test_BQA_balance.json

Dataset_Name = 'LogicBench' # Represents the dataset ['MultiLogicNMR_OOD', 'MultiLogicNMR_NL', 'MultiLogicNMR']
Task_Type, NMR_Category = '', ''
Reasoning_Deep = ''
if Dataset_Name == 'LogicBench':
    Task_Type = 'BQA' # ['BQA','MCQA']
    # ['default_reasoning_default', 'default_reasoning_irr', 'default_reasoning_open','default_reasoning_several','reasoning_about_exceptions_1','reasoning_about_exceptions_2','reasoning_about_exceptions_3','reasoning_about_priority']


write_file_path = '/home/Projects/LLM_ASP_NeSY_Solver/Experiment/Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 # Used to filter the answer set

import warnings
warnings.filterwarnings("ignore")

Label_Dict_with_M = {'F':[0],'T':[1],'M':[2],'':[2]}
Label_Dict_with_M_as_F = {'F':[0],'T':[1],'M':[0],'':[0]}


# Define a function to evaluate the similarity matching degree of two sentence sets.
def Similarity_Explaination(Generation_Explain_list, Explaination_list):
    Predict_Explain_Number = len(Generation_Explain_list)
    # Iterate through all generated sentences,
    Explaination_list01 = copy.deepcopy(Explaination_list)
    # Iterate through the true extension list, one label may have multiple extensions
    avager_similarity_list = []
    for key00 in range(len(Explaination_list01)):
        Correct_Explain_Number = len(Explaination_list[key00])
        Explaination_list02 = Explaination_list01[key00]
        similarity_matrix = [] # Store the similarity of all generated sentences under one extension
        for key01 in range(len(Generation_Explain_list)):
            similarity_list01= [] # Store the similarity of a single sentence in the extension
            for key02 in range(len(Explaination_list02)):
                similarity = difflib.SequenceMatcher(None, Generation_Explain_list[key01], Explaination_list02[key02]).ratio()
                similarity_list01.append(similarity)
            similarity_matrix.append(similarity_list01)

        # Iterate through the similarity matrix and calculate the average matching accuracy.
        total_similarity01 = 0 # Represents the matching accuracy of the generated explanation relative to a true explanation.
        for similarity_list in similarity_matrix:
            max_similarity = max(similarity_list)
            total_similarity01 = total_similarity01 + max_similarity if max_similarity>0.5 else total_similarity01
        avager_similarity = total_similarity01 / Correct_Explain_Number
        avager_similarity_list.append(avager_similarity)

        # Then calculate the value for this extension based on the similarity matrix
    # Return the maximum similarity value between the generated explanation and the true extension
    max_avager_similarity = max(avager_similarity_list)
    return max_avager_similarity

def Read(NMR_Category):
    read_file_path02 = write_file_path + 'LLASP_' + str(Fine_Tune_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Semantic_Verifier_' + str(Semantic_Verifier_Flag) + '_Grammaer_Verifier_' + str(Grammaer_Verifier_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type +'_' + NMR_Category + '_balance' + '.json'
    with open(read_file_path02, 'r',encoding='utf-8') as f0:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List_EM, Total_LLMs_Generted_Label_List_Similarity, Total_LLMs_Generted_Label_List_LLMs, Total_LLMs_Generted_Label_List_DL_and_LLMs = [], [], [], []
        Yes_or_No_Question_Label_Dict = {} # Divide by yes or no to calculate scores.
        Yes_or_No_LLMs_Generted_Label_Dict_EM, Yes_or_No_LLMs_Generted_Label_Dict_Similarity, Yes_or_No_LLMs_Generted_Label_Dict_LLMs, Yes_or_No_LLMs_Generted_Label_Dict_DL_and_LLMs = {}, {}, {}, {}
        Total_count01 = 1
        Test_Extension_Example_Dict ={}

        for line in f0:
            if Total_count01 <= 1: # The first sample is not calculated
                Total_count01 = Total_count01 + 1
                continue
            
            js = json.loads(line.strip())
            Sample_number = js['Sample_number']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            LLMs_Generted_Label_List_with_EM = js['LLMs_Generted_Label_List_with_EM']
            LLMs_Generted_Label_List_with_Similarity = js['LLMs_Generted_Label_List_with_Similarity']
            LLMs_Generted_Label_List_with_LLMs = js['LLMs_Generted_Label_List_with_LLMs']

            for label in Origin_Question_Label_Lists:
                if label not in Yes_or_No_Question_Label_Dict.keys():
                    Yes_or_No_Question_Label_Dict[label] = []
                    Yes_or_No_LLMs_Generted_Label_Dict_EM[label] =[]
                    Yes_or_No_LLMs_Generted_Label_Dict_Similarity[label] =[]
                    Yes_or_No_LLMs_Generted_Label_Dict_LLMs[label] =[]
                    Yes_or_No_LLMs_Generted_Label_Dict_DL_and_LLMs[label] =[]

            # Iterate through the label list of the sample
            for label, predict_label_EM, predict_label_Similarity, predict_label_LLMs in zip(Origin_Question_Label_Lists, LLMs_Generted_Label_List_with_EM, LLMs_Generted_Label_List_with_Similarity, LLMs_Generted_Label_List_with_LLMs):
                Label_Dict = {}
                if M_as_F_Flag == True: # If M as F, set the label of M to F
                    Label_Dict = copy.deepcopy(Label_Dict_with_M_as_F)
                else:
                    Label_Dict = copy.deepcopy(Label_Dict_with_M)

                Total_Question_label_List.extend(Label_Dict[label[0]])
                Total_LLMs_Generted_Label_List_EM.extend(Label_Dict[predict_label_EM[0]])
                Total_LLMs_Generted_Label_List_Similarity.extend(Label_Dict[predict_label_Similarity[0]])
                Total_LLMs_Generted_Label_List_LLMs.extend(Label_Dict[predict_label_LLMs[0]])

                EM_Similarity_LLM_Label_List = []
                EM_Similarity_LLM_Label_List.extend(Label_Dict[predict_label_EM[0]])
                EM_Similarity_LLM_Label_List.extend(Label_Dict[predict_label_Similarity[0]])
                EM_Similarity_LLM_Label_List.extend(Label_Dict[predict_label_LLMs[0]])
                if int(EM_Similarity_LLM_Label_List.count(0)) > int(EM_Similarity_LLM_Label_List.count(1)):
                    Total_LLMs_Generted_Label_List_DL_and_LLMs.extend([0])
                else:
                    Total_LLMs_Generted_Label_List_DL_and_LLMs.extend([1])

                Yes_or_No_Question_Label_Dict[label].extend(Label_Dict[label[0]])
                Yes_or_No_LLMs_Generted_Label_Dict_EM[label].extend(Label_Dict[predict_label_EM[0]])
                Yes_or_No_LLMs_Generted_Label_Dict_Similarity[label].extend(Label_Dict[predict_label_Similarity[0]])
                Yes_or_No_LLMs_Generted_Label_Dict_LLMs[label].extend(Label_Dict[predict_label_LLMs[0]])

                if int(EM_Similarity_LLM_Label_List.count(0)) > int(EM_Similarity_LLM_Label_List.count(1)):
                    Yes_or_No_LLMs_Generted_Label_Dict_DL_and_LLMs[label].extend([0])
                else:
                    Yes_or_No_LLMs_Generted_Label_Dict_DL_and_LLMs[label].extend([1])

            Total_count01 = Total_count01 + 1
        print('Total_count01={},Test_Extension_Example_Dict={}'.format(Total_count01,Test_Extension_Example_Dict))

        em_accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_EM)  # Calculate accuracy
        em_F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_EM, average='macro')
        print('The total accuracy of EM={},The total F1 of EM={}'.format(em_accuracy, em_F1))

        similarity_accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_Similarity)  # Calculate accuracy
        similarity_F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_Similarity, average='macro')
        print('The total accuracy of Similarity={},The total F1 of Similarity={}'.format(similarity_accuracy, similarity_F1))

        return em_F1, similarity_F1
        # accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_LLMs)  # Calculate accuracy
        # F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_LLMs, average='macro')
        # print('The total accuracy of LLMs={},The total F1 of LLMs={}'.format(accuracy, F1))

        # accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_DL_and_LLMs)  # Calculate accuracy
        # F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List_DL_and_LLMs, average='macro')
        # print('The total accuracy of DL_and_LLMs={},The total F1 of DL_and_LLMs={}'.format(accuracy, F1))

        # # Iterate through the extension dictionary and calculate the values produced under different extensions respectively
        # for key in Yes_or_No_Question_Label_Dict.keys():
        #     label_list = Yes_or_No_Question_Label_Dict[key]
        #     predict_label_list= Yes_or_No_LLMs_Generted_Label_Dict_EM[key]
        #     accuracy = accuracy_score(label_list, predict_label_list)  # Calculate accuracy
        #     F1 = f1_score(label_list, predict_label_list, average='macro')
        #     print('The accuracy of EM on Label {} is {},The F1 of EM on Label {} is {}'.format(str(key),accuracy, str(key), F1))

        # for key in Yes_or_No_Question_Label_Dict.keys():
        #     label_list = Yes_or_No_Question_Label_Dict[key]
        #     predict_label_list= Yes_or_No_LLMs_Generted_Label_Dict_Similarity[key]
        #     accuracy = accuracy_score(label_list, predict_label_list)  # Calculate accuracy
        #     F1 = f1_score(label_list, predict_label_list, average='macro')
        #     print('The accuracy of Similarity on Label {} is {},The F1 of Similarity on Label {} is {}'.format(str(key),accuracy, str(key), F1))

        # for key in Yes_or_No_Question_Label_Dict.keys():
        #     label_list = Yes_or_No_Question_Label_Dict[key]
        #     predict_label_list= Yes_or_No_LLMs_Generted_Label_Dict_LLMs[key]
        #     accuracy = accuracy_score(label_list, predict_label_list)  # Calculate accuracy
        #     F1 = f1_score(label_list, predict_label_list, average='macro')
        #     print('The accuracy of LLMs on Label {} is {},The F1 of LLMs on Label {} is {}'.format(str(key),accuracy, str(key), F1))

        # for key in Yes_or_No_Question_Label_Dict.keys():
        #     label_list = Yes_or_No_Question_Label_Dict[key]
        #     predict_label_list= Yes_or_No_LLMs_Generted_Label_Dict_DL_and_LLMs[key]
        #     accuracy = accuracy_score(label_list, predict_label_list)  # Calculate accuracy
        #     F1 = f1_score(label_list, predict_label_list, average='macro')
        #     print('The accuracy of DL_and_LLMs on Label {} is {},The F1 of DL_and_LLMs on Label {} is {}'.format(str(key),accuracy, str(key), F1))

if __name__ == '__main__':
    NMR_Category_List = ['default_reasoning_default','default_reasoning_irr', 'default_reasoning_open','default_reasoning_several','reasoning_about_exceptions_1','reasoning_about_exceptions_2','reasoning_about_exceptions_3','reasoning_about_priority']
    em_accuracy_List, similarity_accuracy_List = [], []
    for NMR_Category in NMR_Category_List:
        em_accuracy, similarity_accuracy = Read(NMR_Category)
        em_accuracy_List.append(em_accuracy)
        similarity_accuracy_List.append(similarity_accuracy)
        print('NMR_Category={} calculation completed\n \n'.format(NMR_Category))
    # Calculate average
    print("\n Average em_accuracy:{},Average similarity_accuracy:{}".format(sum(em_accuracy_List) / len(em_accuracy_List), sum(similarity_accuracy_List) / len(similarity_accuracy_List)))
