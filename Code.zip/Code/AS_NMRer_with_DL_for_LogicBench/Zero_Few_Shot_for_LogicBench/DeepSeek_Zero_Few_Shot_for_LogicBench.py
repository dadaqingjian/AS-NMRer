"""
Implementation of Neuro-Symbolic Methods for Non-Monotonic Reasoning
"""
from abc import ABC, abstractmethod
from collections import defaultdict
import math
import copy
import random
import sys
import re
import httpx
import torch
# Ensure this path is generic or relative in your deployment
sys.path.append('/home/Projects/LLM_ASP_NeSY_Solver/Datasets') 
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
import traceback
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["NCCL_P2P_DISABLE"] = "1" # Disable NCCL P2P communication
os.environ["NCCL_IB_DISABLE"] = "0"  # Disable NCCL IB communication

import torch
from clingo.control import Control
from clingo.symbol import parse_term
from transformers import TrainingArguments, AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig, AutoTokenizer, AutoModel
from trl import SFTTrainer, SFTConfig, DataCollatorForCompletionOnlyLM
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from peft import LoraConfig
import json
from datasets import Dataset
import pandas as pd
from sentence_transformers import SentenceTransformer, util
import warnings
warnings.filterwarnings("ignore")
import numpy as np

max_seq_length = 2048
Reasoning_Mode = 'credulous' # [credulous, skeptical]
Formal_Natural_Language = 'DL' # ['ASP','DL']
Translation_Sentences_Number = 1 # Represents the number of translations per sentence. When 1, each sentence is translated once, and no verifier is used.
Aligned_Rules_Flag = False # Flag to indicate whether to perform predicate consistency alignment. True means using the alignment module; False means not using it.
Iterative_Repair_Flag = False # Flag to indicate repair mode. True means direct repair; False means indirect repair.
Allatonce_Flag = False # Flag to indicate whether to perform one-step sentence-by-sentence reasoning or all-at-once reasoning. True means all-at-once; False means step-by-step.
Grammar_Semantic_Verifier_Flag = False if Translation_Sentences_Number == 1 else True # When the number of generated candidate sentences is 1, it means each sentence is translated only once, and no verifier is used.
Selected_Sentence_Number = 1 # Represents the number of sentences selected from the candidate translation list to join the context. Default is 1.
Dataset_Name = 'LogicBench' # Dataset name ['MultiLogicNMR_OOD', 'MultiLogicNMR_NL', 'MultiLogicNMR','LogicBench','LogicNMR','LogicEval']
Similarity_with_GPT4_Flag, Similarity_with_LLAMA31_Flag, Similarity_with_Sentence_Transformer_Flag = False, False, True # Flags to indicate whether to reason based on similarity in the answer set or directly use the Large Model for reasoning.
Zero_or_Few_Shot = 'Few_Shot' # ['Zero_Shot','Few_Shot', 'Zero_Shot_COT','Few_Shot_COT', 'COT_Extensions', 'COT_Symbolic']

Task_Type, NMR_Category = '', ''
NMR_Category_List = ['default_reasoning_default', 'default_reasoning_irr', 'default_reasoning_open','default_reasoning_several','reasoning_about_exceptions_1','reasoning_about_exceptions_2','reasoning_about_exceptions_3','reasoning_about_priority']
Reasoning_Deep = ''

if Dataset_Name == 'LogicBench':
    Task_Type = 'BQA' # ['BQA','MCQA']
elif Dataset_Name =='LogicEval':
    Reasoning_Deep = '1'

if Dataset_Name == 'LogicEval' and Reasoning_Deep == '1':
    NMR_Category_List = ['default_reasoning_default', 'default_reasoning_irr', 'default_reasoning_open','default_reasoning_several','reasoning_about_exceptions_1','reasoning_about_exceptions_2','reasoning_about_exceptions_3','reasoning_about_priority']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '2':
    NMR_Category_List = ['BDR_MP','BDR_MT','DRD_MP','DRD_MT','DRI_MP','DRI_MT','PBD_MP','PBD_MT','REI_MP','REI_MT','REII_MP','REII_MT']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '3':
    NMR_Category_List = ['d3_1','d3_2']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '4':
    NMR_Category_List = ['d4_1','d4_2']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '5':
    NMR_Category_List = ['d5_1','d5_2']

LLMs_Models_Choise = "DeepSeek" # ['GPT3.5','GPT4','Claude','Gemma_7B','Mistral_7B','LLAMA3','LLAMA31']


read_file_path = '/home/Projects/LLM_ASP_NeSY_Solver/Datasets/' + str(Dataset_Name) + '/'
write_file_path = '/home/Projects/LLM_ASP_NeSY_Solver/Experiment/Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1, 5 # Used to filter answer sets

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


# Set random seed
setup_seed(20)

LogicBench_Few_Shot_Example_Dict ={"default_reasoning_default": "For example 1: Context: kangaroos and emus are marsupials. marsupials usually carry their young in a pouch. kangaroos are possibly an exception to this rule. ### \n Question: emus carry their young in a pouch? ### \n The answer label of question is: True. Question: emus don\'t carry their young in a pouch? ### \n The answer label of question is: False. ### \n", "default_reasoning_irr": "### \n For example 1: Cotext: dogs and cats are animals. animals typically live in homes. dogs are not living in homes. ### \n Question: cats are living in homes? ### \n The answer label of question is: True. ### \n Question: cats are living in homes? ### \n The answer label of question is: False. ### \n", "default_reasoning_open": "### \n For example 1: Context: lemurs are primates. primates have opposable thumbs. lemurs do not have opposable thumbs. ### \n Question: all other primates than lemurs have opposable thumbs? ### \n ### \n The answer label of question is: True. ### \n Question: all other primates than lemurs have opposable thumbs? ### \n The answer label of question is: False. ### \n", "default_reasoning_several": "### \n For example 1: Context: john and tim are friends. friends are loyal. friends are always supportive. john is not loyal. tim is not supportive. ### \n Question: tim is loyal and john is supportive? ### \n The answer label of question is: True. ### \n Question: tim isn\'t loyal and john is supportive? ### \n ### \n The answer label of question is: False. ### \n", "reasoning_about_exceptions_1": "### \n For example 1: Context: apples, oranges, and bananas are fruits. fruits are typically rich in vitamins. at least one of apples or oranges does not contain vitamins. ## \n Question: bananas aren\'t rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### \n The answer label of question is: True. ### \n Question: bananas are rich in vitamins and exactly one of apples or oranges does not contain vitamins? ### \ The answer label of question is: False. ### \n", "reasoning_about_exceptions_2": "### \n For example 1: Context: cars drive on roads. at least one car doesn\'t drive on roads. ### \n Question: exactly one car drive on roads? ### \n The answer label of question is: True ### \n Qestion: exactly one car doesn't drive on roads? ### \n The answer label of question is: False ### \n ", "reasoning_about_exceptions_3": "### \n For example 1: Context: cats are carnivores. carnivores normally eat meat. at least one carnivore does not eat meat. ### \n Question: cats usually eat meat? ### \n The answer label of question is: True ### \n Question: cats usually don\'t eat meat? ### \n The answer label of question is: False ### \n", "reasoning_about_priority": "### \n For example 1: Context: john asserts that the cat is in the park. jane asserts that the cat is not in the park. jane\'s evidence is more reliable than john\'s. ### \n Question: the cat is not in the park? ### \n The answer label of question is: True ### \n Question: the cat is in the park? ### \n The answer label of question is: False ### \n"}

Zero_Shot_Instruction, Three_Few_Shot_Instruction, Zero_Shot_COT_Instruction = '','',''
def Prompt_List(NMR_Category):
    global Zero_Shot_Instruction, Three_Few_Shot_Instruction, Zero_Shot_COT_Instruction
    if Zero_or_Few_Shot == 'Zero_Shot':
        Example_Dict = LogicBench_Few_Shot_Example_Dict 
    elif Zero_or_Few_Shot == 'Few_Shot':
        Example_Dict = LogicBench_Few_Shot_Example_Dict 

    if Dataset_Name =='LogicBench':
        Example_NMR_Category = NMR_Category 
    if Dataset_Name =='LogicEval' and int(Reasoning_Deep)  ==1:
        Example_NMR_Category = NMR_Category
    elif Dataset_Name =='LogicEval' and int(Reasoning_Deep) ==2: # Need to map the reasoning mode of samples with reasoning depth 2 to LogicBench's reasoning mode to use corresponding sample examples
        if 'BDR' in NMR_Category:
            Example_NMR_Category = 'default_reasoning_default'
        elif 'DRD' in NMR_Category:
            Example_NMR_Category = 'default_reasoning_default'
        elif 'DRI' in NMR_Category:
            Example_NMR_Category = 'default_reasoning_irr'
        elif 'PBD' in NMR_Category:
            Example_NMR_Category = 'reasoning_about_priority'
        elif 'REI' in NMR_Category:
            Example_NMR_Category = 'reasoning_about_exceptions_1'
        elif 'REII' in NMR_Category:
            Example_NMR_Category = 'reasoning_about_exceptions_2'
        else:
            Example_NMR_Category = 'default_reasoning_default'

    Zero_Shot_Instruction = 'Task Description: \n  Given contexts and question, You need to generate answer labels for questions in a given context. The question ONLY in "True" or "False". \n If the question can be inferred based on the context, the answer label of the question is: "True"; \n  if the negation of the question can be inferred based on the context, the answer label of the question is: "False"; \n The input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for the question. \n  Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '
    Three_Few_Shot_Instruction = 'Task Description: \n  Given contexts and question, You need to generate answer labels for questions in a given context. The question ONLY in "True" or "False". \n If the question can be inferred based on the context, the answer label of the question is: "True"; \n  if the negation of the question can be inferred based on the context, the answer label of the question is: "False"; \n The input format is Context: ". Question:". The output format is: The answer label of question is:". ' + Example_Dict[Example_NMR_Category] + 'You must generate answer labels for the question. \n  Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '
    Zero_Shot_COT_Instruction = 'Task Description: \n  Given contexts and question, You need to perform step-by-step reasoning and generate answer labels for questions in a given context. The question ONLY in "True" or "False". \n If the question can be inferred based on the context, the answer label of the question is: "True"; \n  if the negation of the question can be inferred based on the context, the answer label of the question is: "False"; \n The input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for the question. \n  Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. Let\'s think step by step. '
        

# API KEY PLACEHOLDER
API_Key = "YOUR_API_KEY_HERE" 
Base_URL =  "https://api.deepseek.com/v1" #  "https://api.nhyun.top" #"https://35.aigcbest.top/v1"


Train_Dataset, Test_Datset = None, None
Label2Text = {'T':'True', 'F':'False', 'M':'Unknown'}

llama3_8B_model, llama3_model_tokenizer = None, None
from unsloth import FastLanguageModel

Extract_Predicate_Pattern, Extract_Entity_Pattern, Translated_Sentence_Pattern = None, None, None
Translated_Sentence_Pattern_for_LogicBench = None
Predicate_Entity_ASP_Pattern, Repair_ASP_Program_Pattern= None, None
Repair_ASP_Program_Pattern_With_GPT4, Repair_Explanation_With_GPT4 = None, None
Semantic_Score_Pattern, Semantic_Explanation_Pattern, Grammar_Score_Pattern = None, None, None
Aligned_ASP_Pattern = None

if LLMs_Models_Choise =='DeepSeek':
    # Define the template for extracting ASP results generated by calling the LLAMA31 model
    Extract_Predicate_Pattern = "(?<=The predicate of the sentence is:).*?(?=Note|#|Instruction|1```1|```|The entities of the sentence is|\n)"  # Used to extract LLAMA3 output results
    Extract_Entity_Pattern = "(?<=The entities of the sentence is:).*?(?=Note|#|Instruction|Instantiation|1```1|```|The translated the sentence is|\n)"  # Used to extract LLAMA3 output results
    Translated_Sentence_Pattern = "(?<=The translated sentence is:).*?(?=\.|Note|###|Instruction|1```1|Final Answer|```|\n)"  # Used to extract LLAMA3 output results # Final Answer:
    Translated_Sentence_Pattern_for_LogicBench = "(?<=The translated formal logic program sentence is:).*?(?=Note|###|Instruction|1```1|Final Answer|```|\n)"  # Used to extract LLAMA3 output results # Final Answer:

    Aligned_ASP_Pattern = "(?<=The aligned formal logic program are:).*?(?=Note|#|Instruction|1```1|Final Answer|```|\n)"  # Used to extract LLAMA3 output results # Final Answer:
    LLAMA31_Grammar_Score_Pattern = "(?<=score is:).*?(?=#|The ASP sentences are|1```1|Final Answer|```|\n)"
    Semantic_Score_Pattern = "(?<=score is:).*?(?=#|The explanation is|The natural language sentences are|1```1|Final Answer|```|\n)"
    Semantic_Explanation_Pattern = "(?<=explanation is:).*?(?=#|Instruction|1```1|Final Answer|```|\n)"

from transformers import AutoTokenizer, AutoModel
import torch


# Mean Pooling - Take attention mask into account for correct averaging
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] # First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)


# Sentences we want sentence embeddings for

# Load model from HuggingFace Hub
tokenizer = AutoTokenizer.from_pretrained('/home/Projects/Pre_trained_Models/distilbert-base-nli-stsb-mean-tokens')
model = AutoModel.from_pretrained('/home/Projects/Pre_trained_Models/distilbert-base-nli-stsb-mean-tokens')

# Tokenize sentences
sentences = ['This is an example sentence', 'Each sentence is converted']

encoded_input = tokenizer(sentences, padding=True, truncation=True, return_tensors='pt')
# Compute token embeddings
with torch.no_grad():
    model_output = model(**encoded_input)
# Perform pooling. In this case, max pooling.
sentence_embeddings = mean_pooling(model_output, encoded_input['attention_mask'])


def similarity(str1, str2):
    # # Convert sentences to vector representations
    # sentence1_embedding = sentence_transformersmodel.encode(str1)
    # sentence2_embedding = sentence_transformersmodel.encode(str2)
    # # Calculate similarity between sentences
    # cosine_similarity = util.cos_sim(sentence1_embedding, sentence2_embedding)

    encoded_input01 = tokenizer(str1, padding=True, truncation=True, return_tensors='pt')
    # Compute token embeddings
    with torch.no_grad():
        model_output01 = model(**encoded_input01)
    # Perform pooling. In this case, max pooling.
    sentence_embeddings01 = mean_pooling(model_output01, encoded_input01['attention_mask'])

    encoded_input02 = tokenizer(str2, padding=True, truncation=True, return_tensors='pt')
    # Compute token embeddings
    with torch.no_grad():
        model_output02 = model(**encoded_input02)
    # Perform pooling. In this case, max pooling.
    sentence_embeddings02 = mean_pooling(model_output02, encoded_input02['attention_mask'])
    cosine_similarity = util.cos_sim(sentence_embeddings01, sentence_embeddings02)

    return cosine_similarity



def DeepSeek_Solver(instructions, context):
    client = OpenAI(base_url=Base_URL,
                    api_key=API_Key)
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="deepseek-chat", # gpt-3.5-turbo/ gpt-4-turbo-preview
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context}
                ],
              temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send error, attempt {while_count01 + 1}: {e}")
            while_count01 += 1
        return ""

def Evaluation_Train_Test_Data_for_LogicBench(Read_Test_Data_file, Write_fine_tune_file_path, Write_Result_file_path, Expert_Iterative_Number, llama3_8B_model, llama3_model_tokenizer, NMR_Category, Dataset_Type):
    global Zero_or_Few_Shot, Zero_Shot_Instruction, Three_Few_Shot_Instruction, Zero_Shot_COT_Extensions_Shot_Instruction
    Instruction = ''
    if Zero_or_Few_Shot == 'Zero_Shot':
        Instruction = Zero_Shot_Instruction
    elif Zero_or_Few_Shot == 'Few_Shot':
        Instruction = Three_Few_Shot_Instruction
    elif Zero_or_Few_Shot == 'Zero_Shot_COT':
        Instruction = Zero_Shot_COT_Extensions_Shot_Instruction
    

    fine_tune_f2, repair_f3 = None, None
    with open(Read_Test_Data_file, 'r') as f0, open(Write_Result_file_path, 'a', encoding='utf-8') as result_f1: # , open(Write_fine_tune_file_path, 'a', encoding='utf-8') as fine_tune_f2: #, open(Write_Repair_file_path, 'a', encoding='utf-8') as repair_f3:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict = {}
        Label_Dict = {'yes': 'T', 'no': 'F'}

        global Answer_Set_List, Soft_Answer_Set_List, Prerequisite_Conclusion_Consistent_Facts_Dict
        global Each_Example_chatgpt_Number
        Each_Example_chatgpt_Number = 0
        LLMs_Generted_Label_List = []
        LLMs_Generted_Answer_Set_Explanation_List = []
        js = json.load(f0)
        # Split the dataset into train/validation/test
        # print(json.dumps(js, ensure_ascii=False))
        type = js['type']
        axiom = js['axiom']
        samples_List = js['samples']  # Calculate the number of facts in the default theory
        for sample in samples_List:
            Write_Result_Dict = {}  # This dictionary is used to store the final results
            Each_Example_chatgpt_Number = 0
            Sample_number = sample['id']
            if int(Sample_number)< -1:
                continue
            context = sample['context']
            qa_pairs = sample['qa_pairs']
            Question_text_List,Label_List = [],[]
            for qa_pair in qa_pairs:
                question_text = qa_pair['question']
                question_text = question_text.replace('does this entail that ','').replace('does this mean that ','').replace('does this imply that ','').replace('does this suggest that ','').replace('Does the context imply that ','').replace('Does this conclude that ','').replace('Can we imply that ','').replace('Does this conclude that ','').replace('?','.')
                answer = qa_pair['answer']
                Question_text_List.append(question_text)
                Label_List.append(Label_Dict[answer])
            Generted_Label_List = []
            if len(Question_text_List)>0:
                for key01 in range(len(Question_text_List)):
                    Context_Text_String = 'Context: ' + context + ' Question: ' + Question_text_List[key01]
                    results = DeepSeek_Solver(Instruction, Context_Text_String)
                    # Analyze the generated results
                    print("Total_count01={}, LLMs Results = {}".format(Total_count01, results))
                    predict_label = None
                    if 'unknown' in results or 'Unknown' in results:
                        predict_label = 'M'
                    elif 'true' in results or 'True' in results:
                        predict_label = 'T'
                    elif 'false' in results or 'False' in results:
                        predict_label = 'F'
                    else:
                        predict_label = 'M'
 
                    Generted_Label_List.extend([predict_label])
                    
            Total_Question_label_List.extend(Label_List)
            Total_LLMs_Generted_Label_List.extend(Generted_Label_List)
            Total_count01 = Total_count01 + 1
            Write_Result_Dict['Sample_number'] = str(Sample_number)  # Number of samples
            Write_Result_Dict['type'] = type
            Write_Result_Dict['axiom'] = axiom
            Write_Result_Dict['context'] = context
            Write_Result_Dict['NL_Origin_Question_Text'] = Question_text_List
            Write_Result_Dict['Origin_Question_Label_Lists'] = Label_List
            Write_Result_Dict['Generted_Label_List'] = Generted_Label_List
            Write_Result_Dict = json.dumps(Write_Result_Dict, ensure_ascii=False)
            result_f1.write(Write_Result_Dict + '\n')

            print('Reasoning mode {}! Sample {} finished! Generated labels: {}, True labels: {}'.format(NMR_Category, str(Sample_number), Generted_Label_List, Label_List))

            

        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # Calculate accuracy
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List, average = 'macro')
        print('accuracy={},F1={}'.format(accuracy,F1))

# Define a function to get the read file and output file paths
def Get_Read_and_Write_file_path(Expert_Iterative_Number, Dataset_Type):
        Read_Data_file = ''
        if Dataset_Name == 'MultiLogicNMR' or Dataset_Name=='MultiLogicNMR_OOD' or Dataset_Name=='MultiLogicNMR_NL':
            Read_Data_file = read_file_path + str(Reasoning_Mode) + '/' + str(Reasoning_Mode) + '_multiNMR_' + str(Dataset_Type) +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
        elif Dataset_Name == 'LogicBench':
            Read_Data_file = read_file_path + 'data/LogicBench(Eval)/' + str(Task_Type) + '/' + 'nm_logic/' + str(NMR_Category) +'/'+ 'data_instances'+ '.json'
        elif Dataset_Name == 'LogicNMR':
            Read_Data_file = read_file_path + str(Dataset_Type) + '.json'
        elif Dataset_Name == 'LogicEval':
            Read_Data_file = read_file_path + 'data/d' + str(Reasoning_Deep) + '_Data/nm/' + str(NMR_Category) + '.json'
        
        # Used to save the final solution results of the samples LLMs_Models_Choise:['DeepSeek'] ;Dataset_Type:['test', 'train'], Reasoning_Mode:['skeptical', 'credulous']
        # ASP_Number_ represents the number of translations per sentence
        Write_Result_file_path = ''
        if Dataset_Name == 'MultiLogicNMR' or Dataset_Name=='MultiLogicNMR_OOD' or Dataset_Name=='MultiLogicNMR_NL':
            Write_Result_file_path = write_file_path + Zero_or_Few_Shot + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + str(ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + '.json'
        elif Dataset_Name == 'LogicBench':
            Write_Result_file_path = write_file_path + Zero_or_Few_Shot + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type +'_' + NMR_Category + '_balance' + '.json'
        elif Dataset_Name == 'LogicNMR':
            Write_Result_file_path = write_file_path + Zero_or_Few_Shot + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_'+ str(ASP_extension_number_Min)+'_' + str(ASP_extension_number_Max) + '_balance' + '.json'
        elif Dataset_Name == 'LogicEval':
            Write_Result_file_path = write_file_path + Zero_or_Few_Shot + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_Allatonce_' + str(Allatonce_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_Deep' + Reasoning_Deep + '_' + NMR_Category + '_balance' + '.json'
        
        # Used to save the fine-tuned training set
        Write_fine_tune_file_path = '' # write_file_path + LLMs_Models_Choise + '_ASP_Solver_Iterative_DL_Tree'+ str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_fine_tune_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
        # Read data used for model fine-tuning
        Read_fine_tune_Data_file = '' # write_file_path + LLMs_Models_Choise + '_ASP_Solver_Iterative_DL_Tree'+ str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_fine_tune_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
        
        return Read_Data_file, Write_Result_file_path, Write_fine_tune_file_path, Read_fine_tune_Data_file #, Write_Repair_file_path_ASP_Repair, Read_Repair_Data_file_ASP_Repair

if __name__ == '__main__':
    # Expert iteration on the model framework
    Expert_Iterative_Number = 0 # Expert iteration count, starting from 0
    # Dataset_Type indicates whether the current read is the test set or validation set; test means test set, train means training set
    Dataset_Type = 'test' # Evaluate test set first
    for Category_key in range(len(NMR_Category_List)): # Iterate through each reasoning mode once
        if int(Category_key)<-1:
            continue
        NMR_Category = NMR_Category_List[Category_key]
        Prompt_List(NMR_Category)
    
        # First step: evaluate the test set
        # Get the paths for reading and writing files; currently reading the test set
        Read_Data_file, Write_Result_file_path, Write_fine_tune_file_path, Read_fine_tune_Data_file = Get_Read_and_Write_file_path(Expert_Iterative_Number, Dataset_Type)
        # Load initial model
        Test_llama3_8B_model, Test_llama3_model_tokenizer = None, None
        # Read dataset and test. If it is just a test set, only generate test set results. If it is a training set, generate fine-tuning samples and results simultaneously.
        # Read_Test_Data_file represents the path of the test dataset, Write_file_path02 is used to save the output results of the test set
        if Dataset_Name == 'LogicBench':
            Evaluation_Train_Test_Data_for_LogicBench(Read_Data_file, Write_fine_tune_file_path, Write_Result_file_path, Expert_Iterative_Number, Test_llama3_8B_model, Test_llama3_model_tokenizer, NMR_Category, Dataset_Type='test')
        else:
            print('Dataset does not exist!')
        
        print('Samples for reasoning mode {} completed!!'.format(NMR_Category))