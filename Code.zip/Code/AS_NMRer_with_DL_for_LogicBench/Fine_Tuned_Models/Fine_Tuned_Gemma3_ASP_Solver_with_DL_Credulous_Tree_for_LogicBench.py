import copy
import sys
import re
import httpx
import torch
sys.path.append('../../Dataset')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["NCCL_P2P_DISABLE"] = "1" # Disable NCCL P2P communication
os.environ["NCCL_IB_DISABLE"] = "0" # Disable NCCL IB communication
os.environ['WANDB_MODE'] = 'dryrun'
from unsloth.chat_templates import train_on_responses_only
from unsloth.chat_templates import get_chat_template
from unsloth.chat_templates import standardize_data_formats
from unsloth import FastModel
import torch
from trl import SFTTrainer,SFTConfig, DataCollatorForCompletionOnlyLM
from transformers import TrainingArguments
from datasets import load_dataset
from huggingface_hub import login
from huggingface_hub import notebook_login
max_seq_length = 2048
from datasets import Dataset
import pandas as pd
import numpy as np
from random import randrange
Reasoning_Mode = 'credulous' # [credulous, skeptical]

Task_Type, NMR_Category = '', ''
NMR_Category_List = []
Dataset_Name = 'LogicBench'
Reasoning_Deep = '1'
FineTuned_Flag = True
Dataset_Type = 'train' # Indicates the type of dataset, ['train', 'dev', 'test']
Task_Type = 'BQA' # ['BQA','MCQA']

if Dataset_Name == 'LogicBench':
    Task_Type = 'BQA' # ['BQA','MCQA']
    NMR_Category_List = ['default_reasoning_default','default_reasoning_irr', 'default_reasoning_open','default_reasoning_several','reasoning_about_exceptions_1','reasoning_about_exceptions_2','reasoning_about_exceptions_3','reasoning_about_priority']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '1':
    NMR_Category_List = ['default_reasoning_default', 'default_reasoning_irr', 'default_reasoning_open','default_reasoning_several','reasoning_about_exceptions_1','reasoning_about_exceptions_2','reasoning_about_exceptions_3','reasoning_about_priority']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '2':
    NMR_Category_List = ['BDR_MP','BDR_MT','DRD_MP','DRD_MT','DRI_MP','DRI_MT','PBD_MP','PBD_MT','REI_MP','REI_MT','REII_MP','REII_MT']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '3':
    NMR_Category_List = ['d3_1','d3_2','d4_1','d4_2','d5_1']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '4':
    NMR_Category_List = ['d4_1','d4_2']
elif Dataset_Name == 'LogicEval' and Reasoning_Deep == '5':
    NMR_Category_List = ['d5_1']

   
LLMs_Models_Choise = "Gemma3_27B" # ['GPT3.5','GPT4','Claude','Gemma3_27B','Mistral_7B','LLAMA3','LLAMA31']
         

read_file_path = '/home/Projects/LLM_ASP_NeSY_Solver/Datasets/' + str(Dataset_Name) + '/'
write_file_path = '/home/Projects/LLM_ASP_NeSY_Solver/Experiment/Results/'

# Prompt requires answering multiple questions simultaneously.
# Zero_Shot_Skeptical_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. ... (omitted for brevity) ...'
# Zero_Shot_Credulous_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. ... (omitted for brevity) ...'

# Prompt requires answering questions one by one.
Zero_Shot_Instruction = 'Task Description: \n  Given contexts and question, You need to generate answer labels for questions in a given context. The question ONLY in "True" or "False". \n If the question can be inferred based on the context, the answer label of the question is: "True"; \n  if the negation of the question can be inferred based on the context, the answer label of the question is: "False"; \n The input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for the question. \n  Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '

Train_Dataset, Test_Datset = None, None
Label2Text = {'yes':'True', 'no':'False', 'Yes':'True', 'No':'False'}
Label_Dict = {'yes':'T','Yes':'T','no':'F','No':'F'}
Label_Dict01 = {'T':[1],'F':[0]}

Instruction = Zero_Shot_Instruction 
# Define a function to read the file
def Read_Train_Dataset(Train_Dev_Test_Flag):
    All_Sample_List = []
    for Category_key in range(len(NMR_Category_List)): # Iterate through each reasoning mode once
        if int(Category_key)<-1:
            continue
        NMR_Category = NMR_Category_List[Category_key]

        Read_Train_Data_file = read_file_path + 'data/LogicBench(Aug)/' + 'nm_logic/' + str(NMR_Category) +'/'+ 'data_instances'+ '.json'
        with open(Read_Train_Data_file, 'r') as f0:
            js = json.load(f0)
            # Split dataset into train/validation/test
            # print(json.dumps(js, ensure_ascii=False))
            type = js['type']
            axiom = js['axiom']
            samples_List = js['samples']  if Dataset_Type == 'test' else js['data_samples']  # Calculate the number of facts in the default theory
            samples_number = 0
            for sample in samples_List:
                Write_Result_Dict = {}  # This dictionary is used to store the final results
                Each_Example_chatgpt_Number = 0
                Sample_number = sample['id'] if Dataset_Type == 'test' else samples_number
                samples_number = samples_number + 1
                if int(Sample_number)< -1:
                    continue
                context = sample['context']
                qa_pairs = sample['qa_pairs']
                Question_text_List,Label_List = [],[]
                Question_context_List = [] # Used to store the precondition 'If...' in the original question
                for qa_pair in qa_pairs:
                    question_text = qa_pair['question']
                    label = qa_pair['answer']
                    sample_list01 = []
                    sample_list01.append(context)
                    sample_list01.append(question_text)
                    sample_list01.append(Label2Text[label]) # yes->True, no->False
                    All_Sample_List.append(sample_list01)

    df = pd.DataFrame(All_Sample_List, columns=['Context','Question', 'Answer'])
    return df

def Train_Test_Dataset():
    # Get training dataset
    Train_dataset_df = Read_Train_Dataset(Train_Dev_Test_Flag='train')
    Train_data = Train_dataset_df[['Context','Question', 'Answer']]
    Train_data=Train_data.reset_index(drop=True)
    Train_data = Dataset.from_pandas(Train_data.iloc[0:])
    print('len(train_data)=',len(Train_data))

    # Get test dataset
    Test_dataset_df = Read_Train_Dataset(Train_Dev_Test_Flag='test')
    Test_data = Test_dataset_df[['Context','Question', 'Answer']]
    Test_data=Test_data.reset_index(drop=True)
    Test_data = Dataset.from_pandas(Test_data.iloc[0:99])
    print('len(Test_data)=',len(Test_data))
    return Train_data, Test_data


# 2. Load model (Load pre-trained model)
def Load_FineTune_Model():
    print('Loading model')
    Train_model, Train_tokenizer = FastModel.from_pretrained(

        model_name="/home/Projects/Pre_trained_Models/gemma3-27B",

        max_seq_length=2048,  # Set the maximum sequence length supported by the model, adjust as needed
        load_in_4bit=True,  # Whether to enable 4-bit quantization, using 4-bit quantization to load the model can significantly reduce memory usage but may slightly sacrifice accuracy
        load_in_8bit=False,  # 8-bit quantization is more accurate than 4-bit but doubles memory usage; if higher accuracy is needed and memory is sufficient, can be set to True
        full_finetuning=False,  # Full parameter fine-tuning
    )

    print('Model loaded successfully')

    

    # Set model parameters and fast LoRA weights and training
    Train_model = FastModel.get_peft_model(
        Train_model,
        finetune_vision_layers=False,  # Pure text task, disable fine-tuning of vision layers to save resources
        finetune_language_layers=True,  # Fine-tune language-related layers in the model, language layers are the core part of text tasks, keep enabled
        finetune_attention_modules=True,  # Fine-tune attention modules in the model
        finetune_mlp_modules=True,  # Fine-tune MLP modules in the model
        r=16,  # Rank in LoRA, higher rank means stronger model expression capability, slower training, and easier overfitting
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj", ],
        lora_alpha=16,  # Scaling factor in LoRA
        lora_dropout=0,  # Dropout rate in LoRA
        bias="none",
        random_state=3407,  # Random number seed, can be arbitrary
    )
    Train_tokenizer = get_chat_template(
        Train_tokenizer,
        chat_template="gemma-3",
    )
    return Train_model, Train_tokenizer

def apply_chat_template(samples):
    conversations = []
    for Context, Question, Answer in zip( samples["Context"], samples["Question"],samples["Answer"]):

        # Construct final conversation format
        # Check if fields in samples are of string type
        if isinstance(Context, list) or isinstance(Question, list) or isinstance(Answer, list):
            print(
                f"Type check: Context type={type(Context)}, Question type={type(Question)}, Answer type={type(Answer)}")
        conversation = (
                "<bos>\n"
                "<start_of_turn>user\n" + Instruction + Context + Question + "\n<end_of_turn>\n"
                "<start_of_turn>model\n" + "The answer label for the question is:" + Answer + "\n<end_of_turn>"
        )
        conversations.append(conversation)

    return {"text": conversations}


def tokenize_function(examples,Train_tokenizer):
    return Train_tokenizer(examples["text"], padding=False)



print('Model prepared for training')
# Start training
def Train_llama3(Train_model, Train_tokenizer, Train_Data):
    if Train_model is None or Train_tokenizer is None or Train_Data is None:
        print("Model or dataset loading failed, cannot proceed with training")
        return

    print('Training model')
    # Standardize data format, ensure all training data meets the input format required by the model
    train_data = Train_Data.map(apply_chat_template, batched=True)
    print("A sample instance processed for training:", train_data[0]["text"])

    # Manually preprocess and tokenize
    train_data = train_data.map(
        lambda examples: tokenize_function(examples, Train_tokenizer=Train_tokenizer),
        batched=True,
        remove_columns=["text"],  # Remove original text column
        desc="Tokenizing dataset"
    )

    

    trainer = SFTTrainer(
        model=Train_model,
        tokenizer=Train_tokenizer,
        train_dataset=train_data,
        eval_dataset=None,  # No evaluation, can be replaced with specific dataset to enable evaluation
        args=SFTConfig(
            dataset_text_field="text",
            dataset_kwargs={"skip_prepare_dataset": True},
            per_device_train_batch_size=4,
            gradient_accumulation_steps=4,  # Gradient accumulation steps
            warmup_steps=10,
            max_steps=100,
            learning_rate=2e-4,  # Learning rate
            logging_steps=1,
            # output_dir = '/home/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_'+ Dataset_Category+  '_' + str(Train_Number),
            optim="adamw_8bit",  # Optimizer, 8-bit version of AdamW optimizer, saves memory and is suitable for large models.
            weight_decay=0.01,
            lr_scheduler_type="linear",
            seed=3407,
            report_to="none",  # Log output destination, here means not using external tools (like WandB) to record logs
        ),
    )

    print('Start training')
    trainer.train()
    print('Training completed')

# Save model
def Saved_Model(Train_model, Train_tokenizer):
    print('Saving train model')
    Train_model.save_pretrained('/home/Projects/LLM_ASP_NeSY_Solver/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Dataset_Name + '_lora_model')
    print('Trained Model saved')

# Load pre-trained model for testing
def Load_Test_Model():
    # 2. Load model
    print('Loading Test model')
    if FineTuned_Flag == True:
        Test_model, Test_tokenizer = FastModel.from_pretrained(
            model_name = '/home/Projects/LLM_ASP_NeSY_Solver/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + 'LogicBench' + '_lora_model', # +  '_' + str(Train_Number) # Specify the exact model in Unsloth.
            max_seq_length = max_seq_length, # Set the maximum sequence length (defined earlier) to limit the input length the model can process.
            dtype = None, # (Assuming it is set to None) Allows the library to choose the most suitable data type
            load_in_4bit = True, # Allow loading in memory-efficient 4-bit format (if model and hardware support it)
        )
    else:
        Test_model, Test_tokenizer = FastModel.from_pretrained(
            model_name = '/home/Projects/Pre_trained_Models/gemma3-27B', # +  '_' + str(Train_Number) 
            max_seq_length = max_seq_length, # Set the maximum sequence length (defined earlier) to limit the input length the model can process.
            dtype = None, # (Assuming it is set to None) Allows the library to choose the most suitable data type
            load_in_4bit = True, # Allow loading in memory-efficient 4-bit format (if model and hardware support it)
        )
    FastModel.for_inference(Test_model)
    print('Test Model loaded')
    return Test_model, Test_tokenizer

def Test_generate_text(Test_model, Test_tokenizer, prompt):
    input_ids = Test_tokenizer(prompt, return_tensors="pt").input_ids.cuda()
    outputs = Test_model.generate(input_ids=input_ids, pad_token_id=Test_tokenizer.eos_token_id, max_new_tokens=50, do_sample=True, top_p=0.9, temperature=0.5) # max_new_tokens Max tokens generated during inference
    generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(input_ids, outputs)]
    LLAMA3_LLMs_response_output = Test_tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    print(f"\nGenerated Response:\n{LLAMA3_LLMs_response_output}")
    return LLAMA3_LLMs_response_output

def Test_Model_LogicBench(Test_model, Test_tokenizer, NMR_Category):
    Read_Test_Data_file, Write_Result_file_path = '',''
    if Dataset_Name == 'LogicBench':
        Read_Test_Data_file = read_file_path + 'data/LogicBench(Eval)/' + str(Task_Type) + '/' + 'nm_logic/' + str(NMR_Category) +'/'+ 'data_instances'+ '.json'
        if FineTuned_Flag==True:
            Write_Result_file_path = write_file_path + 'FineTuned' + '_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type +'_' + NMR_Category + '_balance' + '.json'
        else:
            Write_Result_file_path = write_file_path + 'FineTuned' + '_Flag_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type +'_' + NMR_Category + '_balance' + '.json'

    elif Dataset_Name == 'LogicEval':
        Read_Test_Data_file = read_file_path + 'data/d' + str(Reasoning_Deep) + '_Data/nm/' + str(NMR_Category) + '.json'
        if FineTuned_Flag==True:
            Write_Result_file_path = write_file_path + 'FineTuned' + '_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_Deep' + Reasoning_Deep + '_' + NMR_Category + '_balance' + '.json'
        else:
            Write_Result_file_path = write_file_path + 'FineTuned' + '_Flag_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_Deep' + Reasoning_Deep + '_' + NMR_Category + '_balance' + '.json'

    with open(Read_Test_Data_file, 'r' , encoding='utf-8') as f0, open(Write_Result_file_path, 'w', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        
        Write_Dict = {}  # This dictionary is used to store the sample dictionary to be written
        js = json.load(f0)
        # Split dataset into train/validation/test
        # print(json.dumps(js, ensure_ascii=False))
        type = js['type']
        axiom = js['axiom']
        samples_List = js['samples']   # Calculate the number of facts in the default theory
        samples_number = 1
        for sample in samples_List:
            Write_Result_Dict = {}  # This dictionary is used to store the final results
            Each_Example_chatgpt_Number = 0
            samples_number = samples_number + 1
            context = sample['context']
            qa_pairs = sample['qa_pairs']
            Question_text_List,Label_List = [],[]
            Question_context_List = [] # Used to store the precondition 'If...' in the original question
            Question_label_List = []
            LLMs_Generted_Label_List = []

            for qa_pair in qa_pairs:
                question_text = qa_pair['question']
                if 'If' in question_text and 'does this mean that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this mean that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'If' in question_text and 'does this entail that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this entail that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'If' in question_text and 'does this imply that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this imply that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'If' in question_text and 'does this suggest that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this suggest that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                else:
                    question_text = question_text.replace('does this entail that ','').replace('does this mean that ','').replace('does this imply that ','').replace('does this suggest that ','').replace('Does the context imply that ','').replace('Does this conclude that ','').replace('Can we imply that ','').replace('Does this conclude that ','').replace('?','.')

                label = Label_Dict[qa_pair['answer']] # yes->'T', no->F
                Question_text_List.append(question_text)
                Question_label_List.append(label) # yes->T, no->F

                Total_Question_label_List.extend(Label_Dict01[label]) # yes->T, no->F
                # Call large model for prediction
                Test_prompt = f"""### Instruction: {Instruction} ### Context: {context} ### Question: {question_text}\n### Response: """
                while_count01 = 0
                result_output = ''

                result_output = Test_generate_text(Test_model, Test_tokenizer, Test_prompt)

                ### Add a function to judge the format of the result generated by the large model; if it does not meet the format, regenerate.

                # Analyze the generated results
                print("Total_count01={}, LLMs Results = {}".format(Total_count01, result_output))
                predict_label = None
                if 'true' in result_output or 'True' in result_output:
                    predict_label = 'T'
                elif 'false' in result_output or 'False' in result_output:
                    predict_label = 'F'
                else:
                    predict_label = 'F'
                LLMs_Generted_Label_List.append(predict_label)

                Total_LLMs_Generted_Label_List.extend(Label_Dict01[predict_label])
            
            print('Model tested: Total_count01={}, Total_LLMs_Generted_Label_List = {}, Origin_Question_Label_Lists: = {}'.format(Total_count01, Question_label_List, LLMs_Generted_Label_List))

            Write_Result_Dict['Sample_number'] = str(samples_number)  # Sample count
            Write_Result_Dict['type'] = type
            Write_Result_Dict['axiom'] = axiom
            Write_Result_Dict['context'] = context
            Write_Result_Dict['NL_Origin_Question_Text'] = Question_text_List
            Write_Result_Dict['Origin_Question_Label_Lists'] = Question_label_List
            Write_Result_Dict['LLMs_Generted_Label_List_with_LLMs'] = LLMs_Generted_Label_List
            Write_Result_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Result_Dict['Each_Example_chatgpt_Number'] = Each_Example_chatgpt_Number
            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')
            Total_count01 = Total_count01 + 1


        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # Calculate accuracy
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List,average = 'macro')
        print('DatasetName = {}, NMR_Category = {},accuracy={},F1={}'.format(Dataset_Name, NMR_Category, accuracy,F1))

def Test_Model_LogicEval(Test_model, Test_tokenizer, NMR_Category):
    Read_Test_Data_file, Write_Result_file_path = '',''
    if Dataset_Name == 'LogicBench':
        Read_Test_Data_file = read_file_path + 'data/LogicBench(Eval)/' + str(Task_Type) + '/' + 'nm_logic/' + str(NMR_Category) +'/'+ 'data_instances'+ '.json'
        Write_Result_file_path = write_file_path + 'SC-NMRer_Tree' + '_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + Task_Type +'_' + NMR_Category + '_balance' + '.json'
    elif Dataset_Name == 'LogicEval':
        Read_Test_Data_file = read_file_path + 'data/d' + str(Reasoning_Deep) + '_Data/nm/' + str(NMR_Category) + '.json'
        Write_Result_file_path = write_file_path + 'SC-NMRer_Tree' + '_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_Deep' + Reasoning_Deep + '_' + NMR_Category + '_balance' + '.json'
    
    with open(Read_Test_Data_file, 'r' , encoding='utf-8') as f0, open(Write_Result_file_path, 'w', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        
        Write_Dict = {}  # This dictionary is used to store the sample dictionary to be written
        js = json.load(f0)
        # Split dataset into train/validation/test
        # print(json.dumps(js, ensure_ascii=False))
        type = js['rule']
        depth = js['depth']
        samples_List = js['samples']  # Calculate the number of facts in the default theory
        samples_number = 1
        for sample in samples_List:
            Write_Result_Dict = {}  # This dictionary is used to store the final results
            Each_Example_chatgpt_Number = 0
            samples_number = samples_number + 1
            context = sample['context']
            qa_pairs = [sample['question']]
            Question_text_List,Label_List = [],[]
            Question_context_List = [] # Used to store the precondition 'If...' in the original question
            Question_label_List = []
            LLMs_Generted_Label_List = []

            for qa_pair in qa_pairs:
                question_text = qa_pair
                if 'If' in question_text and 'does this mean that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this mean that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'If' in question_text and 'does this entail that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this entail that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'If' in question_text and 'does this imply that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this imply that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                elif 'If' in question_text and 'does this suggest that' in question_text:
                    question_text_list = question_text.replace('If','').split('does this suggest that')
                    question_context,question_text = question_text_list[0],question_text_list[-1]
                    Question_context_List.append(question_context)
                else:
                    question_text = question_text.replace('does this entail that ','').replace('does this mean that ','').replace('does this imply that ','').replace('does this suggest that ','').replace('Does the context imply that ','').replace('Does this conclude that ','').replace('Can we imply that ','').replace('Does this conclude that ','').replace('?','.').replace('Can we conclude that ','')
                    question_text = question_text.replace('?','.').replace('Can we conclude ','')

                label = Label_Dict[sample['answer']] # yes->'T', no->F
                Question_text_List.append(question_text)
                Question_label_List.append(label) # yes->T, no->F

                Total_Question_label_List.extend(Label_Dict01[label]) # yes->T, no->F
                # Call large model for prediction
                Test_prompt = f"""### Instruction: {Instruction} ### Context: {context} ### Question: {question_text}\n### Response: """
                while_count01 = 0
                result_output = ''

                result_output = Test_generate_text(Test_model, Test_tokenizer, Test_prompt)

                ### Add a function to judge the format of the result generated by the large model; if it does not meet the format, regenerate.

                # Analyze the generated results
                print("Total_count01={}, LLMs Results = {}".format(Total_count01, result_output))
                predict_label = None
                if 'true' in result_output or 'True' in result_output:
                    predict_label = 'T'
                elif 'false' in result_output or 'False' in result_output:
                    predict_label = 'F'
                else:
                    predict_label = 'F'
                LLMs_Generted_Label_List.append(predict_label)

                Total_LLMs_Generted_Label_List.extend(Label_Dict01[predict_label])
            
            print('Model tested: Total_count01={}, Total_LLMs_Generted_Label_List = {}, Origin_Question_Label_Lists: = {}'.format(Total_count01, Question_label_List, LLMs_Generted_Label_List))

            Write_Result_Dict['Sample_number'] = str(samples_number)  # Sample count
            Write_Result_Dict['type'] = type
            Write_Result_Dict['depth'] = depth
            Write_Result_Dict['context'] = context
            Write_Result_Dict['NL_Origin_Question_Text'] = Question_text_List
            Write_Result_Dict['Origin_Question_Label_Lists'] = Question_label_List
            Write_Result_Dict['LLMs_Generted_Label_List_with_LLMs'] = LLMs_Generted_Label_List
            Write_Result_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Result_Dict['Each_Example_chatgpt_Number'] = Each_Example_chatgpt_Number
            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')
            Total_count01 = Total_count01 + 1


        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # Calculate accuracy
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List,average = 'macro')
        print('DatasetName = {}, NMR_Category = {},accuracy={},F1={}'.format(Dataset_Name, NMR_Category, accuracy,F1))


if __name__ == '__main__':
    Train_data, Test_data = Train_Test_Dataset()
    Train_model, Train_tokenizer = Load_FineTune_Model()
    Train_llama3(Train_model, Train_tokenizer, Train_data)
    Saved_Model(Train_model, Train_tokenizer)

    Test_model, Test_tokenizer = Load_Test_Model()
    for Category_key in range(len(NMR_Category_List)): # Iterate through each reasoning mode once
        if int(Category_key)<-1:
            continue
        NMR_Category = NMR_Category_List[Category_key]
        if Dataset_Name == 'LogicBench':
            Test_Model_LogicBench(Test_model, Test_tokenizer, NMR_Category)
        elif Dataset_Name == 'LogicEval':
            Test_Model_LogicEval(Test_model, Test_tokenizer, NMR_Category)